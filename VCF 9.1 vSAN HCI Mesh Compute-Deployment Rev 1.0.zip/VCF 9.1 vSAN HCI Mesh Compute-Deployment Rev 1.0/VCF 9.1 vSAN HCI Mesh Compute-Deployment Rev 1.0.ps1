﻿#requires -Version 7.2
<#
.SYNOPSIS
VCF 9.1 single-site vSAN compute cluster creation workbench.
.DESCRIPTION
Separate companion to VCF9-StretchCluster-Automation-v2.0.7.
Imports a complete creation specification, provides topology controls, exports JSON,
validates through SDDC Manager, and submits only the exact successfully validated JSON.
This does NOT stretch an existing storage cluster and does not configure a witness.
No live environment testing has been performed. Review all inputs before use.
#>
[CmdletBinding()]
param([switch]$NoRelaunch,[switch]$EnableDeployment)
$ErrorActionPreference='Stop'
if (-not $IsWindows) { throw 'Windows and PowerShell 7 are required for WPF.' }
if ([Threading.Thread]::CurrentThread.ApartmentState -ne 'STA') {
    if ($NoRelaunch) { throw 'Start with pwsh -STA.' }
    & (Get-Process -Id $PID).Path -NoProfile -STA -File $PSCommandPath -NoRelaunch -EnableDeployment:$EnableDeployment
    exit $LASTEXITCODE
}
Add-Type -AssemblyName PresentationFramework,PresentationCore,WindowsBase
$script:Token=$null; $script:ValidatedHash=$null; $script:ValidatedBase=$null
$script:Submitted=$false; $script:Base=$null
$script:RunDir=Join-Path $PSScriptRoot ('VCF91-SingleSiteCompute-'+(Get-Date -Format 'yyyyMMdd-HHmmss'))
$null=New-Item -ItemType Directory -Path $script:RunDir
[xml]$xaml=@'
<Window xmlns="http://schemas.microsoft.com/winfx/2006/xaml/presentation" xmlns:x="http://schemas.microsoft.com/winfx/2006/xaml" Title="VCF 9.1 Single-Site Compute Deployment v3.5.9-complete" Width="1540" Height="1000" MinWidth="1000" MinHeight="650" Background="#101820" Foreground="#E6EDF3" WindowStartupLocation="CenterScreen">
<Window.Resources>
<Style TargetType="TextBlock"><Setter Property="Foreground" Value="#E6EDF3"/><Setter Property="Margin" Value="4"/><Setter Property="VerticalAlignment" Value="Center"/></Style>
<Style TargetType="TextBox"><Setter Property="Background" Value="#202C38"/><Setter Property="Foreground" Value="#E6EDF3"/><Setter Property="Margin" Value="4"/><Setter Property="Padding" Value="5"/></Style>
<Style TargetType="PasswordBox"><Setter Property="Background" Value="#202C38"/><Setter Property="Foreground" Value="#E6EDF3"/><Setter Property="Margin" Value="4"/></Style>
<Style TargetType="Button">
<Setter Property="Margin" Value="4"/><Setter Property="Padding" Value="10,6"/><Setter Property="Background" Value="#294454"/><Setter Property="Foreground" Value="#FFFFFF"/><Setter Property="BorderBrush" Value="#5A8298"/>
<Setter Property="Template"><Setter.Value><ControlTemplate TargetType="Button"><Border x:Name="ButtonBorder" Background="{TemplateBinding Background}" BorderBrush="{TemplateBinding BorderBrush}" BorderThickness="1" CornerRadius="3" Padding="{TemplateBinding Padding}"><ContentPresenter HorizontalAlignment="Center" VerticalAlignment="Center" RecognizesAccessKey="True"/></Border><ControlTemplate.Triggers><Trigger Property="IsMouseOver" Value="True"><Setter TargetName="ButtonBorder" Property="Background" Value="#365E73"/></Trigger><Trigger Property="IsEnabled" Value="False"><Setter Property="Opacity" Value="0.55"/></Trigger></ControlTemplate.Triggers></ControlTemplate></Setter.Value></Setter>
</Style>
<Style TargetType="CheckBox"><Setter Property="Foreground" Value="#E6EDF3"/><Setter Property="Margin" Value="6"/></Style>

<Style TargetType="TabControl">
<Setter Property="Background" Value="#16232D"/><Setter Property="Foreground" Value="#EDF4FA"/><Setter Property="BorderBrush" Value="#486171"/>
<Setter Property="Template"><Setter.Value><ControlTemplate TargetType="TabControl"><Grid Background="{TemplateBinding Background}"><Grid.RowDefinitions><RowDefinition Height="Auto"/><RowDefinition Height="*"/></Grid.RowDefinitions><TabPanel IsItemsHost="True" Margin="0,0,0,4"/><Border Grid.Row="1" Background="{TemplateBinding Background}" BorderBrush="{TemplateBinding BorderBrush}" BorderThickness="1" Padding="8"><ContentPresenter x:Name="PART_SelectedContentHost" ContentSource="SelectedContent"/></Border></Grid></ControlTemplate></Setter.Value></Setter>
</Style>
<Style TargetType="TabItem">
<Setter Property="Foreground" Value="#EDF4FA"/><Setter Property="Background" Value="#233644"/><Setter Property="Padding" Value="10,7"/>
<Setter Property="Template"><Setter.Value><ControlTemplate TargetType="TabItem"><Border x:Name="TabBorder" Background="{TemplateBinding Background}" BorderBrush="#486171" BorderThickness="1" Padding="{TemplateBinding Padding}" Margin="0,0,3,0"><ContentPresenter ContentSource="Header" RecognizesAccessKey="True"/></Border><ControlTemplate.Triggers><Trigger Property="IsSelected" Value="True"><Setter TargetName="TabBorder" Property="Background" Value="#006C91"/><Setter Property="Foreground" Value="#FFFFFF"/></Trigger><Trigger Property="IsMouseOver" Value="True"><Setter TargetName="TabBorder" Property="BorderBrush" Value="#67C9ED"/></Trigger></ControlTemplate.Triggers></ControlTemplate></Setter.Value></Setter>
</Style>
<Style TargetType="ComboBox">
<Setter Property="Background" Value="#223441"/><Setter Property="Foreground" Value="#F1F6FA"/><Setter Property="BorderBrush" Value="#668394"/><Setter Property="Padding" Value="6"/><Setter Property="MinHeight" Value="29"/>
<Setter Property="Template"><Setter.Value><ControlTemplate TargetType="ComboBox"><Grid><ToggleButton x:Name="DropToggle" Focusable="False" IsChecked="{Binding IsDropDownOpen, RelativeSource={RelativeSource TemplatedParent}, Mode=TwoWay}"><ToggleButton.Template><ControlTemplate TargetType="ToggleButton"><Border Background="#223441" BorderBrush="#668394" BorderThickness="1" CornerRadius="2"><TextBlock Text="&#x25BE;" HorizontalAlignment="Right" Margin="0,0,8,0" Foreground="#FFFFFF"/></Border></ControlTemplate></ToggleButton.Template></ToggleButton><ContentPresenter x:Name="SelectedText" Content="{TemplateBinding SelectionBoxItem}" ContentTemplate="{TemplateBinding SelectionBoxItemTemplate}" Margin="7,3,26,3" VerticalAlignment="Center" IsHitTestVisible="False"/><TextBox x:Name="PART_EditableTextBox" Visibility="Hidden" Background="#223441" Foreground="#FFFFFF" BorderThickness="0" Margin="4,2,25,2" VerticalContentAlignment="Center"/><Popup x:Name="PART_Popup" Placement="Bottom" IsOpen="{TemplateBinding IsDropDownOpen}" AllowsTransparency="True" Focusable="False" PopupAnimation="None"><Border Background="#223441" BorderBrush="#668394" BorderThickness="1" MinWidth="{Binding ActualWidth, RelativeSource={RelativeSource TemplatedParent}}" MaxHeight="350"><ScrollViewer CanContentScroll="True"><ItemsPresenter KeyboardNavigation.DirectionalNavigation="Contained"/></ScrollViewer></Border></Popup></Grid><ControlTemplate.Triggers><Trigger Property="IsEditable" Value="True"><Setter TargetName="PART_EditableTextBox" Property="Visibility" Value="Visible"/><Setter TargetName="SelectedText" Property="Visibility" Value="Hidden"/></Trigger><Trigger Property="IsEnabled" Value="False"><Setter Property="Opacity" Value="0.55"/></Trigger></ControlTemplate.Triggers></ControlTemplate></Setter.Value></Setter>
</Style>
<Style TargetType="ComboBoxItem"><Setter Property="Foreground" Value="#FFFFFF"/><Setter Property="Background" Value="#223441"/><Setter Property="Padding" Value="7"/><Setter Property="Template"><Setter.Value><ControlTemplate TargetType="ComboBoxItem"><Border x:Name="ItemBorder" Background="{TemplateBinding Background}" Padding="{TemplateBinding Padding}"><ContentPresenter/></Border><ControlTemplate.Triggers><Trigger Property="IsHighlighted" Value="True"><Setter TargetName="ItemBorder" Property="Background" Value="#006C91"/></Trigger><Trigger Property="IsSelected" Value="True"><Setter TargetName="ItemBorder" Property="Background" Value="#28566D"/></Trigger></ControlTemplate.Triggers></ControlTemplate></Setter.Value></Setter></Style>
<Style TargetType="DataGridColumnHeader"><Setter Property="Background" Value="#294454"/><Setter Property="Foreground" Value="#FFFFFF"/><Setter Property="Padding" Value="8"/><Setter Property="BorderBrush" Value="#486171"/><Setter Property="BorderThickness" Value="0,0,1,1"/></Style>
<Style TargetType="DataGridRow"><Setter Property="Foreground" Value="#F1F6FA"/><Style.Triggers><Trigger Property="IsSelected" Value="True"><Setter Property="Background" Value="#006C91"/></Trigger></Style.Triggers></Style>
<Style TargetType="DataGridCell"><Setter Property="Foreground" Value="#F1F6FA"/><Setter Property="BorderBrush" Value="#486171"/><Setter Property="Padding" Value="4"/><Style.Triggers><Trigger Property="IsSelected" Value="True"><Setter Property="Background" Value="#006C91"/><Setter Property="Foreground" Value="#FFFFFF"/></Trigger></Style.Triggers></Style>

</Window.Resources>
<Grid Margin="12"><Grid.RowDefinitions><RowDefinition Height="Auto"/><RowDefinition Height="Auto"/><RowDefinition Height="Auto"/><RowDefinition Height="*"/><RowDefinition Height="Auto"/></Grid.RowDefinitions>
<StackPanel Grid.Row="0"><TextBlock FontSize="20" FontWeight="Bold" Text="New single-site vSAN compute cluster | Generate / Validate / Execute"/><TextBlock TextWrapping="Wrap" Foreground="#F4C777" Text="Creates a NEW single-site compute cluster using an existing standard or stretched remote vSAN datastore. Does not modify the existing storage server cluster. Review the complete network specification. Deployment is disabled unless launched with -EnableDeployment."/></StackPanel>
<Grid Grid.Row="1"><Grid.ColumnDefinitions><ColumnDefinition Width="100"/><ColumnDefinition Width="*"/><ColumnDefinition Width="70"/><ColumnDefinition Width="*"/><ColumnDefinition Width="80"/><ColumnDefinition Width="180"/><ColumnDefinition Width="Auto"/></Grid.ColumnDefinitions>
<TextBlock Text="SDDC FQDN"/><TextBox Name="Server" Grid.Column="1"/><TextBlock Grid.Column="2" Text="User"/><TextBox Name="User" Grid.Column="3"/><TextBlock Grid.Column="4" Text="Password"/><PasswordBox Name="Password" Grid.Column="5"/><Button Name="Connect" Grid.Column="6" Content="Connect"/>
</Grid>
<StackPanel Grid.Row="2">
<WrapPanel><CheckBox Name="SkipTls" Content="Explicitly bypass TLS certificate verification (lab / approved exception only)"/><TextBlock Name="Status" Text="Not connected" Foreground="#F4C777"/></WrapPanel>
<WrapPanel><Button Name="Load" Content="Load creation JSON"/><Button Name="Starter" Content="Load starter template"/><Button Name="Inventory" Content="Read inventory"/><TextBlock Text="Server cluster ID:"/><TextBox Name="ServerCluster" Width="290"/><Button Name="Datastores" Content="Read server datastores"/><Button Name="OpenOutput" Content="Open output"/></WrapPanel>
<WrapPanel><TextBlock Text="Topology:"/><ComboBox Name="Topology" Width="140" Margin="4"><ComboBoxItem Content="Symmetric"/><ComboBoxItem Content="Asymmetric" IsSelected="True"/></ComboBox><TextBox Name="Client1" Width="175" Visibility="Collapsed" IsEnabled="False"/><TextBlock Text="Local storage site:"/><TextBox Name="Site1" Width="175"/><TextBox Name="Client2" Width="175" Visibility="Collapsed" IsEnabled="False"/><TextBox Name="Site2" Width="175" Visibility="Collapsed" IsEnabled="False"/><Button Name="Apply" Content="Apply topology"/></WrapPanel>
</StackPanel>
<TabControl Name="MainTabs" Grid.Row="3" Margin="4"><TabItem Header="Creation specification"><TextBox Name="Editor" FontFamily="Consolas" FontSize="12" AcceptsReturn="True" AcceptsTab="True" VerticalScrollBarVisibility="Auto" HorizontalScrollBarVisibility="Auto"/></TabItem><TabItem Header="Inventory / API response"><TextBox Name="Response" IsReadOnly="True" FontFamily="Consolas" AcceptsReturn="True" VerticalScrollBarVisibility="Auto" HorizontalScrollBarVisibility="Auto"/></TabItem><TabItem Header="Log"><TextBox Name="Log" IsReadOnly="True" FontFamily="Consolas" AcceptsReturn="True" VerticalScrollBarVisibility="Auto"/></TabItem></TabControl>
<WrapPanel Grid.Row="4"><CheckBox Name="Reviewed" Content="I reviewed the local site, host commissioning, datastore, image, NSX pools, uplinks and network design"/><Button Name="Generate" Content="Generate JSON"/><Button Name="Validate" Content="Validate with SDDC"/><Button Name="Execute" Content="Execute creation" IsEnabled="False"/><Button Name="Close" Content="Close"/></WrapPanel>
</Grid></Window>
'@
$reader=[System.Xml.XmlNodeReader]::new($xaml)
$script:Window=[Windows.Markup.XamlReader]::Load($reader)
$ui=@{}
foreach($n in @('Server','User','Password','Connect','SkipTls','Status','Load','Starter','Inventory','ServerCluster','Datastores','OpenOutput','Topology','Client1','Client2','Site1','Site2','Apply','Editor','Response','Log','Reviewed','Generate','Validate','Execute','Close','MainTabs')) { $ui[$n]=$script:Window.FindName($n) }
function Write-Log([string]$Message) {
    $line='[{0}] {1}' -f (Get-Date -Format 'yyyy-MM-dd HH:mm:ss'),$Message
    $ui.Log.AppendText($line+"`r`n"); $ui.Log.ScrollToEnd()
    Add-Content -LiteralPath (Join-Path $script:RunDir 'deployment.log') -Value $line
}
function Invalidate {
    $script:ValidatedHash=$null; $script:ValidatedBase=$null; $ui.Execute.IsEnabled=$false
}
function Get-Hash([string]$Text) {
    [Convert]::ToHexString([Security.Cryptography.SHA256]::HashData([Text.Encoding]::UTF8.GetBytes($Text)))
}
function Get-Base {
    $hostText=$ui.Server.Text.Trim()
    if ($hostText -notmatch '^[A-Za-z0-9][A-Za-z0-9.-]*$') { throw 'Enter only the SDDC Manager FQDN, without a scheme, port or path.' }
    'https://'+$hostText
}
function Invoke-Api([string]$Method,[string]$Path,$Body=$null,[switch]$Anonymous) {
    $base=Get-Base
    if (-not $Anonymous -and (-not $script:Token -or $script:Base -ne $base)) { throw 'Connect to the selected SDDC Manager first.' }
    $p=@{Method=$Method;Uri=$base+$Path;ContentType='application/json';TimeoutSec=1800;ErrorAction='Stop'}
    if (-not $Anonymous) { $p.Headers=@{Authorization='Bearer '+$script:Token;Accept='application/json'} }
    if ($ui.SkipTls.IsChecked) { $p.SkipCertificateCheck=$true }
    if ($null -ne $Body) { $p.Body=if($Body -is [string]){$Body}else{$Body|ConvertTo-Json -Depth 100} }
    try { Invoke-RestMethod @p }
    catch {
        $detail=if($_.ErrorDetails.Message){$_.ErrorDetails.Message}else{$_.Exception.Message}
        if($Anonymous){throw 'Authentication failed. Verify credentials, TLS trust and endpoint. No credential-bearing response is logged.'}
        throw "$Method $Path failed: $detail"
    }
}
function Save-Response([string]$Name,$Object) {
    $text=ConvertTo-Json -InputObject $Object -Depth 100
    $ui.Response.Text=$text
    $path=Join-Path $script:RunDir ($Name+'-'+(Get-Date -Format 'yyyyMMdd-HHmmss')+'.json')
    [IO.File]::WriteAllText($path,$text,[Text.UTF8Encoding]::new($false))
    Write-Log "Saved $Name response to $path"
}
function Read-Spec {
    if ($script:ViewDirty) { throw 'Unsaved form changes: click Apply on the edited tab, or Reload forms to discard them, before validation/export/execution.' }
    if ([string]::IsNullOrWhiteSpace($ui.Editor.Text)) { throw 'Load and complete a creation JSON specification first.' }
    $s=ConvertFrom-Json -InputObject $ui.Editor.Text -AsHashtable -Depth 100
    if (-not ($s -is [System.Collections.IDictionary])) { throw 'Root must be a JSON object.' }
    if ($s.Contains('clusterStretchSpec') -or $s.Contains('clusterUpdateSpec')) { throw 'This is an existing-cluster stretch/update payload. A NEW cluster requires domainId and computeSpec.' }
    if (@($s.computeSpec.clusterSpecs).Count -ne 1) { throw 'This workbench requires exactly one new cluster per request.' }
    return $s
}

# v3.5.1 pure local preflight: never repairs, rescales or rewrites source values.
function Test-TransportVlanValue($Value){
    if($Value -isnot [string] -and $Value -isnot [int] -and $Value -isnot [long]){return $false}
    $text=[string]$Value;$parsed=0
    if($text -cnotmatch '^[0-9]{1,4}$'){return $false}
    return ([int]::TryParse($text,[ref]$parsed) -and $parsed -ge 0 -and $parsed -le 4094)
}
function Get-SpecPreflight($Spec,$ServerIsStretched=$null){
    $rows=[Collections.Generic.List[object]]::new()
    function Add-Check([string]$Area,[string]$Name,[bool]$Passed,[string]$Detail){
        $rows.Add([pscustomobject]@{Area=$Area;Check=$Name;Status=if($Passed){'PASS'}else{'FAIL'};Detail=$Detail})
    }
    function Add-Warning([string]$Area,[string]$Name,[string]$Detail){
        $rows.Add([pscustomobject]@{Area=$Area;Check=$Name;Status='WARN';Detail=$Detail})
    }
    if($Spec -isnot [Collections.IDictionary]){Add-Check 'Payload' 'Root object' $false 'Creation JSON must be an object.';return ,$rows.ToArray()}
    Add-Check 'Payload' 'Placeholders' ((Json-Text $Spec) -notmatch 'REPLACE_|<[^>]+>') 'No unfinished placeholders allowed.'
    Add-Check 'Payload' 'Creation workflow' (-not ($Spec.Contains('clusterStretchSpec') -or $Spec.Contains('clusterUpdateSpec'))) 'This creates a compute cluster; it does not stretch an existing cluster.'
    $clusters=@($Spec.computeSpec.clusterSpecs|Where-Object {$null -ne $_})
    Add-Check 'Payload' 'One cluster' ($clusters.Count -eq 1) 'Exactly one cluster specification is supported.'
    if($clusters.Count -ne 1){return ,$rows.ToArray()}
    $c=$clusters[0]
    foreach($entry in @(@('domainId',$Spec.domainId),@('name',$c.name),@('clusterImageId',$c.clusterImageId),@('datacenterName',$c.datacenterName))){
        Add-Check 'Payload' $entry[0] (-not [string]::IsNullOrWhiteSpace([string]$entry[1])) 'Required workbench selection must be applied.'
    }
    $hosts=@($c.hostSpecs|Where-Object {$null -ne $_})
    Add-Check 'Hosts' 'Host selection' ($hosts.Count -gt 0) 'Select commissioned hosts; installed SDDC decides minimum count and eligibility.'
    Add-Check 'Hosts' 'Unique host IDs' (@($hosts.id|Sort-Object -Unique).Count -eq $hosts.Count -and @($hosts|Where-Object {-not $_.id}).Count -eq 0) 'Each selected host requires a unique commissioned ID.'
    $remote=$c.datastoreSpec.vsanRemoteDatastoreClusterSpec
    if($remote -isnot [Collections.IDictionary]){Add-Check 'Topology' 'Remote datastore structure' $false 'Missing vsanRemoteDatastoreClusterSpec.'}
    else{
        Add-Check 'Topology' 'Single-site compute client' ($remote.isStretched -is [bool] -and -not $remote.isStretched -and -not $remote.Contains('primaryAzName')) 'isStretched=false describes the client, not the storage server.'
        $mounts=@($remote.vsanRemoteDatastoreSpec|Where-Object {$null -ne $_})
        Add-Check 'Topology' 'Remote mount' ($mounts.Count -eq 1) 'Exactly one remote datastore specification required.'
        if($mounts.Count -eq 1){
            $r=$mounts[0];Add-Check 'Topology' 'Datastore UUID' (-not [string]::IsNullOrWhiteSpace([string]$r.datastoreUuid)) 'Use the discovered vSAN datastore UUID.'
            if($ServerIsStretched -isnot [bool]){Add-Check 'Topology' 'Server stretch state' $false 'Select/discover the storage server; unknown state is not assumed.'}
            elseif($ServerIsStretched){
                Add-Check 'Topology' 'API topology field' ($r.networkTopology -cin @('Symmetric','Asymmetric')) 'Stretched storage requires explicit networkTopology; the native UI omission is not copied.'
                if($r.networkTopology -ceq 'Asymmetric'){
                    $aff=@($r.siteAffinity|Where-Object {$null -ne $_})
                    $valid=($aff.Count -eq 1)
                    if($valid){$valid=(-not [string]::IsNullOrWhiteSpace([string]$aff[0].serverSite) -and -not $aff[0].Contains('clientSite'))}
                    Add-Check 'Topology' 'Server-only affinity' $valid 'Asymmetric single-site client requires one serverSite and no clientSite.'
                }elseif($r.networkTopology -ceq 'Symmetric'){Add-Check 'Topology' 'Symmetric affinity omission' (-not $r.Contains('siteAffinity')) 'Symmetric must omit siteAffinity in this workbench.'}
            }else{Add-Check 'Topology' 'Standard storage omission' (-not $r.Contains('networkTopology') -and -not $r.Contains('siteAffinity')) 'Standard storage must omit topology/site affinity.'}
        }
    }
    $n=$c.networkSpec;$nsx=$n.nsxClusterSpec.nsxTClusterSpec
    $vds=@($n.vdsSpecs|Where-Object {$null -ne $_});$profiles=@($n.networkProfiles|Where-Object {$null -ne $_})
    $pools=@($nsx.ipAddressPoolsSpec|Where-Object {$null -ne $_});$ups=@($nsx.uplinkProfiles|Where-Object {$null -ne $_})
    Add-Check 'NSX' 'Switch definitions' ($vds.Count -gt 0) 'Apply vDS definitions before NSX.'
    Add-Check 'NSX' 'NSX structure' ($nsx -is [Collections.IDictionary]) 'nsxTClusterSpec must be an object.'
    foreach($collection in @(@{Label='vDS';Items=$vds},@{Label='network profile';Items=$profiles},@{Label='pool';Items=$pools},@{Label='uplink profile';Items=$ups})){
        $items=@($collection.Items)
        Add-Check 'NSX' ('Unique '+$collection.Label+' names') (@($items|Where-Object {[string]::IsNullOrWhiteSpace([string]$_.name)}).Count -eq 0 -and @($items.name|Sort-Object -Unique).Count -eq $items.Count) 'Names must be nonempty and unique within their collection.'
    }
    $none=($nsx.overlayVtepSpec.vtepType -ceq 'NO_IP')
    if($none){
        Add-Check 'NSX' 'None profile omission' ($profiles.Count -eq 0 -and $pools.Count -eq 0 -and $ups.Count -eq 0) 'NO_IP shape requires no TEP profiles, pools or uplink definitions.'
        Add-Check 'NSX' 'None host references' (@($hosts|Where-Object {$_.hostNetworkSpec.networkProfileName}).Count -eq 0) 'No stale host networkProfileName for the None shape.'
    }else{
        Add-Check 'NSX' 'TEP network profiles' ($profiles.Count -gt 0 -and @($profiles|Where-Object {$_.isDefault -eq $true}).Count -eq 1) 'TEP-enabled workflow requires exactly one default network profile.'
        Add-Check 'NSX' 'TEP host-switch configuration' (@($profiles|ForEach-Object {$_.nsxtHostSwitchConfigs}|Where-Object {$null -ne $_}).Count -gt 0) 'Apply a complete NSX host-switch profile.'
        foreach($profile in $profiles){foreach($config in @($profile.nsxtHostSwitchConfigs|Where-Object {$null -ne $_})){
            $sw=@($vds|Where-Object {$_.name -ceq $config.vdsName})
            Add-Check 'NSX' 'Profile switch reference' ($sw.Count -eq 1) 'Host-switch profile must reference exactly one applied vDS.'
            Add-Check 'NSX' 'Uplink profile reference' (@($ups|Where-Object {$_.name -ceq $config.uplinkProfileName}).Count -eq 1) 'Referenced uplink profile must be defined.'
            if($config.ipAddressPoolName){Add-Check 'NSX' 'Static pool reference' (@($pools|Where-Object {$_.name -ceq $config.ipAddressPoolName}).Count -eq 1) 'Existing pool may be name-only; new pool must define valid subnets.'}
            else{
                $dhcp=($sw.Count -eq 1 -and -not [string]::IsNullOrWhiteSpace([string]$sw[0].nsxtSwitchConfig.ipAssignmentType))
                Add-Check 'NSX' 'Non-static assignment' $dhcp 'Without a static pool, an explicitly verified DHCP assignment value is required.'
                Add-Warning 'NSX' 'DHCP encoding' 'Local presence checks do not verify DHCP enum semantics. Installed-version evidence/SDDC validation required.'
            }
            $maps=@($config.vdsUplinkToNsxUplink|Where-Object {$null -ne $_})
            Add-Check 'NSX' 'Uplink mappings' ($maps.Count -gt 0 -and @($maps|Where-Object {-not $_.vdsUplinkName -or -not $_.nsxUplinkName}).Count -eq 0 -and @($maps.vdsUplinkName|Sort-Object -Unique).Count -eq $maps.Count) 'Each vDS uplink maps explicitly to an NSX uplink.'
            foreach($hostSpec in $hosts){
                $hu=@($hostSpec.hostNetworkSpec.vmNics|Where-Object {$_.vdsName -ceq $config.vdsName}|ForEach-Object {$_.uplink})
                Add-Check 'NSX' 'Host/profile uplink consistency' (@($maps|Where-Object {$_.vdsUplinkName -notin $hu}).Count -eq 0) 'Each referenced vDS uplink must be mapped on each selected host.'
            }
        }}
    }
    foreach($sw in $vds){
        $mtu=0;Add-Check 'vDS' 'Switch MTU' ([int]::TryParse([string]$sw.mtu,[ref]$mtu) -and $mtu -ge 1500 -and $mtu -le 9000) 'vDS MTU must be 1500-9000 in this guided workflow.'
        if($sw.nsxtSwitchConfig){
            $zones=@($sw.nsxtSwitchConfig.transportZones|Where-Object {$null -ne $_})
            Add-Check 'NSX' 'Transport zones' ($zones.Count -gt 0 -and @($zones|Where-Object {-not $_.name -or $_.transportType -cnotin @('VLAN','OVERLAY')}).Count -eq 0) 'NSX switch requires named VLAN/OVERLAY transport zones.'
            if($none){Add-Check 'NSX' 'None assignment shape' (-not $sw.nsxtSwitchConfig.Contains('ipAssignmentType')) 'Captured None uses overlayVtepSpec NO_IP, not ipAssignmentType.'}
        }
    }
    Add-Check 'NSX' 'NSX-prepared switch' (@($vds|Where-Object {$_.nsxtSwitchConfig}).Count -gt 0) 'Apply NSX configuration to at least one switch.'
    foreach($up in $ups){Add-Check 'NSX' 'Transport VLAN' (Test-TransportVlanValue $up.transportVlan) 'Accept integer or digits-only string 0-4094 without rewriting the source value.'}
    foreach($pool in $pools){
        if(-not $pool.Contains('subnets')){Add-Warning 'NSX' 'Existing pool reuse' 'Name-only reference accepted locally. Current pool ownership/capacity/availability is not verified.';continue}
        $subs=@($pool.subnets|Where-Object {$null -ne $_});Add-Check 'NSX' 'New pool subnets' ($subs.Count -gt 0) 'Present subnets must be nonempty; omit subnets for name-only reuse.'
        foreach($sub in $subs){
            $ranges=@($sub.ipAddressPoolRanges|Where-Object {$null -ne $_});Add-Check 'NSX' 'New pool ranges' ($ranges.Count -gt 0) 'New static pool requires allocation ranges.'
            foreach($range in $ranges){try{Assert-NewIpv4Pool ([string]$sub.cidr) ([string]$sub.gateway) ([string]$range.start) ([string]$range.end);Add-Check 'NSX' 'Static IPv4 range' $true 'CIDR/gateway/range structure passed.'}catch{Add-Check 'NSX' 'Static IPv4 range' $false 'Invalid CIDR/gateway/range. Review the new pool fields.'}}
        }
    }
    Add-Warning 'Scope' 'Traffic MTU' 'Per-traffic MTUs remain planning-only; this check does not configure VMkernel MTUs.'
    Add-Warning 'Scope' 'Local checks only' 'No IP availability, reachability, profile existence, pool capacity, host eligibility or production readiness is certified. Full SDDC validation remains mandatory.'
    return ,$rows.ToArray()
}
function Assert-ValidationResponse($Response){
    if($Response.executionStatus -cne 'COMPLETED' -or $Response.resultStatus -cne 'SUCCEEDED'){throw 'SDDC validation must explicitly report COMPLETED / SUCCEEDED. HTTP acceptance is not success.'}
    function Test-FailedValidationNode($Node){
        if($null -eq $Node){return $false}
        if($Node -is [array]){foreach($item in $Node){if(Test-FailedValidationNode $item){return $true}};return $false}
        if($Node -is [Collections.IDictionary]){$props=$Node.Keys}else{$props=@($Node.PSObject.Properties.Name)}
        if('resultStatus' -in $props -and $Node.resultStatus -in @('FAILED','CANCELLED','PENDING','IN_PROGRESS','ERROR')){return $true}
        foreach($key in $props){$value=$Node.$key;if($value -is [Collections.IDictionary] -or $value -is [pscustomobject] -or $value -is [array]){if(Test-FailedValidationNode $value){return $true}}}
        return $false
    }
    if(Test-FailedValidationNode $Response){throw 'A nested SDDC validation result is failed or incomplete. Execution remains blocked.'}
}
function Invoke-SpecPreflight($Spec){
    $state=$null
    try{$state=(Get-SelectedServerState).isStretched}catch{}
    $checks=Get-SpecPreflight $Spec $state
    foreach($validator in @('Assert-LocalSpec','Assert-References')){
        try{& $validator $Spec;$checks+=,[pscustomobject]@{Area='Existing guards';Check=$validator;Status='PASS';Detail='Existing local validator passed.'}}
        catch{$checks+=,[pscustomobject]@{Area='Existing guards';Check=$validator;Status='FAIL';Detail=$_.Exception.Message}}
    }
    $failed=@($checks|Where-Object {$_.Status -eq 'FAIL'})
    $warnings=@($checks|Where-Object {$_.Status -eq 'WARN'})
    $report=[ordered]@{kind='LocalPreflight';payloadHash=(Get-Hash $ui.Editor.Text);result=if($failed.Count){'FAILED'}else{'PASSED_LOCAL_ONLY'};failureCount=$failed.Count;warningCount=$warnings.Count;checks=$checks}
    Save-Response 'preflight' $report
    if($ui.ContainsKey('PreflightStatus')){$ui.PreflightStatus.Text='Local preflight: '+$failed.Count+' failure(s), '+$warnings.Count+' warning(s). See Inventory / API response and saved preflight JSON.';$ui.PreflightStatus.Foreground=if($failed.Count){'#FFD166'}else{'#87D8B0'}}
    if($failed.Count){Invalidate;throw ('Preflight failed: '+(($failed|ForEach-Object {$_.Area+'/'+$_.Check}) -join '; ')+'. Review the saved preflight report.')}
    Write-Log 'Local preflight passed with warnings. This does not authorize execution or replace full SDDC validation.'
}

function Assert-LocalSpec($s) {
    $json=ConvertTo-Json -InputObject $s -Depth 100
    if($json -match 'REPLACE_|<[^>]+>'){throw 'Complete every placeholder before validation or execution.'}
    if(-not $s.domainId){throw 'domainId is required.'}
    if(@($s.computeSpec.clusterSpecs).Count -ne 1){throw 'Exactly one new cluster is supported per request.'}
    $c=$s.computeSpec.clusterSpecs[0]
    if(-not $c.name -or -not $c.clusterImageId){throw 'Cluster name and image ID are required by this workbench.'}
    $hosts=@($c.hostSpecs)
    if($hosts.Count -eq 0){throw 'Select commissioned compute hosts. Installed SDDC validation determines the supported host count.'}
    if(@($hosts.id|Sort-Object -Unique).Count -ne $hosts.Count){throw 'Duplicate host IDs.'}
    $remote=$c.datastoreSpec.vsanRemoteDatastoreClusterSpec
    if($remote.isStretched -isnot [bool] -or $remote.isStretched){throw 'Single-site compute workflow requires JSON boolean isStretched=false.'}
    if($remote.Contains('primaryAzName')){throw 'Remove primaryAzName: this client is not stretched.'}
    if(@($remote.vsanRemoteDatastoreSpec).Count -ne 1){throw 'Select exactly one primary remote datastore.'}
    $r=$remote.vsanRemoteDatastoreSpec[0]
    if($r.networkTopology -eq 'Asymmetric' -and ($script:SiteScopeClusterId -ne $ui.ServerCluster.Text -or -not $ui.StorageSiteChoice.SelectedItem -or $r.siteAffinity[0].serverSite -ne [string]$ui.StorageSiteChoice.SelectedItem.Content)){throw 'Select the storage server and its discovered local fault domain, then Apply topology before validation.'}
    if(-not $r.datastoreUuid){throw 'Remote datastore UUID is required.'}
    $server=Get-SelectedServerState
    if(-not $server.isStretched){
        if($r.Contains('siteAffinity') -or $r.Contains('networkTopology')){throw 'Standard storage server: Apply topology to remove stretched-server topology/site fields.'}
    }elseif($r.networkTopology -notin @('Symmetric','Asymmetric')){throw 'Stretched storage server requires explicit Symmetric or Asymmetric topology.'}
    if($r.datastoreUuid -notin @($script:Cache.Datastores.id)){throw 'Remote datastore UUID must match a discovered vSAN datastore for the selected storage server.'}

    if($r.networkTopology -eq 'Asymmetric'){
        $aff=@($r.siteAffinity)
        if($aff.Count -ne 1 -or [string]::IsNullOrWhiteSpace($aff[0].serverSite)){throw 'Asymmetric single-site client requires one serverSite affinity entry.'}
        if($aff[0].Contains('clientSite')){throw 'Remove clientSite: the client is not stretched.'}
    }elseif($r.Contains('siteAffinity')){throw 'Symmetric topology must omit siteAffinity in this workbench.'}
    $n=$c.networkSpec
    if(-not $n.vdsSpecs -or -not $n.nsxClusterSpec){throw 'Complete the custom vDS and NSX network definitions.'}
    $noTep=($n.nsxClusterSpec.nsxTClusterSpec.overlayVtepSpec.vtepType -ceq 'NO_IP')
    if(-not $noTep -and -not $n.networkProfiles){throw 'TEP-enabled configuration requires networkProfiles.'}
    $profiles=@($n.networkProfiles.name);$switches=@($n.vdsSpecs.name)
    foreach($h in $hosts){
        if($h.Contains('azName')){throw 'Remove host azName from this single-site workbench payload.'}
        if(-not $h.id){throw 'Each host requires its actual commissioned ID.'}
        if($n.nsxClusterSpec.nsxTClusterSpec.overlayVtepSpec.vtepType -ne 'NO_IP'){
            if($h.hostNetworkSpec.networkProfileName){if($h.hostNetworkSpec.networkProfileName -notin $profiles){throw 'Host references an undefined network profile.'}}
            elseif(@($n.networkProfiles|Where-Object {$_.isDefault -eq $true}).Count -ne 1){throw 'Host has no explicit profile and there is not exactly one default network profile.'}
        }
        $nics=@($h.hostNetworkSpec.vmNics)
        if($nics.Count -eq 0 -or @($nics.id|Sort-Object -Unique).Count -ne $nics.Count){throw 'Review each host NIC mapping; no NIC can be mapped twice.'}
        foreach($nic in $nics){if($nic.id -notmatch '^vmnic\d+$' -or $nic.vdsName -notin $switches -or -not $nic.uplink){throw 'Invalid physical NIC / vDS / uplink mapping.'}}
    }
    foreach($up in @($n.nsxClusterSpec.nsxTClusterSpec.uplinkProfiles|Where-Object {$null -ne $_})){
        if(-not (Test-TransportVlanValue $up.transportVlan)){throw 'Transport VLAN must be an integer or digits-only JSON string in range 0-4094. Source type/value is preserved.'}
    }
    if($json -match '"(?:clusterStretchSpec|clusterUpdateSpec|witnessSpec)"\s*:'){throw 'Existing-cluster stretch/update and witness payloads are not allowed.'}
    Write-Log 'Single-site compute structure checked. SDDC validation must still confirm host eligibility, minimum host count, networking and storage compatibility.'
}
function Invoke-UiAction([scriptblock]$Action) {
    $script:Window.Cursor=[Windows.Input.Cursors]::Wait
    try { & $Action } catch { Invalidate; Write-Log $_.Exception.Message; [Windows.MessageBox]::Show($_.Exception.Message,'Operation stopped','OK','Error')|Out-Null }
    finally { $script:ConnectingAll=$false; $script:LoadingForms=$false; $script:Window.Cursor=[Windows.Input.Cursors]::Arrow }
}
function Load-Text([string]$Path) {
    $script:LoadingForms=$true
    $ui.Editor.Text=[IO.File]::ReadAllText($Path)
    $s=Read-Spec; $r=$s.computeSpec.clusterSpecs[0].datastoreSpec.vsanRemoteDatastoreClusterSpec.vsanRemoteDatastoreSpec[0]
    foreach($item in $ui.Topology.Items) { if($item.Content -eq $r.networkTopology){$ui.Topology.SelectedItem=$item} }
    $sites=@($s.computeSpec.clusterSpecs[0].hostSpecs.azName|Select-Object -Unique)
    $ui.Client1.Text=if($sites.Count -gt 0){$sites[0]}else{''}
    $ui.Client2.Text=if($sites.Count -gt 1){$sites[1]}else{''}
    $a=@($r.siteAffinity)
    $ui.Site1.Text=if($a.Count -gt 0){$a[0].serverSite}else{''}
    $ui.Site2.Text=if($a.Count -gt 1){$a[1].serverSite}else{''}
    Write-Log "Loaded $Path. No API mutation was performed."
    $script:LoadingForms=$false
}
$ui.Connect.Add_Click({ Invoke-UiAction {
    Invalidate; $script:Token=$null;Clear-StorageCascade
    $t=Invoke-Api 'POST' '/v1/tokens' @{username=$ui.User.Text.Trim();password=$ui.Password.Password} -Anonymous
    if(-not $t.accessToken){throw 'No accessToken returned.'}
    $script:Token=$t.accessToken;$script:Base=Get-Base;$ui.Password.Clear();$ui.Status.Text='Connected';Write-Log 'Connected. Token is held only in memory.'
} })
$ui.Load.Add_Click({ Invoke-UiAction {
    $d=[Microsoft.Win32.OpenFileDialog]::new();$d.Filter='JSON (*.json)|*.json'
    if($d.ShowDialog()){$script:ViewDirty=$false;Load-Text $d.FileName;Reload-Forms}
} })
$ui.Starter.Add_Click({ Invoke-UiAction { $script:ViewDirty=$false; Load-Text (Join-Path $PSScriptRoot 'VCF91-SingleSiteCompute-Starter.json'); Reload-Forms } })
$ui.Inventory.Add_Click({ Invoke-UiAction {
    foreach($pair in @(@('domains','/v1/domains'),@('clusters','/v1/clusters'),@('hosts','/v1/hosts'),@('personalities','/v1/personalities'))) {
        $r=Invoke-Api 'GET' $pair[1];Save-Response $pair[0] $r
    }
    Write-Log 'Inventory snapshots saved. Review API pagination metadata; these snapshots are not a completeness or host-eligibility guarantee.'
} })
$ui.Datastores.Add_Click({ Invoke-UiAction {Read-SelectedStorageDatastores} })
$ui.Apply.Add_Click({ Invoke-UiAction {
    if(@($script:DirtySections|Where-Object {$_ -notin @('Topology','2 Storage / Topology')}).Count -gt 0){throw ('Apply pending edits in: '+(($script:DirtySections|Where-Object {$_ -notin @('Topology','2 Storage / Topology')}) -join ', '))}
    $s=Current-Spec
    $c=$s.computeSpec.clusterSpecs[0]
    $remote=$c.datastoreSpec.vsanRemoteDatastoreClusterSpec
    $remote.isStretched=$false
    $remote.Remove('primaryAzName')|Out-Null
    foreach($h in @($c.hostSpecs)){$h.Remove('azName')|Out-Null}
    $r=$remote.vsanRemoteDatastoreSpec[0]
    $server=Get-SelectedServerState
    if(-not $server.isStretched){
        $r.Remove('networkTopology')|Out-Null;$r.Remove('siteAffinity')|Out-Null
    }else{
    $r.networkTopology=[string]$ui.Topology.SelectedItem.Content
    if($r.networkTopology -eq 'Asymmetric'){
        if(-not $ui.StorageSiteChoice.SelectedItem -or $script:SiteScopeClusterId -ne $ui.ServerCluster.Text){throw 'Choose a discovered fault domain for the selected storage server.'}
        $r.siteAffinity=@(@{serverSite=$ui.Site1.Text.Trim()})
    }elseif($r.networkTopology -eq 'Symmetric'){$r.Remove('siteAffinity')|Out-Null}
    else{throw 'Select Symmetric or Asymmetric explicitly.'}
    }
    $script:ApplyingTopology=$true
    try {Commit-Spec $s} finally {$script:ApplyingTopology=$false}
    Write-Log 'Applied non-stretched client configuration and server-only affinity. Storage cluster configuration was not changed.'
} })
$ui.Generate.Add_Click({ Invoke-UiAction {
    $s=Read-Spec;Invoke-SpecPreflight $s
    $path=Join-Path $script:RunDir ('ClusterCreationSpec-'+(Get-Date -Format 'yyyyMMdd-HHmmss')+'.json')
    [IO.File]::WriteAllText($path,$ui.Editor.Text,[Text.UTF8Encoding]::new($false));Write-Log "Generated $path"
} })
$ui.Validate.Add_Click({ Invoke-UiAction {
    Invalidate;$s=Read-Spec;Invoke-SpecPreflight $s
    if(-not $ui.Reviewed.IsChecked){throw 'Complete the design review acknowledgement first.'}
    $text=$ui.Editor.Text
    $r=Invoke-Api 'POST' '/v1/clusters/validations?useAsyncValidation=false' $text
    Save-Response 'validation' $r
    Assert-ValidationResponse $r
    $script:ValidatedHash=Get-Hash $text;$script:ValidatedBase=Get-Base
    if(-not $script:Submitted -and $EnableDeployment){$ui.Execute.IsEnabled=$true}
    Write-Log 'SDDC validation completed successfully for the exact editor contents. Review all warnings before execution.'
    [Windows.MessageBox]::Show('SDDC validation COMPLETED / SUCCEEDED for the exact editor contents. The saved validation response contains no failed validation check.','SDDC validation passed','OK','Information')|Out-Null
} })
$ui.Execute.Add_Click({ Invoke-UiAction {
    if(-not $EnableDeployment){throw 'Deployment is disabled in this test session. Relaunch with -EnableDeployment only after review.'}
    if($script:ViewDirty){throw 'Apply or discard pending form changes before execution.'}
    if($script:Submitted){throw 'Submission was already attempted in this session. Check SDDC tasks before any retry.'}
    if(-not $ui.Reviewed.IsChecked -or -not $script:ValidatedHash -or (Get-Hash $ui.Editor.Text) -ne $script:ValidatedHash -or (Get-Base) -ne $script:ValidatedBase){throw 'Validate the unchanged specification against this SDDC Manager first.'}
    $s=Read-Spec;Invoke-SpecPreflight $s;$c=$s.computeSpec.clusterSpecs[0]
    $message="CREATE NEW single-site compute cluster '$($c.name)' in domain '$($s.domainId)' using $(@($c.hostSpecs).Count) hosts? This changes infrastructure."
    if([Windows.MessageBox]::Show($message,'Confirm cluster creation','YesNo','Warning') -ne 'Yes'){return}
    $text=$ui.Editor.Text
    [IO.File]::WriteAllText((Join-Path $script:RunDir 'Submitted-ClusterCreationSpec.json'),$text,[Text.UTF8Encoding]::new($false))
    $script:Submitted=$true;$ui.Execute.IsEnabled=$false
    Write-Log 'Submitting POST /v1/clusters once. If the response is lost, inspect SDDC tasks before retrying; no automatic retry is performed.'
    $r=Invoke-Api 'POST' '/v1/clusters' $text
    Save-Response 'creation' $r
    Write-Log 'Creation request returned. This is NOT a deployment-complete assertion. Monitor the returned task and VCF Operations Tasks.'
    Invalidate
} })
$ui.Editor.Add_TextChanged({Invalidate; if (-not $script:LoadingForms) { $script:FormsStale=$true }})
$ui.Server.Add_TextChanged({Invalidate;$script:Token=$null;Clear-StorageCascade;$ui.Status.Text='Reconnect required'})
$ui.SkipTls.Add_Click({Invalidate;$script:Token=$null;$ui.Status.Text='Reconnect required'})
$ui.Reviewed.Add_Unchecked({Invalidate})
$ui.Topology.Add_SelectionChanged({Invalidate; if($null -ne $script:DirtySections){Mark-Dirty 'Topology'}})
foreach($key in @('Client1','Client2','Site1','Site2')){$ui[$key].Add_TextChanged({Invalidate;if($null -ne $script:DirtySections){Mark-Dirty 'Topology'}})}
$ui.OpenOutput.Add_Click({Start-Process explorer.exe -ArgumentList ('"'+$script:RunDir+'"')})
$ui.Close.Add_Click({$script:Window.Close()})
$script:Window.Add_Closed({$script:Token=$null})

# ============================================================================
# v2 discovery-driven form workbench. All form changes are staged, never silent.
# ============================================================================
$script:ViewDirty=$false; $script:FormsStale=$false; $script:LoadingForms=$false
$script:DirtySections=[Collections.Generic.HashSet[string]]::new()
$script:Cache=@{}; $script:NsxCredential=$null; $script:NsxBase=$null
$script:Vc=$null; $script:VcInventory=@{}
$script:InventoryBase=$null
function Mark-Dirty([string]$Section='') {
    if (-not $script:LoadingForms) {
        if(-not $Section){$Section=[string]$ui.MainTabs.SelectedItem.Header}
        if($Section -eq 'Topology'){$Section='2 Storage / Topology'}
        if($Section -in @('Advanced NSX discovery','Advanced NSX definitions')){$Section='Network definitions'}
        if($Section -eq 'Advanced vDS / JSON'){$Section='4 Custom vDS'}
        if($Section -match '^[56] '){$Section='Network definitions'}
        $null=$script:DirtySections.Add($Section)
        $script:ViewDirty=$true; Invalidate; $ui.Status.Text='Pending form changes - Apply this section before editing another'
    }
}
function Json-Text($Value) { ConvertTo-Json -InputObject $Value -Depth 100 -Compress }
function Parse-Json([string]$Text) { ConvertFrom-Json -InputObject $Text -AsHashtable -Depth 100 -NoEnumerate }
function Copy-Json($Value) { Parse-Json (Json-Text $Value) }
function Need-CurrentForms {
    if($script:FormsStale){throw 'The JSON changed since forms were loaded. Click Reload forms before editing a form.'}
}

function Set-StorageSelectionsInSpec($Spec) {
    $server=Get-SelectedServerState
    $remote=$Spec.computeSpec.clusterSpecs[0].datastoreSpec.vsanRemoteDatastoreClusterSpec
    $remote.isStretched=$false;$remote.Remove('primaryAzName')|Out-Null
    $r=$remote.vsanRemoteDatastoreSpec[0]
    if($ui.DsChoice.SelectedItem){
        $ds=$ui.DsChoice.SelectedItem.Tag
        if($ds.datastoreType -ne 'VSAN' -or -not $ds.id){throw 'Select a discovered VSAN datastore with its UUID id.'}
        if($ds.id -notin @($script:Cache.Datastores.id)){throw 'Datastore is not in the current server discovery results.'}
        $r.datastoreUuid=[string]$ds.id
    }
    if(-not $server.isStretched){$r.Remove('networkTopology')|Out-Null;$r.Remove('siteAffinity')|Out-Null}
    else{
        $r.networkTopology=[string]$ui.Topology.SelectedItem.Content
        if($r.networkTopology -eq 'Asymmetric'){
            if(-not $ui.StorageSiteChoice.SelectedItem -or $script:SiteScopeClusterId -ne [string]$server.id){throw 'Choose a discovered storage-server fault domain before applying storage settings.'}
            $r.siteAffinity=@(@{serverSite=[string]$ui.StorageSiteChoice.SelectedItem.Content})
        }elseif($r.networkTopology -eq 'Symmetric'){$r.Remove('siteAffinity')|Out-Null}
        else{throw 'Choose the stretched-server network topology.'}
    }
}

function Commit-Spec($Spec) {
    $active=[string]$ui.MainTabs.SelectedItem.Header
    if($active -in @('Advanced NSX discovery','Advanced NSX definitions')){$active='Network definitions'}
    if($active -eq 'Advanced vDS / JSON'){$active='4 Custom vDS'}
    if($active -match '^[56] '){$active='Network definitions'}
    if($script:DirtySections.Remove('Topology')){$null=$script:DirtySections.Add('2 Storage / Topology')}
    if($active -eq '2 Storage / Topology'){Set-StorageSelectionsInSpec $Spec}
    if($script:DirtySections.Count -eq 1 -and -not $script:DirtySections.Contains($active) -and -not ($script:ApplyingTopology -and $script:DirtySections.Contains('Topology'))){throw ('Pending edits belong to: '+($script:DirtySections -join ', ')+'. Apply that section first; current section is '+$active+'.')}

    if($script:DirtySections.Count -gt 1){throw 'More than one section has staged edits. Reload forms to explicitly discard them, then edit and Apply one section at a time. No changes were silently discarded.'}
    $script:LoadingForms=$true
    try {$ui.Editor.Text=ConvertTo-Json -InputObject $Spec -Depth 100} finally {$script:LoadingForms=$false}
    $script:ViewDirty=$false; $script:FormsStale=$false
    Invalidate; Reload-Forms
}
function Current-Spec {
    Need-CurrentForms
    if([string]::IsNullOrWhiteSpace($ui.Editor.Text)){throw 'Load starter or creation JSON first.'}
    Parse-Json $ui.Editor.Text
}
function New-PanelTab([string]$Title) {
    $tab=[Windows.Controls.TabItem]::new();$tab.Header=$Title
    $dock=[Windows.Controls.DockPanel]::new();$dock.Margin='8'
    $tab.Content=$dock
    $ui.MainTabs.Items.Insert($ui.MainTabs.Items.Count-3,$tab)
    return ,$dock
}
function Add-Text($Parent,[string]$Text) {
    $t=[Windows.Controls.TextBlock]::new();$t.Text=$Text;$t.TextWrapping='Wrap';$t.Margin='4'
    [Windows.Controls.DockPanel]::SetDock($t,'Top');$null=$Parent.Children.Add($t)
}
function New-Bar($Parent) {
    $p=[Windows.Controls.WrapPanel]::new();[Windows.Controls.DockPanel]::SetDock($p,'Top');$null=$Parent.Children.Add($p);return ,$p
}
function Add-Button($Parent,[string]$Text,[scriptblock]$Action) {
    $btn=[Windows.Controls.Button]::new();$btn.Content=$Text
    $btn.Add_Click($Action);$null=$Parent.Children.Add($btn);return ,$btn
}
function Add-Input($Parent,[string]$Label,[string]$Key,[int]$Width=190,[switch]$Password,[switch]$Choice) {
    $t=[Windows.Controls.TextBlock]::new();$t.Text=$Label;$null=$Parent.Children.Add($t)
    if($Password){$c=[Windows.Controls.PasswordBox]::new()}
    elseif($Choice){$c=[Windows.Controls.ComboBox]::new();$c.IsEditable=$true;$c.Margin='4'}
    else{$c=[Windows.Controls.TextBox]::new()}
    $c.Width=$Width;$ui[$Key]=$c;$null=$Parent.Children.Add($c)
    return ,$c
}
function New-Grid($Parent,[string]$Key,$Columns) {
    $g=[Windows.Controls.DataGrid]::new();$g.AutoGenerateColumns=$false;$g.CanUserAddRows=$false;$g.CanUserDeleteRows=$false
    $g.SelectionMode='Extended';$g.SelectionUnit='FullRow';$g.Background='#182530';$g.Foreground='#F1F6FA';$g.RowBackground='#1C2D39';$g.AlternatingRowBackground='#233A49';$g.Margin='4'
    foreach($col in $Columns){
        if($col[1] -in @('Use','Nsx')){$c=[Windows.Controls.DataGridCheckBoxColumn]::new()}else{$c=[Windows.Controls.DataGridTextColumn]::new()}
        $c.Header=$col[0];$binding=[Windows.Data.Binding]::new($col[1]);$binding.Mode='TwoWay';$binding.UpdateSourceTrigger='PropertyChanged';$c.Binding=$binding
        $c.Width=[Windows.Controls.DataGridLength]::new([double]$col[2]);$c.IsReadOnly=($col.Count -gt 3 -and $col[3])
        $null=$g.Columns.Add($c)
    }
    $g.Add_CellEditEnding({Mark-Dirty});$ui[$Key]=$g;$null=$Parent.Children.Add($g);return ,$g
}
function Set-Rows([string]$Key,$Rows) {
    $list=[Collections.ObjectModel.ObservableCollection[object]]::new()
    foreach($r in $Rows){$list.Add([pscustomobject]$r)}
    $ui[$Key].ItemsSource=$list
}
function Flush-Grids {
    foreach($key in @('HostGrid','VdsGrid','PoolGrid','UplinkGrid','ProfileGrid','FieldGrid')){
        if($ui.ContainsKey($key)){$null=$ui[$key].CommitEdit([Windows.Controls.DataGridEditingUnit]::Cell,$true);$null=$ui[$key].CommitEdit([Windows.Controls.DataGridEditingUnit]::Row,$true)}
    }
}
function Show-JsonObject([string]$Title,$Object) {
    $d=[Windows.Window]::new();$d.Title=$Title+' | field editor';$d.Width=1200;$d.Height=760;$d.Owner=$script:Window;$d.Background='#101820';$d.Resources=$script:Window.Resources
    $dock=[Windows.Controls.DockPanel]::new();$d.Content=$dock
    Add-Text $dock 'Edit each field as a JSON literal. Strings require quotes; numbers and booleans do not. Arrays can be replaced using the JSON pointer controls. Nothing is applied until Save fields.'
    $bar=New-Bar $dock
    $ok=[Windows.Controls.Button]::new();$ok.Content='Save fields';$null=$bar.Children.Add($ok)
    $cancel=[Windows.Controls.Button]::new();$cancel.Content='Cancel';$null=$bar.Children.Add($cancel)
    $ptr=[Windows.Controls.TextBox]::new();$ptr.Width=440;$ptr.ToolTip='JSON pointer';$null=$bar.Children.Add($ptr)
    $val=[Windows.Controls.TextBox]::new();$val.Width=360;$val.ToolTip='JSON literal';$null=$bar.Children.Add($val)
    $set=[Windows.Controls.Button]::new();$set.Content='Set / add field';$null=$bar.Children.Add($set)
    $grid=[Windows.Controls.DataGrid]::new();$grid.AutoGenerateColumns=$false;$grid.CanUserAddRows=$false;$grid.CanUserDeleteRows=$false;$grid.Background='#182530';$grid.Foreground='#F1F6FA';$grid.RowBackground='#1C2D39';$grid.AlternatingRowBackground='#233A49'
    foreach($col in @(@('Field / JSON pointer','Pointer',650,$true),@('Type','Type',90,$true),@('Value (JSON literal)','ValueJson',390,$false))){
        $c=[Windows.Controls.DataGridTextColumn]::new();$c.Header=$col[0];$binding=[Windows.Data.Binding]::new($col[1]);$binding.Mode='TwoWay';$binding.UpdateSourceTrigger='PropertyChanged';$c.Binding=$binding;$c.Width=[Windows.Controls.DataGridLength]::new([double]$col[2]);$c.IsReadOnly=$col[3];$null=$grid.Columns.Add($c)
    }
    $list=[Collections.ObjectModel.ObservableCollection[object]]::new();$flat=[Collections.Generic.List[object]]::new();Flatten-Fields $Object '' $flat
    foreach($r in $flat){$list.Add([pscustomobject]$r)};$grid.ItemsSource=$list;$null=$dock.Children.Add($grid)
    $state=@{Object=(Copy-Json $Object)}
    $set.Add_Click({try{
        $null=$grid.CommitEdit([Windows.Controls.DataGridEditingUnit]::Cell,$true);$null=$grid.CommitEdit([Windows.Controls.DataGridEditingUnit]::Row,$true)
        $candidate=Copy-Json $state.Object;foreach($r in $list){Set-Pointer $candidate $r.Pointer (Parse-Json $r.ValueJson)}
        Set-Pointer $candidate $ptr.Text (Parse-Json $val.Text);$state.Object=$candidate
        $flat=[Collections.Generic.List[object]]::new();Flatten-Fields $state.Object '' $flat;$list.Clear();foreach($r in $flat){$list.Add([pscustomobject]$r)}
    }catch{[Windows.MessageBox]::Show($_.Exception.Message)|Out-Null}})
    $ok.Add_Click({try{
        $null=$grid.CommitEdit([Windows.Controls.DataGridEditingUnit]::Cell,$true);$null=$grid.CommitEdit([Windows.Controls.DataGridEditingUnit]::Row,$true)
        $candidate=Copy-Json $state.Object;foreach($r in $list){Set-Pointer $candidate $r.Pointer (Parse-Json $r.ValueJson)}
        $d.Tag=$candidate;$d.DialogResult=$true
    }catch{[Windows.MessageBox]::Show($_.Exception.Message)|Out-Null}})
    $cancel.Add_Click({$d.DialogResult=$false})
    if($d.ShowDialog()){return ,$d.Tag};return $null
}
# Pagination: SDDC pageMetadata and NSX cursor. Repeated pages/cursors stop discovery.
function Get-List([string]$Path,[switch]$Nsx) {
    $items=[Collections.Generic.List[object]]::new();$page=0;$cursor=$null;$seen=[Collections.Generic.HashSet[string]]::new()
    do {
        $sep=if($Path.Contains('?')){'&'}else{'?'}
        $url=$Path
        if($Nsx -and $cursor){$url+=$sep+'cursor='+[Uri]::EscapeDataString($cursor)}
        elseif(-not $Nsx -and $page -gt 0){$url+=$sep+'pageNumber='+$page}
        $r=if($Nsx){Invoke-NsxGet $url}else{Invoke-Api 'GET' $url}
        $batch=if($null -eq $r){@()}elseif($null -ne $r.elements){@($r.elements)}elseif($null -ne $r.results){@($r.results)}elseif($r -is [array]){@($r)}else{@($r)}
        $fingerprint=Get-Hash (Json-Text $batch)
        if(-not $seen.Add($fingerprint)){throw "Repeated discovery page for $Path. Partial results are not offered as complete."}
        foreach($x in $batch){if($null -ne $x){$items.Add($x)}}
        if($Nsx){$cursor=[string]$r.cursor;$more=-not [string]::IsNullOrWhiteSpace($cursor)}
        else{$page++;$more=($null -ne $r.pageMetadata -and $page -lt [int]$r.pageMetadata.totalPages)}
        if($page -gt 1000 -or $items.Count -gt 100000){throw 'Discovery safety limit reached; narrow the scope.'}
    }while($more)
    return $items.ToArray()
}
function Invoke-NsxGet([string]$Path) {
    if(-not $script:NsxCredential -or $script:NsxBase -ne ('https://'+$ui.NsxHost.Text.Trim())){throw 'Connect NSX for the selected endpoint first.'}
    if($Path -notmatch '^/(api/v1|policy/api/v1)/'){throw 'Only NSX read-only API paths are accepted.'}
    $p=@{Uri=$script:NsxBase+$Path;Method='GET';Authentication='Basic';Credential=$script:NsxCredential;TimeoutSec=120;ErrorAction='Stop'}
    if($ui.SkipTls.IsChecked){$p.SkipCertificateCheck=$true}
    Invoke-RestMethod @p
}
function First-Value($Object,[string[]]$Keys) {
    foreach($key in $Keys){$v=$Object.$key;if($null -ne $v -and -not [string]::IsNullOrWhiteSpace([string]$v)){return $v}}
    return ''
}
function Fill-Choice([string]$Key,$Objects,[string[]]$NameKeys,[string[]]$IdKeys) {
    $ui[$Key].Items.Clear()
    foreach($o in $Objects){$name=First-Value $o $NameKeys;$id=First-Value $o $IdKeys
        $item=[Windows.Controls.ComboBoxItem]::new();$item.Content="$name [$id]";$item.Tag=$o;$null=$ui[$Key].Items.Add($item)}
}
function Selected-Object([string]$Key) {
    if(-not $ui[$Key].SelectedItem -or -not $ui[$Key].SelectedItem.Tag){$label=switch($Key){'DsChoice'{'Remote datastore'};'StorageClusterChoice'{'Existing storage cluster'};'GuidedNsxVds'{'Applied vDS (first save a switch on Distributed Switch)'};default{$Key}};throw ('No '+$label+' is selected. Run discovery first, then select a returned item. Inspect Log if the list is empty.')}
    return $ui[$Key].SelectedItem.Tag
}
function Require-Inventory {
    if($script:InventoryBase -ne (Get-Base)){throw 'Discover inventory from the current SDDC Manager first.'}
}
# 1 General / image
$general=New-PanelTab '1 General / Image'
Add-Text $general 'Complete Connections / Inventory first, then load starter and select domain/image explicitly. Catalog image selection is supported. Host-image extraction is not implemented.'
$bar=New-Bar $general
$null=Add-Button $bar 'Discover SDDC inventory' {Invoke-UiAction {Discover-Sddc}}
$null=Add-Button $bar 'Reload forms from JSON (discard staged edits)' {Invoke-UiAction {$script:ViewDirty=$false;Reload-Forms}}
$bar=New-Bar $general
$null=Add-Input $bar 'Domain' 'DomainChoice' 420 -Choice
$null=Add-Input $bar 'Cluster name' 'ClusterName' 300
$bar=New-Bar $general
$null=Add-Input $bar 'Image catalog' 'ImageChoice' 620 -Choice
$null=Add-Button $bar 'Apply selected domain + image + name' {Invoke-UiAction {
    Require-Inventory;$spec=Current-Spec;$domain=Selected-Object 'DomainChoice';$image=Selected-Object 'ImageChoice'
    if([string]::IsNullOrWhiteSpace($ui.ClusterName.Text)){throw 'Cluster name required.'}
    $spec.domainId=[string](First-Value $domain @('id'));$spec.computeSpec.clusterSpecs[0].name=$ui.ClusterName.Text.Trim()
    $spec.computeSpec.clusterSpecs[0].clusterImageId=[string](First-Value $image @('personalityId','id'))
    Commit-Spec $spec;Write-Log 'Applied selected domain, catalog image and cluster name. Compatibility is still subject to SDDC validation.'
}}
$bar=New-Bar $general
$null=Add-Input $bar 'vCenter FQDN' 'VcHost' 270
$null=Add-Input $bar 'User' 'VcUser' 260
$null=Add-Input $bar 'Password' 'VcPass' 170 -Password
$null=Add-Button $bar 'Connect vCenter / discover datacenters + vDS' {Invoke-UiAction {Discover-Vcenter}}
$bar=New-Bar $general
$null=Add-Input $bar 'Datacenter inventory' 'DcChoice' 420 -Choice
Add-Text $general 'Select a datacenter from the target domain vCenter and apply it to the payload. Confirm domain placement during SDDC validation.'
Add-Text $general 'All fields tab supports every loaded JSON field, including optional fields added explicitly. Dedicated forms cover the common wizard settings. This is remote-vSAN compute creation only; NFS/FC/vVol and image extraction are not implemented.'
# 2 Storage
$storage=New-PanelTab '2 Storage / Topology'
Add-Text $storage 'Storage mode: vSAN > Compute Cluster > Mount Remote Datastore. Discover storage server clusters, then list their datastores. Discovery is not a compatibility guarantee. Select a vSAN target explicitly; the datastore response id is used as datastoreUuid.'
$bar=New-Bar $storage
$null=Add-Input $bar 'Storage vCenter' 'StorageVcChoice' 340 -Choice
$null=Add-Input $bar 'Storage datacenter' 'StorageDcChoice' 300 -Choice
$bar=New-Bar $storage
$null=Add-Input $bar 'Existing storage cluster' 'StorageClusterChoice' 540 -Choice
$ui.StorageVcChoice.IsEditable=$false;$ui.StorageDcChoice.IsEditable=$false;$ui.StorageClusterChoice.IsEditable=$false

$null=Add-Button $bar 'Discover selected server datastores' {Invoke-UiAction {Read-SelectedStorageDatastores}}
$bar=New-Bar $storage
$null=Add-Input $bar 'Remote datastore' 'DsChoice' 680 -Choice
$null=Add-Button $bar 'Apply remote datastore' {Invoke-UiAction {
    Require-Inventory;$o=Selected-Object 'DsChoice';$spec=Current-Spec
    $type=[string](First-Value $o @('type','datastoreType'))
    if($type -and $type -notmatch 'VSAN'){throw "Selected target reports non-vSAN type '$type'."}
    $id=[string](First-Value $o @('id','datastoreUuid'));if(-not $id){throw 'No datastore identifier.'}
    $spec.computeSpec.clusterSpecs[0].datastoreSpec.vsanRemoteDatastoreClusterSpec.vsanRemoteDatastoreSpec[0].datastoreUuid=$id
    Commit-Spec $spec;Write-Log 'Applied storage settings together: selected datastore UUID and server-appropriate topology/site affinity. SDDC validation is still required.'
}}
Add-Text $storage 'Use the Symmetric / Asymmetric and local storage-server site controls above the tabs, then Apply topology. Those controls modify the same JSON shown in Review. The client is non-stretched. Asymmetric uses one serverSite affinity and no clientSite.'
Add-Text $storage 'ESA is a property of the remote storage target in this workflow. This tool does not turn on local vSAN ESA for compute-only hosts. Optional remote encryption settings can be added in All fields only after confirming the installed schema.'
# 3 Hosts
$hostsTab=New-PanelTab '3 Hosts / NIC mappings'
Add-Text $hostsTab 'Only explicit unassigned usable/ready hosts with no cluster assignment are selectable. Storage type is displayed, not inferred. Set Use and network profile and per-host NIC mappings. SDDC validation decides final eligibility.'
$bar=New-Bar $hostsTab
$null=Add-Button $bar 'Refresh available hosts' {Invoke-UiAction {Discover-Sddc}}
# Client AZ assignment removed for single-site compute.
$null=Add-Input $bar 'Network profile' 'AssignProfile' 260
$null=Add-Button $bar 'Assign profile to selected rows' {Invoke-UiAction {
    Need-CurrentForms
    foreach($r in @($ui.HostGrid.SelectedItems)){$r.Profile=$ui.AssignProfile.Text.Trim();$r.Use=$true}
    $ui.HostGrid.Items.Refresh();Mark-Dirty
}}
$null=Add-Button $bar 'Edit selected host NIC fields' {Invoke-UiAction {
    Need-CurrentForms;$row=$ui.HostGrid.SelectedItem;if(-not $row){throw 'Select a host row.'}
    $obj=Show-JsonObject 'Per-host NIC mappings' (Parse-Json $row.NicsJson)
    if($null -ne $obj){$row.NicsJson=Json-Text $obj;$ui.HostGrid.Items.Refresh();Mark-Dirty}
}}
$null=Add-Button $bar 'Apply checked hosts' {Invoke-UiAction {
    Flush-Grids;Require-Inventory;$spec=Current-Spec;$out=@()
    foreach($r in @($ui.HostGrid.ItemsSource|Where-Object Use)){
        if(-not $r.Profile){throw 'Each checked host requires a network profile.'}
        $nics=Parse-Json $r.NicsJson
        if($nics -isnot [array]){throw 'NicsJson must be a JSON array.'}
        $prior=@($spec.computeSpec.clusterSpecs[0].hostSpecs|Where-Object {$_.id -eq $r.Id})
        $hostSpec=if($prior.Count){Copy-Json $prior[0]}else{@{}}
        $hostSpec.id=$r.Id;$hostSpec.Remove('hostname')|Out-Null;$hostSpec.hostName=$r.FQDN;$hostSpec.Remove('azName')|Out-Null
        $hostSpec.hostNetworkSpec=@{networkProfileName=$r.Profile;vmNics=$nics};$out+=$hostSpec
    }
    if($out.Count -eq 0){throw 'No checked hosts. Discovery can legitimately return zero; do not bypass commissioning.'}
    $spec.computeSpec.clusterSpecs[0].hostSpecs=$out;Commit-Spec $spec
}}
$null=New-Grid $hostsTab 'HostGrid' @(@('Use','Use',48),@('FQDN','FQDN',260,$true),@('ID','Id',260,$true),@('Status','Status',170,$true),@('Storage type','StorageType',150,$true),@('Network pool','NetworkPool',200,$true),@('Network profile','Profile',260),@('vmNics JSON (per host)','NicsJson',650))
# 4 Custom distributed switches
$switchTab=New-PanelTab '4 Custom vDS'
Add-Text $switchTab 'Define custom switches; multiple vDS rows are supported. Portgroups, transport zones, NIOC and LAGs are editable arrays. A discovered existing vDS is a design template, NOT an automatic existing-switch reuse instruction.'
$bar=New-Bar $switchTab
$null=Add-Input $bar 'Discovered vDS template' 'VdsChoice' 450 -Choice
$null=Add-Button $bar 'Copy selected vDS as NEW design row' {Invoke-UiAction {
    Need-CurrentForms;$o=Selected-Object 'VdsChoice'
    $ui.VdsGrid.ItemsSource.Add([pscustomobject]@{Name=('REPLACE_NEW_'+$o.Name);MTU=$o.Mtu;Nsx=$false;Mode='STANDARD';IpAssignment='';PortGroupsJson='[]';ZonesJson='[]';NiocJson='[]';LagJson='[]'})
    Mark-Dirty;Write-Log 'Copied name/MTU only. Explicitly define traffic roles, portgroups, NSX transport zones and uplinks; existing vCenter portgroups are not inferred as VCF transport roles.'
}}
$null=Add-Button $bar 'Add custom vDS' {Invoke-UiAction {Need-CurrentForms;$ui.VdsGrid.ItemsSource.Add([pscustomobject]@{Name='REPLACE_NEW_VDS';MTU=9000;Nsx=$true;Mode='STANDARD';IpAssignment='';PortGroupsJson='[]';ZonesJson='[]';NiocJson='[]';LagJson='[]'});Mark-Dirty}}
$null=Add-Button $bar 'Remove selected rows' {Invoke-UiAction {Need-CurrentForms;foreach($r in @($ui.VdsGrid.SelectedItems)){$null=$ui.VdsGrid.ItemsSource.Remove($r)};Mark-Dirty}}
$null=Add-Button $bar 'Edit selected vDS portgroup fields' {Invoke-UiAction {
    Need-CurrentForms;$row=$ui.VdsGrid.SelectedItem;if(-not $row){throw 'Select a vDS row.'}
    $obj=Show-JsonObject 'Portgroup definitions' (Parse-Json $row.PortGroupsJson)
    if($null -ne $obj){$row.PortGroupsJson=Json-Text $obj;$ui.VdsGrid.Items.Refresh();Mark-Dirty}
}}
$null=Add-Button $bar 'Apply custom vDS design' {Invoke-UiAction {
    Flush-Grids;$spec=Current-Spec;$out=@()
    foreach($r in $ui.VdsGrid.ItemsSource){
        $mtu=0;if(-not [int]::TryParse([string]$r.MTU,[ref]$mtu) -or $mtu -lt 1280 -or $mtu -gt 9000){throw 'Review vDS MTU (1280-9000 tool boundary).'}
        $v=if($r.OriginalJson){Parse-Json $r.OriginalJson}else{@{}}
        $v.name=$r.Name;$v.mtu=$mtu;$v.portGroupSpecs=Parse-Json $r.PortGroupsJson
        if(-not $r.Nsx){$v.Remove('nsxtSwitchConfig')|Out-Null}
        if($r.Nsx){$cfg=if($v.nsxtSwitchConfig){$v.nsxtSwitchConfig}else{@{}};$cfg.hostSwitchOperationalMode=$r.Mode;$cfg.transportZones=Parse-Json $r.ZonesJson;$v.nsxtSwitchConfig=$cfg;if($r.IpAssignment){$v.nsxtSwitchConfig.ipAssignmentType=$r.IpAssignment}}
        $ni=Parse-Json $r.NiocJson;$la=Parse-Json $r.LagJson
        $v.niocBandwidthAllocationSpecs=$ni;$v.lagSpecs=$la
        $out+=$v
    }
    $spec.computeSpec.clusterSpecs[0].networkSpec.vdsSpecs=$out;Commit-Spec $spec
}}
$null=New-Grid $switchTab 'VdsGrid' @(@('Name','Name',260),@('MTU','MTU',75),@('NSX enabled (True/False)','Nsx',140),@('Mode','Mode',130),@('ipAssignmentType (optional)','IpAssignment',210),@('Portgroups JSON','PortGroupsJson',520),@('Transport zones JSON','ZonesJson',420),@('NIOC JSON','NiocJson',420),@('LAG JSON','LagJson',420))
# 5 NSX discovery and static configuration
$nsxTab=New-PanelTab '5 NSX discovery'
Add-Text $nsxTab 'Read-only NSX discovery. Select a pool/profile and import as an editable definition. Imported definitions must be renamed before creation unless installed SDDC validation explicitly supports the intended existing-name behavior. No NSX POST/PUT/PATCH is performed directly.'
$bar=New-Bar $nsxTab
$null=Add-Input $bar 'NSX FQDN' 'NsxHost' 260
$null=Add-Input $bar 'User' 'NsxUser' 220
$null=Add-Input $bar 'Password' 'NsxPass' 170 -Password
$null=Add-Button $bar 'Connect / discover NSX' {Invoke-UiAction {Discover-Nsx}}
$bar=New-Bar $nsxTab
$null=Add-Input $bar 'Static pool' 'NsxPoolChoice' 550 -Choice
$null=Add-Button $bar 'Import selected pool definition' {Invoke-UiAction {Import-NsxPool}}
$bar=New-Bar $nsxTab
$null=Add-Input $bar 'Uplink profile' 'NsxUplinkChoice' 550 -Choice
$null=Add-Button $bar 'Import selected uplink profile' {Invoke-UiAction {Import-NsxUplink}}
$bar=New-Bar $nsxTab
$null=Add-Input $bar 'Transport zone' 'NsxZoneChoice' 550 -Choice
$null=Add-Button $bar 'Add zone to selected vDS row' {Invoke-UiAction {
    Need-CurrentForms;$o=Selected-Object 'NsxZoneChoice';$row=$ui.VdsGrid.SelectedItem;if(-not $row){throw 'Select a vDS row in Custom vDS first.'}
    $kind=if($o.transport_type){$o.transport_type}elseif($o.tz_type -eq 'OVERLAY_STANDARD'){'OVERLAY'}elseif($o.tz_type -eq 'VLAN_BACKED'){'VLAN'}else{''}
    if($kind -notin @('VLAN','OVERLAY')){throw 'Transport type could not be mapped safely. Inspect raw NSX response.'}
    $zones=Parse-Json $row.ZonesJson;$zones=@($zones);$zones+=@{name=[string](First-Value $o @('display_name','name'));transportType=$kind}
    $row.ZonesJson=Json-Text $zones;$row.Nsx=$true;$ui.VdsGrid.Items.Refresh();Mark-Dirty '4 Custom vDS'
}}
Add-Text $nsxTab 'Static TEP configuration is expressed through explicit ipAddressPoolsSpec definitions and networkProfiles[].nsxtHostSwitchConfigs[].ipAddressPoolName references. No guessed ipAssignmentType value is emitted. If the installed API requires that field, enter its verified value in Custom vDS / All fields.'
Add-Text $nsxTab 'Imported NSX pool ranges are existing allocations, not free-address recommendations. Rename AND replace the address ranges for a new pool; discovery does not prove IP availability. DHCP, per-host static TEP IP lists and transport-node-profile attachment are not implemented by this creation schema adapter.'
# 6 editable network profile objects
$networkTab=New-PanelTab '6 Static pools / profiles'
Add-Text $networkTab 'Edit per-site static pools, uplink profiles and host-switch network profiles. Each row represents one object; nested arrays can be edited in the dedicated JSON-object dialog or in All fields. Apply commits all three tables together.'
$bar=New-Bar $networkTab
$null=Add-Button $bar 'Edit selected pool object' {Invoke-UiAction {Edit-DefinitionRow 'PoolGrid'}}
$null=Add-Button $bar 'Edit selected uplink object' {Invoke-UiAction {Edit-DefinitionRow 'UplinkGrid'}}
$null=Add-Button $bar 'Edit selected network profile' {Invoke-UiAction {Edit-DefinitionRow 'ProfileGrid'}}
$null=Add-Button $bar 'Add pool' {Invoke-UiAction {Add-DefinitionRow 'PoolGrid'}}
$null=Add-Button $bar 'Add uplink' {Invoke-UiAction {Add-DefinitionRow 'UplinkGrid'}}
$null=Add-Button $bar 'Add network profile' {Invoke-UiAction {Add-DefinitionRow 'ProfileGrid'}}
$null=Add-Button $bar 'Apply all network definitions' {Invoke-UiAction {
    Flush-Grids;$spec=Current-Spec;$n=$spec.computeSpec.clusterSpecs[0].networkSpec
    if(-not $n.nsxClusterSpec){$n.nsxClusterSpec=@{nsxTClusterSpec=@{}}}
    $n.nsxClusterSpec.nsxTClusterSpec.ipAddressPoolsSpec=@($ui.PoolGrid.ItemsSource|ForEach-Object {Parse-Json $_.DefinitionJson})
    $n.nsxClusterSpec.nsxTClusterSpec.uplinkProfiles=@($ui.UplinkGrid.ItemsSource|ForEach-Object {Parse-Json $_.DefinitionJson})
    $n.networkProfiles=@($ui.ProfileGrid.ItemsSource|ForEach-Object {Parse-Json $_.DefinitionJson})
    Commit-Spec $spec
}}
$stack=[Windows.Controls.Grid]::new();foreach($i in 1..3){$r=[Windows.Controls.RowDefinition]::new();$r.Height=[Windows.GridLength]::new(1,[Windows.GridUnitType]::Star);$null=$stack.RowDefinitions.Add($r)};$null=$networkTab.Children.Add($stack)
$index=0
foreach($key in @('PoolGrid','UplinkGrid','ProfileGrid')){
    $p=[Windows.Controls.DockPanel]::new();[Windows.Controls.Grid]::SetRow($p,$index);$null=$stack.Children.Add($p)
    Add-Text $p $key
    $null=New-Grid $p $key @(@('Name (display; edit object to rename)','Name',320,$true),@('Complete editable definition JSON','DefinitionJson',1050))
    $index++
}
# 7 all scalar and container fields (JSON Pointer) including optional additions
$allTab=New-PanelTab '7 All fields'
Add-Text $allTab 'Every scalar and empty container in the loaded specification is exposed here. Values use JSON literals: strings in quotes, numbers unquoted, true/false, arrays or objects. Apply is atomic. For nested object/array replacement, use Set pointer; optional fields are not sent unless explicitly added.'
$bar=New-Bar $allTab
$null=Add-Button $bar 'Apply edited field rows' {Invoke-UiAction {
    Flush-Grids;$spec=Current-Spec
    foreach($r in $ui.FieldGrid.ItemsSource){Set-Pointer $spec $r.Pointer (Parse-Json $r.ValueJson)}
    Commit-Spec $spec
}}
$null=Add-Input $bar 'JSON pointer' 'Pointer' 530
$null=Add-Input $bar 'JSON value' 'PointerValue' 360
$null=Add-Button $bar 'Set / add pointer' {Invoke-UiAction {$spec=Current-Spec;Set-Pointer $spec $ui.Pointer.Text (Parse-Json $ui.PointerValue.Text);Commit-Spec $spec}}
$null=Add-Button $bar 'Remove pointer' {Invoke-UiAction {$spec=Current-Spec;Remove-Pointer $spec $ui.Pointer.Text;Commit-Spec $spec}}
$null=New-Grid $allTab 'FieldGrid' @(@('JSON pointer','Pointer',760,$true),@('Type','Type',110,$true),@('Editable JSON value','ValueJson',650))
function Pointer-Parts([string]$Pointer) {
    if(-not $Pointer.StartsWith('/')){throw 'Use a JSON pointer beginning with /.'}
    return ,@($Pointer.Substring(1).Split('/')|ForEach-Object {$_.Replace('~1','/').Replace('~0','~')})
}
function Set-Pointer($Root,[string]$Pointer,$Value) {
    $parts=Pointer-Parts $Pointer;$parent=$Root
    for($i=0;$i -lt $parts.Count-1;$i++){
        if($parent -is [Collections.IDictionary]){if(-not $parent.Contains($parts[$i])){throw 'Parent path does not exist. Add its object first.'};$parent=$parent[$parts[$i]]}
        elseif($parent -is [array]){$ix=0;if(-not [int]::TryParse($parts[$i],[ref]$ix) -or $ix -lt 0 -or $ix -ge $parent.Count){throw 'Invalid array index.'};$parent=$parent[$ix]}
        else{throw 'Pointer traverses a scalar.'}
    }
    $last=$parts[-1]
    if($parent -is [Collections.IDictionary]){$parent[$last]=$Value}
    elseif($parent -is [array]){$ix=0;if(-not [int]::TryParse($last,[ref]$ix) -or $ix -lt 0 -or $ix -ge $parent.Count){throw 'Replace the parent array to add/remove array elements.'};$parent[$ix]=$Value}
    else{throw 'Pointer parent is not an object or array.'}
}
function Remove-Pointer($Root,[string]$Pointer) {
    $parts=Pointer-Parts $Pointer;$parent=$Root
    for($i=0;$i -lt $parts.Count-1;$i++){$parent=if($parent -is [array]){$parent[[int]$parts[$i]]}else{$parent[$parts[$i]]}}
    if($parent -isnot [Collections.IDictionary]){throw 'Remove object properties here; replace parent arrays to remove elements.'}
    $parent.Remove($parts[-1])|Out-Null
}
function Flatten-Fields($Value,[string]$Pointer,$List) {
    if($Value -is [Collections.IDictionary] -and $Value.Count -gt 0){foreach($k in $Value.Keys){$escaped=([string]$k).Replace('~','~0').Replace('/','~1');Flatten-Fields $Value[$k] ($Pointer+'/'+$escaped) $List}}
    elseif($Value -is [array] -and $Value.Count -gt 0){for($i=0;$i -lt $Value.Count;$i++){Flatten-Fields $Value[$i] ($Pointer+'/'+$i) $List}}
    else{$type=if($null -eq $Value){'null'}elseif($Value -is [bool]){'boolean'}elseif($Value -is [string]){'string'}elseif($Value -is [array]){'array'}elseif($Value -is [Collections.IDictionary]){'object'}else{'number'};$List.Add(@{Pointer=$Pointer;Type=$type;ValueJson=(Json-Text $Value)})}
}
function Reload-Forms {
    if([string]::IsNullOrWhiteSpace($ui.Editor.Text)){return}
    $script:LoadingForms=$true
    try {
        $spec=Parse-Json $ui.Editor.Text;$c=$spec.computeSpec.clusterSpecs[0];$n=$c.networkSpec
        $ui.ClusterName.Text=$c.name
        $remote=$c.datastoreSpec.vsanRemoteDatastoreClusterSpec.vsanRemoteDatastoreSpec[0]
        foreach($item in $ui.Topology.Items){if($item.Content -eq $remote.networkTopology){$ui.Topology.SelectedItem=$item}}
        $sites=@($c.hostSpecs.azName|Select-Object -Unique)
        $ui.Client1.Text=if($sites.Count -gt 0){$sites[0]}else{''};$ui.Client2.Text=if($sites.Count -gt 1){$sites[1]}else{''}
        $aff=@($remote.siteAffinity)
        $ui.Site1.Text=if($aff.Count -gt 0){$aff[0].serverSite}else{''};$ui.Site2.Text=if($aff.Count -gt 1){$aff[1].serverSite}else{''}

        $vrows=@();foreach($v in @($n.vdsSpecs)){$vrows+=@{OriginalJson=(Json-Text $v);Name=$v.name;MTU=$v.mtu;Nsx=($null -ne $v.nsxtSwitchConfig);Mode=$v.nsxtSwitchConfig.hostSwitchOperationalMode;IpAssignment=$v.nsxtSwitchConfig.ipAssignmentType;PortGroupsJson=(Json-Text @($v.portGroupSpecs));ZonesJson=(Json-Text @($v.nsxtSwitchConfig.transportZones));NiocJson=(Json-Text @($v.niocBandwidthAllocationSpecs|Where-Object{$null -ne $_}));LagJson=(Json-Text @($v.lagSpecs|Where-Object{$null -ne $_}))}}
        Set-Rows 'VdsGrid' $vrows
        foreach($pair in @(@('PoolGrid',@($n.nsxClusterSpec.nsxTClusterSpec.ipAddressPoolsSpec)),@('UplinkGrid',@($n.nsxClusterSpec.nsxTClusterSpec.uplinkProfiles)),@('ProfileGrid',@($n.networkProfiles)))){
            $rows=@();foreach($o in $pair[1]){if($null -ne $o){$rows+=@{Name=$o.name;DefinitionJson=(Json-Text $o)}}};Set-Rows $pair[0] $rows
        }
        $fields=[Collections.Generic.List[object]]::new();Flatten-Fields $spec '' $fields;Set-Rows 'FieldGrid' $fields
        Build-HostRows $c.hostSpecs
        $script:FormsStale=$false;$script:ViewDirty=$false;$script:DirtySections.Clear();$ui.Status.Text='Forms synchronized - validation required after edits'
    } finally {$script:LoadingForms=$false}
}
function Build-HostRows($SelectedHosts) {
    $rows=@()
    foreach($h in @($script:Cache.AvailableHosts|Where-Object {$null -ne $_})){
        $id=[string](First-Value $h @('id','hostId'));$existing=@($SelectedHosts|Where-Object {$_.id -eq $id})
        $pick=if($existing.Count){$existing[0]}else{$null}
        $rows+=@{Use=($null -ne $pick);Id=$id;FQDN=[string](First-Value $h @('fqdn','hostname','hostName'));Status=[string](First-Value $h @('status','state'));StorageType=[string](First-Value $h @('datastoreType','storageType','vsanType'));NetworkPool=if($h.networkpool.name){[string]$h.networkpool.name}else{[string](First-Value $h @('networkPoolName','networkPoolId'))};AZ=$pick.azName;Profile=$pick.hostNetworkSpec.networkProfileName;NicsJson=if($pick){Json-Text @($pick.hostNetworkSpec.vmNics)}else{'[]'}}
    }
    Set-Rows 'HostGrid' $rows
}
function Discover-Sddc {
    if($script:ViewDirty){throw 'Apply or discard staged edits before refreshing inventory.'}
    $cache=@{}
    foreach($pair in @(@('Domains','/v1/domains'),@('Clusters','/v1/clusters'),@('Hosts','/v1/hosts'),@('Images','/v1/personalities'))){$cache[$pair[0]]=@(Get-List $pair[1]);Save-Response ('inventory-'+$pair[0]) $cache[$pair[0]]}
    $available=@()
    foreach($h in $cache.Hosts){
        $cluster=[string]$h.clusterId;if(-not $cluster){$cluster=[string]$h.cluster.id}
        $status=(@($h.status,$h.state,$h.assignmentState,$h.usabilityStatus)|Where-Object{$_}) -join ' '
        if(-not $cluster -and $status -match '(?i)UNASSIGNED' -and $status -match '(?i)USEABLE|USABLE|READY' -and $status -notmatch '(?i)UNUSABLE|UNUSEABLE|ERROR|FAILED'){$available+=$h}
    }
    $cache.AvailableHosts=$available;$script:Cache=$cache;$script:InventoryBase=Get-Base
    Fill-Choice 'DomainChoice' $cache.Domains @('name') @('id')
    Fill-Choice 'ImageChoice' $cache.Images @('personalityName','name') @('personalityId','id')
    Initialize-StorageCascade
    if($ui.Editor.Text){Reload-Forms}else{Build-HostRows @()}
    Write-Log "Discovery complete: $($available.Count) explicitly unassigned usable host candidates. Commissioning type, version, NIC readiness and target-domain compatibility still require review."
}
function Discover-Vcenter {
    Import-Module VMware.VimAutomation.Core -ErrorAction Stop
    Import-Module VMware.VimAutomation.Vds -ErrorAction Stop
    if($ui.SkipTls.IsChecked){Set-PowerCLIConfiguration -Scope Session -InvalidCertificateAction Ignore -Confirm:$false|Out-Null}
    else{Set-PowerCLIConfiguration -Scope Session -InvalidCertificateAction Fail -Confirm:$false|Out-Null}
    $cred=[pscredential]::new($ui.VcUser.Text.Trim(),$ui.VcPass.SecurePassword)
    $script:Vc=Connect-VIServer -Server $ui.VcHost.Text.Trim() -Credential $cred -ErrorAction Stop
    $ui.VcPass.Clear()
    $dcs=@(Get-Datacenter -Server $script:Vc);$switches=@(Get-VDSwitch -Server $script:Vc)
    Fill-Choice 'DcChoice' $dcs @('Name') @('Id');Fill-Choice 'VdsChoice' $switches @('Name') @('Id')
    $script:VcInventory=@{Datacenters=$dcs;Switches=$switches}
    $script:FaultDomainCache=@{}
    Import-Module VMware.VimAutomation.Storage -ErrorAction Stop
    foreach($dc in $dcs){
        foreach($cl in @(Get-Cluster -Location $dc -Server $script:Vc)){
            $key=[string]$cl.ExtensionData.MoRef.Value
            try {
                $names=@(Get-VsanFaultDomain -Cluster $cl -Server $script:Vc -ErrorAction Stop|Select-Object -ExpandProperty Name|Sort-Object -Unique)
                $script:FaultDomainCache[$key]=@{Names=$names;DatacenterMorId=[string]$dc.ExtensionData.MoRef.Value;DatacenterName=[string]$dc.Name;ClusterName=[string]$cl.Name}
            }catch{Write-Log ('Fault-domain read unavailable for cluster '+$cl.Name+'. Inspect vCenter permissions / vSAN configuration.')}
        }
    }

    Write-Log 'vCenter datacenters and vDS templates discovered. Target domain/vCenter correspondence must be confirmed by the operator.'
}
function Discover-Nsx {
    $hostText=$ui.NsxHost.Text.Trim();if($hostText -notmatch '^[A-Za-z0-9][A-Za-z0-9.-]*$'){throw 'Enter NSX FQDN only.'}
    $script:NsxCredential=[pscredential]::new($ui.NsxUser.Text.Trim(),$ui.NsxPass.SecurePassword);$script:NsxBase='https://'+$hostText
    $ui.NsxPass.Clear()
    # Manager-plane objects are mapped conservatively; raw snapshots remain available.
    $pools=@(Get-List '/api/v1/pools/ip-pools' -Nsx)
    $rawProfiles=@(Get-List '/api/v1/host-switch-profiles' -Nsx)
    Save-Response 'nsx-host-switch-profiles-raw' $rawProfiles
    $profiles=@($rawProfiles|Where-Object {$_.resource_type -eq 'UplinkHostSwitchProfile'})
    $zones=@(Get-List '/api/v1/transport-zones' -Nsx)
    Fill-Choice 'NsxPoolChoice' $pools @('display_name','name') @('id')
    Fill-Choice 'NsxUplinkChoice' $profiles @('display_name','name') @('id')
    Fill-Choice 'NsxZoneChoice' $zones @('display_name','name') @('id')
    Save-Response 'nsx-pools' $pools;Save-Response 'nsx-uplink-profiles' $profiles;Save-Response 'nsx-transport-zones' $zones
    Write-Log 'Read-only NSX discovery completed. If manager-plane endpoints are unavailable, stop and compare installed NSX API; no alternate mutation is attempted.'
}
function Import-NsxPool {
    Need-CurrentForms;$o=Selected-Object 'NsxPoolChoice';$subnets=@()
    foreach($sub in @($o.subnets)){
        $ranges=@();foreach($r in @($sub.allocation_ranges)){$ranges+=@{start=$r.start;end=$r.end}}
        if(-not $sub.cidr -or -not $sub.gateway_ip -or $ranges.Count -eq 0){throw 'Pool subnet cannot be mapped safely. Inspect the raw response; no partial definition imported.'}
        $subnets+=@{cidr=$sub.cidr;gateway=$sub.gateway_ip;ipAddressPoolRanges=$ranges}
    }
    if($subnets.Count -eq 0){throw 'No static pool subnets found.'}
    $obj=@{name=('REPLACE_NEW_'+[string](First-Value $o @('display_name','name')));subnets=$subnets}
    $ui.PoolGrid.ItemsSource.Add([pscustomobject]@{Name=$obj.name;DefinitionJson=(Json-Text $obj)});Mark-Dirty
    Write-Log 'Imported pool as a clone candidate. Rename and replace address ranges; existing ranges are NOT available-address recommendations.'
}
function Import-NsxUplink {
    Need-CurrentForms;$o=Selected-Object 'NsxUplinkChoice'
    if(-not $o.teaming -or $null -eq $o.transport_vlan){throw 'Profile cannot be mapped safely. Inspect raw response.'}
    $teams=@();foreach($t in (@($o.teaming)+@($o.named_teamings|Where-Object{$null -ne $_}))){
        $active=@($t.active_list|ForEach-Object {$_.uplink_name});$standby=@($t.standby_list|ForEach-Object {$_.uplink_name})
        if(-not $t.policy -or $active.Count -eq 0){throw 'Missing teaming policy or active uplinks.'}
        $team=@{policy=$t.policy;activeUplinks=$active;standByUplinks=$standby};if($t.name){$team.name=$t.name};$teams+=$team
    }
    $obj=@{name=('REPLACE_NEW_'+[string](First-Value $o @('display_name','name')));transportVlan=[int]$o.transport_vlan;teamings=$teams}
    $ui.UplinkGrid.ItemsSource.Add([pscustomobject]@{Name=$obj.name;DefinitionJson=(Json-Text $obj)});Mark-Dirty
}
function Edit-DefinitionRow([string]$Key) {
    Need-CurrentForms;$row=$ui[$Key].SelectedItem;if(-not $row){throw 'Select a row first.'}
    $obj=Show-JsonObject ('Edit '+$Key) (Parse-Json $row.DefinitionJson)
    if($null -ne $obj){$row.DefinitionJson=Json-Text $obj;$row.Name=$obj.name;$ui[$Key].Items.Refresh();Mark-Dirty}
}
function Add-DefinitionRow([string]$Key) {
    Need-CurrentForms
    $obj=switch($Key){
        'PoolGrid' {@{name='REPLACE_NEW_POOL';subnets=@(@{cidr='REPLACE_CIDR';gateway='REPLACE_GATEWAY';ipAddressPoolRanges=@(@{start='REPLACE_START';end='REPLACE_END'})})}}
        'UplinkGrid' {@{name='REPLACE_NEW_UPLINK_PROFILE';transportVlan=0;teamings=@(@{policy='LOADBALANCE_SRCID';activeUplinks=@('uplink1','uplink2');standByUplinks=@()})}}
        'ProfileGrid' {@{name='REPLACE_NETWORK_PROFILE';isDefault=$false;nsxtHostSwitchConfigs=@(@{vdsName='REPLACE_VDS';ipAddressPoolName='REPLACE_POOL';uplinkProfileName='REPLACE_UPLINK_PROFILE';vdsUplinkToNsxUplink=@(@{vdsUplinkName='uplink1';nsxUplinkName='uplink1'},@{vdsUplinkName='uplink2';nsxUplinkName='uplink2'})})}}
    }
    $ui[$Key].ItemsSource.Add([pscustomobject]@{Name=$obj.name;DefinitionJson=(Json-Text $obj)});Mark-Dirty
}
# Additional cross-reference checks, no assertion of live network readiness.
function Assert-References($Spec) {
    $n=$Spec.computeSpec.clusterSpecs[0].networkSpec
    $vds=@($n.vdsSpecs.name);$pools=@($n.nsxClusterSpec.nsxTClusterSpec.ipAddressPoolsSpec.name);$ups=@($n.nsxClusterSpec.nsxTClusterSpec.uplinkProfiles.name)
    foreach($names in @($vds,$pools,$ups,@($n.networkProfiles.name))){if(@($names|Sort-Object -Unique).Count -ne @($names).Count){throw 'Duplicate names in a network definition collection.'}}
    foreach($p in @($n.networkProfiles|Where-Object {$null -ne $_})){
        foreach($h in @($p.nsxtHostSwitchConfigs|Where-Object {$null -ne $_})){
            if($h.vdsName -notin $vds){throw 'Network profile references an unknown vDS.'}
            if($h.ipAddressPoolName){if($h.ipAddressPoolName -notin $pools){throw 'Static pool reference has no matching definition.'}}else{
                $sw=@($n.vdsSpecs|Where-Object {$_.name -eq $h.vdsName})
                if($sw.Count -ne 1 -or -not $sw[0].nsxtSwitchConfig.ipAssignmentType){throw 'No static pool: an explicit installed-schema-verified DHCP assignment type is required.'}
            }
            if($h.uplinkProfileName -notin $ups){throw 'Network profile references an unknown uplink definition.'}
            if(@($h.vdsUplinkToNsxUplink).Count -eq 0){throw 'vDS-to-NSX uplink mapping is required.'}
        }
    }
    foreach($pool in @($n.nsxClusterSpec.nsxTClusterSpec.ipAddressPoolsSpec|Where-Object {$null -ne $_})){
        foreach($sub in @($pool.subnets|Where-Object {$null -ne $_})){
            $gw=$null;if(-not [Net.IPAddress]::TryParse([string]$sub.gateway,[ref]$gw)){throw 'Invalid TEP gateway IP.'}
            if($sub.cidr -notmatch '^.+/\d{1,3}$'){throw 'Invalid TEP CIDR format.'}
            foreach($range in @($sub.ipAddressPoolRanges)){
                $start=$null;$end=$null
                if(-not [Net.IPAddress]::TryParse([string]$range.start,[ref]$start) -or -not [Net.IPAddress]::TryParse([string]$range.end,[ref]$end)){throw 'Invalid static TEP range endpoint.'}
            }
        }
    }
    Write-Log 'Network name references and basic address formats passed. No IP availability, overlap, routing, bandwidth, MTU or site-health assertion is made.'
}
# Initialize empty collection-backed grids so Add works before discovery.
foreach($key in @('HostGrid','VdsGrid','PoolGrid','UplinkGrid','ProfileGrid','FieldGrid')){Set-Rows $key @()}
foreach($key in @('ClusterName','AssignProfile')){$ui[$key].Add_TextChanged({Mark-Dirty})}
$ui.DomainChoice.Add_SelectionChanged({Mark-Dirty});$ui.ImageChoice.Add_SelectionChanged({Mark-Dirty})
$ui.NsxHost.Add_TextChanged({$script:NsxCredential=$null})
$script:Window.Add_Closed({$script:NsxCredential=$null;if($script:Vc){Disconnect-VIServer -Server $script:Vc -Confirm:$false -ErrorAction SilentlyContinue}})
Write-Log 'Ready v3 single-site test build. Load starter, discover inventory, configure forms, Apply each edited tab, Generate / Validate / Execute. Original stretch utility is unchanged.'

$dcBar=New-Bar $general
$null=Add-Button $dcBar 'Apply selected datacenter' {Invoke-UiAction {
    $spec=Current-Spec;$dc=Selected-Object 'DcChoice'
    if(-not $dc.Name){throw 'Select a discovered datacenter from the target-domain vCenter.'}
    $spec.computeSpec.clusterSpecs[0].datacenterName=[string]$dc.Name;Commit-Spec $spec
    $ui.DatacenterApplyStatus.Text='Saved datacenter '+[string]$dc.Name+' to creation JSON. No live infrastructure was changed.';$ui.DatacenterApplyStatus.Foreground='#87D8B0'
    Write-Log ('Applied datacenter '+[string]$dc.Name+' to creation JSON.')
}}
Add-Text $storage 'Single-site compute: isStretched=false. No primaryAzName, host azName or clientSite. Server storage may be standard or stretched and is not modified.'
Add-Text $switchTab 'MTU LIMITATION: vDS MTU is configurable here. Separate management=1500 and vMotion/vSAN=9000 VMkernel MTUs are NOT configured by this package. Confirm the supported workflow before deployment.'


# v3.5.9-complete cascading storage inventory. Uses SDDC cluster metadata, not guessed IDs.
$script:StorageCascadeLoading=$false
$script:StorageScopeBase=$null
function Clear-StorageCascade {
    $script:StorageScopeBase=$null
    if($ui.ContainsKey('ServerCluster')){$ui.ServerCluster.Text=''}
    foreach($key in @('StorageVcChoice','StorageDcChoice','StorageClusterChoice','DsChoice')){
        if($ui.ContainsKey($key)){$ui[$key].Items.Clear();$ui[$key].SelectedIndex=-1}
    }
}
function Add-InventoryChoice([string]$Key,[string]$Label,$Object) {
    $item=[Windows.Controls.ComboBoxItem]::new();$item.Content=$Label;$item.Tag=$Object
    $null=$ui[$Key].Items.Add($item)
}
function Reset-StorageTarget {
    if($ui.ContainsKey('StorageSiteChoice')){$ui.StorageSiteChoice.Items.Clear();$ui.Site1.Text='';$script:SiteScopeClusterId=$null;Invalidate}
    $ui.ServerCluster.Text='';$ui.DsChoice.Items.Clear();$ui.DsChoice.SelectedIndex=-1
    $script:Cache.Datastores=@()
}
function Initialize-StorageCascade {
    $script:StorageCascadeLoading=$true
    try {
        Clear-StorageCascade
        $script:StorageScopeBase=Get-Base
        $vcs=@($script:Cache.Clusters|Where-Object {$_.vcenter.fqdn}|ForEach-Object {$_.vcenter.fqdn}|Sort-Object -Unique)
        foreach($vc in $vcs){Add-InventoryChoice 'StorageVcChoice' ([string]$vc) ([pscustomobject]@{Fqdn=[string]$vc})}
        if($vcs.Count -eq 0){Write-Log 'SDDC cluster response contains no vcenter.fqdn metadata. Cascade cannot safely scope inventory. Inspect saved cluster JSON; no name-only ID matching is attempted.'}
        else{Write-Log "Storage selector loaded $($vcs.Count) vCenter scope(s). Choose storage vCenter, datacenter, then existing storage cluster."}
    } finally {$script:StorageCascadeLoading=$false}
}
function Populate-StorageDatacenters {
    Require-Inventory
    $vc=Selected-Object 'StorageVcChoice'
    Reset-StorageTarget;$ui.StorageDcChoice.Items.Clear();$ui.StorageClusterChoice.Items.Clear()
    $clusters=@($script:Cache.Clusters|Where-Object {$_.vcenter.fqdn -eq $vc.Fqdn})
    $groups=@($clusters|Where-Object {$_.datacenter.name}|Group-Object {$_.datacenter.morId+'|'+$_.datacenter.name})
    foreach($group in $groups){
        $dc=$group.Group[0].datacenter
        Add-InventoryChoice 'StorageDcChoice' ([string]$dc.name) ([pscustomobject]@{Name=[string]$dc.name;MorId=[string]$dc.morId;VcFqdn=[string]$vc.Fqdn})
    }
    if($groups.Count -eq 0){Write-Log 'No datacenter metadata for the selected storage vCenter. No unscoped cluster fallback is offered.'}
}
function Populate-StorageClusters {
    Require-Inventory
    $dc=Selected-Object 'StorageDcChoice'
    Reset-StorageTarget;$ui.StorageClusterChoice.Items.Clear()
    $scopedClusters=@($script:Cache.Clusters|Where-Object {
        $_.vcenter.fqdn -eq $dc.VcFqdn -and $_.datacenter.name -eq $dc.Name -and
        (-not $dc.MorId -or $_.datacenter.morId -eq $dc.MorId)
    }|Sort-Object name)
    foreach($cluster in $scopedClusters){
        $type=[string]$cluster.primaryDatastoreType
        $stretch=if($cluster.isStretched -eq $true){'stretched'}elseif($cluster.isStretched -eq $false){'not stretched'}else{'stretch state unknown'}
        Add-InventoryChoice 'StorageClusterChoice' ("{0} | {1} | {2}" -f $cluster.name,$type,$stretch) $cluster
    }
    Write-Log "Loaded $($scopedClusters.Count) existing SDDC cluster(s) in selected vCenter/datacenter. Select the storage server; eligibility is not inferred from presence."
}

function Expand-DatastoreRecords($Value) {
    if($null -eq $Value){return}
    if($Value -is [array] -or $Value -is [System.Collections.IList]){
        foreach($entry in $Value){Expand-DatastoreRecords $entry};return
    }
    foreach($key in @('elements','results')){
        $has=if($Value -is [System.Collections.IDictionary]){$Value.Contains($key)}else{$null -ne $Value.PSObject.Properties[$key]}
        if($has){Expand-DatastoreRecords $Value.$key;return}
    }
    if($Value.datastoreType -eq 'VSAN' -and $Value.id -and $Value.name){Write-Output $Value}
}
function Get-SelectedServerState {
    if(-not $ui.StorageClusterChoice.SelectedItem){throw 'Select the existing storage server first.'}
    $c=$ui.StorageClusterChoice.SelectedItem.Tag
    if($c.isStretched -isnot [bool]){throw 'Storage server stretch state is unknown. Refresh inventory; no state is assumed.'}
    return $c
}

function Read-SelectedStorageDatastores {
    Require-Inventory
    if($script:StorageScopeBase -ne (Get-Base)){throw 'Refresh SDDC inventory for this endpoint first.'}
    $cluster=Selected-Object 'StorageClusterChoice'
    $id=[string]$cluster.id
    if([string]::IsNullOrWhiteSpace($id)){throw 'Selected SDDC cluster has no ID. Inspect the inventory response.'}
    $ui.ServerCluster.Text=$id
    $ui.DsChoice.Items.Clear()
    $raw=Invoke-Api 'GET' ('/v1/clusters/'+[Uri]::EscapeDataString($id)+'/datastores')
    Save-Response 'raw-selected-cluster-datastores' $raw
    $ds=@(Expand-DatastoreRecords $raw)
    if($ds.Count -eq 0){
        $ui.StorageDiscoveryStatus.Text='No VSAN datastore records with UUID id/name were recognized in the SDDC response for '+$cluster.name+'. Raw response saved. Check selected server, SDDC inventory and permissions; no UUID was fabricated.'
        Write-Log $ui.StorageDiscoveryStatus.Text
    }else{$ui.StorageDiscoveryStatus.Text='Discovered '+$ds.Count+' datastore(s). Select one, then Apply remote datastore.'}

    $ds=@(Expand-DatastoreRecords $ds)
    $script:Cache.Datastores=$ds
    Fill-Choice 'DsChoice' $ds @('name','datastoreName') @('id','datastoreUuid')
    Save-Response 'discovered-datastores' $ds
    Write-Log "Discovered $($ds.Count) datastore result(s) for selected storage server '$($cluster.name)'. Select and Apply the remote vSAN datastore on Storage / Topology."
    foreach($tab in $ui.MainTabs.Items){if([string]$tab.Header -eq '2 Storage / Topology'){$ui.MainTabs.SelectedItem=$tab;break}}
}
$ui.ServerCluster.IsReadOnly=$true
$ui.ServerCluster.ToolTip='SDDC cluster ID is populated from the selected existing storage cluster. This is not a vCenter MoRef.'
$ui.Datastores.Content='Read selected cluster datastores'
$ui.StorageVcChoice.Add_SelectionChanged({
    if(-not $script:StorageCascadeLoading -and $ui.StorageVcChoice.SelectedItem){Invoke-UiAction {Populate-StorageDatacenters}}
})
$ui.StorageDcChoice.Add_SelectionChanged({
    if(-not $script:StorageCascadeLoading -and $ui.StorageDcChoice.SelectedItem){Invoke-UiAction {Populate-StorageClusters}}
})
$ui.StorageClusterChoice.Add_SelectionChanged({
    if(-not $script:StorageCascadeLoading){
        Reset-StorageTarget
        if($ui.StorageClusterChoice.SelectedItem){$ui.ServerCluster.Text=[string]$ui.StorageClusterChoice.SelectedItem.Tag.id;Populate-StorageSites}
    }
})
Add-Text $storage 'Choose storage vCenter > datacenter > existing storage cluster. These scopes come from SDDC inventory metadata. The selected cluster ID is populated automatically; the new compute cluster name is a separate field on General / Image. Changing storage scope clears the datastore dropdown, but does not silently rewrite the already committed payload: explicitly Apply the new datastore.'


# v3.5.9-complete Connections-first workflow and server fault-domain selection.
$script:FaultDomainCache=if($script:FaultDomainCache){$script:FaultDomainCache}else{@{}}
$script:ConnectionReady=@{SDDC=$false;vCenter=$false;NSX=$false}
$script:SiteScopeClusterId=$null
function Move-ConnectionRow($Control,$Destination){
    $row=$Control.Parent
    if($row.Parent -isnot [Windows.Controls.Panel]){throw 'Unexpected credential row parent.'}
    $row.Parent.Children.Remove($row)
    [Windows.Controls.DockPanel]::SetDock($row,'Top')
    $null=$Destination.Children.Add($row)
}
function Reset-ConnectionReadiness {
    if($script:ConnectingAll){return}
    foreach($key in @('SDDC','vCenter','NSX')){$script:ConnectionReady[$key]=$false}
    if($ui.ContainsKey('NextConfiguration')){$ui.NextConfiguration.IsEnabled=$false}
    Invalidate
}
function Set-ConnectionStatus([string]$Key,[string]$Message,[bool]$Success){
    $script:ConnectionReady[$Key]=$Success
    $ui[('Connection'+$Key)].Text=$Key+': '+$Message
    $ui[('Connection'+$Key)].Foreground=if($Success){'#87D8B0'}else{'#FFD166'}
}
function Populate-StorageSites {
    $ui.StorageSiteChoice.Items.Clear();$ui.Site1.Text='';$script:SiteScopeClusterId=$null
    if(-not $ui.StorageClusterChoice.SelectedItem){return}
    $cluster=$ui.StorageClusterChoice.SelectedItem.Tag
    $standard=($cluster.isStretched -is [bool] -and -not $cluster.isStretched)
    $ui.StorageSiteChoice.IsEnabled=(-not $standard);$ui.Topology.IsEnabled=(-not $standard)
    if($standard){
        $item=[Windows.Controls.ComboBoxItem]::new();$item.Content='Not applicable: non-stretched storage server';$null=$ui.StorageSiteChoice.Items.Add($item);$ui.StorageSiteChoice.SelectedIndex=0
        $ui.StorageDiscoveryStatus.Text='Standard vSAN server: topology/site affinity are not applicable. Select the datastore and Apply remote datastore; no separate topology Apply is needed.'
        $script:SiteScopeClusterId=[string]$cluster.id
        return
    }
    $vcFqdn=[string]$cluster.vcenter.fqdn
    if(-not $script:Vc -or -not $script:Vc.IsConnected -or [string]$script:Vc.Name -ne $vcFqdn){
        Write-Log 'Fault-domain discovery requires a connection to the selected STORAGE server vCenter. Enter that vCenter on Connections and rerun Connect & Discover. No site names are guessed.';return
    }
    $mor=[string](First-Value $cluster @('managedObjectReferenceId','morId'))
    if($mor){
        try{
            $vcCluster=Get-Cluster -Id ('ClusterComputeResource-'+$mor) -Server $script:Vc -ErrorAction Stop
            $domains=@(Get-VsanFaultDomain -Cluster $vcCluster -Server $script:Vc -ErrorAction Stop|Select-Object -ExpandProperty Name|Sort-Object -Unique)
            $dc=Get-Datacenter -Id ('Datacenter-'+[string]$cluster.datacenter.morId) -Server $script:Vc -ErrorAction Stop
            $script:FaultDomainCache[$mor]=@{Names=$domains;DatacenterMorId=[string]$dc.ExtensionData.MoRef.Value;ClusterName=[string]$vcCluster.Name}
        }catch{Write-Log ('Live fault-domain refresh failed for '+$cluster.name+': '+$_.Exception.Message)}
    }
    if(-not $mor -or -not $script:FaultDomainCache.ContainsKey($mor)){
        Write-Log 'Selected SDDC cluster has no matching vCenter cluster MoRef in the fault-domain cache. No name-only matching is used.';return
    }
    $entry=$script:FaultDomainCache[$mor]
    if($entry.ClusterName -ne $cluster.name -or ($cluster.datacenter.morId -and $entry.DatacenterMorId -ne $cluster.datacenter.morId)){
        Write-Log 'Cluster/datacenter metadata differs between SDDC and vCenter. Site selection is blocked.';return
    }
    foreach($name in @($entry.Names)){
        $item=[Windows.Controls.ComboBoxItem]::new();$item.Content=[string]$name;$null=$ui.StorageSiteChoice.Items.Add($item)
    }
    $script:SiteScopeClusterId=[string]$cluster.id
    if($ui.StorageSiteChoice.Items.Count -eq 0){$ui.StorageDiscoveryStatus.Text='No vSAN fault domains discovered for '+$cluster.name+'. SDDC reports stretched='+[string]$cluster.isStretched+'. Verify the selected storage server; do not create a site name.'}
    Write-Log ('Discovered '+$ui.StorageSiteChoice.Items.Count+' storage fault-domain choice(s). Choose the site physically local to the new compute hosts; no locality inference is made.')
}
$connections=New-PanelTab 'Connections / Inventory'
$connectionTab=$connections.Parent
$ui.MainTabs.Items.Remove($connectionTab);$ui.MainTabs.Items.Insert(0,$connectionTab)
$connections.LastChildFill=$false
Add-Text $connections 'Step 1 | Enter all credentials, then Connect & Discover. SDDC inventory, vCenter datacenters/switches/fault domains and NSX pools/profiles/zones are gathered in one foreground operation. No cluster creation is submitted.'
Add-Text $connections 'SDDC Manager'
Move-ConnectionRow $ui.Server $connections
$ui.Connect.Visibility='Collapsed'
Add-Text $connections 'vCenter (use the storage-server vCenter for fault-domain discovery)'
$vcRow=$ui.VcHost.Parent
foreach($child in @($vcRow.Children)){if($child -is [Windows.Controls.Button]){$child.Visibility='Collapsed'}}
Move-ConnectionRow $ui.VcHost $connections
Add-Text $connections 'NSX Manager'
$nsxRow=$ui.NsxHost.Parent
foreach($child in @($nsxRow.Children)){if($child -is [Windows.Controls.Button]){$child.Visibility='Collapsed'}}
Move-ConnectionRow $ui.NsxHost $connections
Move-ConnectionRow $ui.SkipTls $connections
$actionBar=New-Bar $connections
$null=Add-Button $actionBar 'Connect & Discover All' {Invoke-UiAction {
    if($script:ViewDirty){throw 'Apply or discard pending configuration edits before reconnecting.'}
    foreach($key in @('Server','User','VcHost','VcUser','NsxHost','NsxUser')){if([string]::IsNullOrWhiteSpace($ui[$key].Text)){throw 'Complete SDDC, vCenter and NSX endpoint/user fields on Connections.'}}
    foreach($key in @('Password','VcPass','NsxPass')){if($ui[$key].SecurePassword.Length -eq 0){throw 'Enter all three passwords before Connect & Discover. Password boxes are cleared after successful authentication.'}}
    Reset-ConnectionReadiness
    $script:ConnectingAll=$true
    $script:Token=$null;Clear-StorageCascade;$script:FaultDomainCache=@{}
    if($script:Vc){Disconnect-VIServer -Server $script:Vc -Confirm:$false -ErrorAction SilentlyContinue;$script:Vc=$null}
    $script:NsxCredential=$null
    foreach($key in @('NsxPoolChoice','NsxUplinkChoice','NsxZoneChoice','DcChoice','VdsChoice')){$ui[$key].Items.Clear()}
    try{
        $t=Invoke-Api 'POST' '/v1/tokens' @{username=$ui.User.Text.Trim();password=$ui.Password.Password} -Anonymous
        if(-not $t.accessToken){throw 'No SDDC token returned.'}
        $script:Token=$t.accessToken;$script:Base=Get-Base;$ui.Password.Clear()
        Discover-Sddc
        Set-ConnectionStatus 'SDDC' 'Connected; inventory loaded' $true
    }catch{Set-ConnectionStatus 'SDDC' 'Connection or discovery failed; inspect log' $false;Write-Log $_.Exception.Message}
    try{Discover-Vcenter;Set-ConnectionStatus 'vCenter' 'Connected; inventory loaded (fault-domain read warnings may appear in log)' $true}
    catch{Set-ConnectionStatus 'vCenter' 'Connection or discovery failed; inspect log' $false;Write-Log $_.Exception.Message}
    try{Discover-Nsx;Set-ConnectionStatus 'NSX' 'Connected; inventory loaded' $true}
    catch{Set-ConnectionStatus 'NSX' 'Connection or discovery failed; inspect log' $false;Write-Log 'NSX discovery failed. Verify endpoint, credentials, permissions and installed API compatibility.'}
    $script:ConnectingAll=$false
    $all=$script:ConnectionReady.SDDC -and $script:ConnectionReady.vCenter -and $script:ConnectionReady.NSX
    $ui.NextConfiguration.IsEnabled=($all -and -not [string]::IsNullOrWhiteSpace($ui.Editor.Text));if(Get-Command Update-StartReadiness -ErrorAction SilentlyContinue){Update-StartReadiness}
    $ui.Status.Text=if($all){'Connections and discovery completed. Continue to configuration.'}else{'Discovery incomplete. Review service status and log; re-enter passwords before retry.'}
}}
$ui.NextConfiguration=Add-Button $actionBar 'Next: General / Image' {
    if([string]::IsNullOrWhiteSpace($ui.Editor.Text)){throw 'Load a starter or existing creation JSON on Connections first.'};if($script:ConnectionReady.SDDC -and $script:ConnectionReady.vCenter -and $script:ConnectionReady.NSX){$ui.MainTabs.SelectedItem=$general.Parent}
}
$ui.NextConfiguration.IsEnabled=$false
foreach($key in @('SDDC','vCenter','NSX')){
    $t=[Windows.Controls.TextBlock]::new();$t.Text=$key+': Not connected';$t.Margin='6';$t.Foreground='#FFD166'
    [Windows.Controls.DockPanel]::SetDock($t,'Top');$null=$connections.Children.Add($t);$ui[('Connection'+$key)]=$t
}
Add-Text $connections 'Connection profiles can save encrypted passwords using the separate profile controls. Successful logins clear password boxes. Endpoint or credential edits invalidate readiness. Connections run sequentially in this foreground action; partial failures remain visible here.'
# Remove scattered discovery actions, while retaining the underlying functions.
foreach($panel in @($general,$nsxTab)){
    foreach($row in @($panel.Children)){
        if($row -is [Windows.Controls.Panel]){
            foreach($child in @($row.Children)){
                if($child -is [Windows.Controls.Button] -and [string]$child.Content -in @('Discover SDDC inventory','Connect / discover NSX')){$child.Visibility='Collapsed'}
            }
        }
    }
}
$ui.Inventory.Visibility='Collapsed'
# Move topology controls off the global header to Storage / Topology.
$topologyRow=$ui.Topology.Parent
$topologyRow.Parent.Children.Remove($topologyRow)
[Windows.Controls.DockPanel]::SetDock($topologyRow,'Top');$storage.Children.Insert(0,$topologyRow)
$siteBar=New-Bar $storage
$null=Add-Input $siteBar 'Local storage site (server fault domain)' 'StorageSiteChoice' 460 -Choice
$ui.StorageSiteChoice.IsEditable=$false
$null=Add-Button $siteBar 'Refresh storage-site choices' {Invoke-UiAction {Populate-StorageSites}}
$ui.Site1.Visibility='Collapsed'
$parent=$ui.Site1.Parent;$index=$parent.Children.IndexOf($ui.Site1)
if($index -gt 0 -and $parent.Children[$index-1] -is [Windows.Controls.TextBlock]){$parent.Children[$index-1].Visibility='Collapsed'}
$ui.StorageSiteChoice.Add_SelectionChanged({
    if($ui.StorageSiteChoice.SelectedItem){$ui.Site1.Text=[string]$ui.StorageSiteChoice.SelectedItem.Content}else{$ui.Site1.Text=''}
})
Add-Text $storage 'Local storage site is the existing storage-server fault domain to associate with this single-site compute client for Asymmetric connectivity. Choose the physically local storage site. Discovery lists names but does not determine physical locality. Apply topology writes serverSite only; no clientSite is created.'
foreach($key in @('Server','User','VcHost','VcUser','NsxHost','NsxUser')){$ui[$key].Add_TextChanged({Reset-ConnectionReadiness})}
foreach($key in @('Password','VcPass','NsxPass')){$ui[$key].Add_PasswordChanged({Reset-ConnectionReadiness})}
$ui.SkipTls.Add_Click({Reset-ConnectionReadiness;$script:NsxCredential=$null;$script:FaultDomainCache=@{}})
$ui.MainTabs.SelectedItem=$connectionTab


# v3.5.9-complete explicit prerequisite and visible storage diagnostics.
$loadBar=[Windows.Controls.WrapPanel]::new()
foreach($control in @($ui.Load,$ui.Starter)){
    $control.Parent.Children.Remove($control);$null=$loadBar.Children.Add($control)
}
[Windows.Controls.DockPanel]::SetDock($loadBar,'Top');$connections.Children.Insert(0,$loadBar)
$ui.Load.Content='Step 1: Load existing creation JSON'
$ui.Starter.Content='Step 1: Start NEW configuration'
$ui.TemplateStatus=[Windows.Controls.TextBlock]::new();$ui.TemplateStatus.Text='Required: choose a starter or existing creation JSON before continuing.';$ui.TemplateStatus.Foreground='#FFD166';$ui.TemplateStatus.Margin='6'
[Windows.Controls.DockPanel]::SetDock($ui.TemplateStatus,'Top');$connections.Children.Insert(1,$ui.TemplateStatus)
$ui.StorageDiscoveryStatus=[Windows.Controls.TextBlock]::new();$ui.StorageDiscoveryStatus.Text='Select a storage cluster, then Discover selected server datastores. No datastore is selected automatically.';$ui.StorageDiscoveryStatus.Foreground='#FFD166';$ui.StorageDiscoveryStatus.TextWrapping='Wrap';$ui.StorageDiscoveryStatus.Margin='6'
[Windows.Controls.DockPanel]::SetDock($ui.StorageDiscoveryStatus,'Top');$storage.Children.Insert(1,$ui.StorageDiscoveryStatus)
$storage.LastChildFill=$false
function Update-StartReadiness {
    $loaded=$false
    if(-not [string]::IsNullOrWhiteSpace($ui.Editor.Text)){
        try{$obj=ConvertFrom-Json -InputObject $ui.Editor.Text -AsHashtable -Depth 100;$loaded=($obj.Contains('domainId') -and @($obj.computeSpec.clusterSpecs).Count -eq 1)}catch{}
    }
    $ui.TemplateStatus.Text=if($loaded){'Configuration loaded. Connect & Discover, then Next: General / Image.'}else{'Required: choose a starter or existing creation JSON before continuing.'}
    $ui.TemplateStatus.Foreground=if($loaded){'#87D8B0'}else{'#FFD166'}
    $ready=$loaded -and $script:ConnectionReady.SDDC -and $script:ConnectionReady.vCenter -and $script:ConnectionReady.NSX
    $ui.NextConfiguration.IsEnabled=$ready
    foreach($tab in $ui.MainTabs.Items){
        if($tab -ne $connectionTab){$tab.IsEnabled=$loaded}
    }
}
$ui.Editor.Add_TextChanged({Update-StartReadiness})
$ui.Load.Add_Click({Update-StartReadiness;$ui.MainTabs.SelectedItem=$connectionTab})
$ui.Starter.Add_Click({Update-StartReadiness;$ui.MainTabs.SelectedItem=$connectionTab})
$ui.StorageClusterChoice.Add_SelectionChanged({
    if($ui.StorageClusterChoice.SelectedItem){
        $c=$ui.StorageClusterChoice.SelectedItem.Tag
        $ui.StorageDiscoveryStatus.Text='Selected '+$c.name+'. SDDC reported stretched='+[string]$c.isStretched+'. Click Discover selected server datastores; inspect Log for site-discovery details.'
    }
})
Update-StartReadiness


# v3.1 UX extension. Inject immediately before the original ShowDialog.
$script:UxProfileSecrets=@{}
function Save-UxConnectionProfile {
    if(-not $IsWindows){throw 'Connection profiles require Windows DPAPI.'}
    $services=@{}
    foreach($row in @(@('SDDC','Server','User','Password'),@('vCenter','VcHost','VcUser','VcPass'),@('NSX','NsxHost','NsxUser','NsxPass'))){
        $secret=$ui[$row[3]].SecurePassword
        if($secret.Length -eq 0 -and $script:UxProfileSecrets.ContainsKey($row[0])){$secret=$script:UxProfileSecrets[$row[0]]}
        $services[$row[0]]=@{fqdn=$ui[$row[1]].Text.Trim();username=$ui[$row[2]].Text.Trim();passwordDpapi=if($secret.Length){ConvertFrom-SecureString $secret}else{''}}
    }
    $d=[Microsoft.Win32.SaveFileDialog]::new();$d.Filter='Connection profile (*.json)|*.json';$d.FileName='VCF-Connections.json'
    if($d.ShowDialog()){
        $profile=@{kind='VCF-ConnectionProfile';version=1;protection='Windows-DPAPI';services=$services}
        [IO.File]::WriteAllText($d.FileName,(ConvertTo-Json -InputObject $profile -Depth 10),[Text.UTF8Encoding]::new($false))
        Write-Log 'Saved connection profile. Passwords are encrypted; this is separate from the creation JSON. Protect the profile file.'
    }
}
function Load-UxConnectionProfile {
    $d=[Microsoft.Win32.OpenFileDialog]::new();$d.Filter='Connection profile (*.json)|*.json'
    if(-not $d.ShowDialog()){return}
    $profile=ConvertFrom-Json -InputObject ([IO.File]::ReadAllText($d.FileName)) -AsHashtable
    if($profile.kind -ne 'VCF-ConnectionProfile' -or $profile.protection -ne 'Windows-DPAPI'){throw 'Not a supported encrypted connection profile. Use the creation JSON loader for cluster specifications.'}
    # Decrypt everything before changing UI; no partial credential load.
    $decoded=@{}
    foreach($name in @('SDDC','vCenter','NSX')){
        if(-not $profile.services.ContainsKey($name)){throw 'Profile is missing a service.'}
        $entry=$profile.services[$name]
        $decoded[$name]=if($entry.passwordDpapi){ConvertTo-SecureString $entry.passwordDpapi}else{[Security.SecureString]::new()}
    }
    foreach($row in @(@('SDDC','Server','User','Password'),@('vCenter','VcHost','VcUser','VcPass'),@('NSX','NsxHost','NsxUser','NsxPass'))){
        $entry=$profile.services[$row[0]]
        $ui[$row[1]].Text=[string]$entry.fqdn;$ui[$row[2]].Text=[string]$entry.username
        $ui[$row[3]].Password=[pscredential]::new('profile',$decoded[$row[0]]).GetNetworkCredential().Password
    }
    Reset-ConnectionReadiness
    Write-Log 'Loaded connection profile. Verify endpoints and click Connect & Discover All. No login or deployment was performed by loading.'
}
$profileBar=New-Bar $connections
$null=Add-Button $profileBar 'Save connection profile (encrypted passwords)' {Invoke-UiAction {Save-UxConnectionProfile}}
$null=Add-Button $profileBar 'Load connection profile' {Invoke-UiAction {Load-UxConnectionProfile}}
Add-Text $connections 'Connection profile JSON stores FQDNs/usernames and DPAPI-encrypted passwords. Creation JSON is a separate file. Save credentials before connecting, or save later using this session cache. Encrypted profiles are intended for the same Windows account/computer, not portable team secrets.'
# Keep encrypted-save capability after the existing connection functions clear password boxes.
foreach($row in @(@('SDDC','Password'),@('vCenter','VcPass'),@('NSX','NsxPass'))){
    $ui[$row[1]].Tag=$row[0]
    $ui[$row[1]].Add_PasswordChanged({param($sender,$eventArgs)
        $service=[string]$sender.Tag
        if($sender.SecurePassword.Length){
            if($script:UxProfileSecrets.ContainsKey($service)){$script:UxProfileSecrets[$service].Dispose()}
            $script:UxProfileSecrets[$service]=$sender.SecurePassword.Copy()
        }
    })
}
foreach($row in @(@('SDDC','Server','User'),@('vCenter','VcHost','VcUser'),@('NSX','NsxHost','NsxUser'))){
    foreach($key in @($row[1],$row[2])){
        $ui[$key].Tag=$row[0]
        $ui[$key].Add_TextChanged({param($sender,$eventArgs)
            $service=[string]$sender.Tag
            if($script:UxProfileSecrets.ContainsKey($service)){$script:UxProfileSecrets[$service].Dispose();$script:UxProfileSecrets.Remove($service)}
        })
    }
}
$script:Window.Add_Closed({foreach($secret in $script:UxProfileSecrets.Values){$secret.Dispose()};$script:UxProfileSecrets.Clear()})
# Host tab: selection only. Keep original model but hide mapping/profile inputs.
$hostsTab.Parent.Header='3 Host Selection'
foreach($column in $ui.HostGrid.Columns){if([string]$column.Header -in @('ID','Network profile','vmNics JSON (per host)','AZ')){$column.Visibility='Collapsed'}}
foreach($child in @($hostsTab.Children)){
    if($child -is [Windows.Controls.Panel]){
        foreach($control in @($child.Children)){
            if($control -is [Windows.Controls.Button] -and [string]$control.Content -in @('Assign profile to selected rows','Edit selected host NIC fields','Apply checked hosts')){$control.Visibility='Collapsed'}
        }
    }
}
$ui.AssignProfile.Visibility='Collapsed'
if($ui.AssignProfile.Parent){foreach($child in @($ui.AssignProfile.Parent.Children)){if($child -is [Windows.Controls.TextBlock] -and $child.Text -eq 'Network profile'){$child.Visibility='Collapsed'}}}
# Correct observed host inventory field names for the existing grid.
function Refresh-UxHostMetadata {
    foreach($row in @($ui.HostGrid.ItemsSource)){
        $source=@($script:Cache.AvailableHosts|Where-Object {$_.id -eq $row.Id})
        if($source.Count -eq 1){$row.StorageType=[string]$source[0].datastoreType;$row.NetworkPool=[string]$source[0].networkpool.name}
    }
    $ui.HostGrid.Items.Refresh()
}
$hostActions=New-Bar $hostsTab
$hostsTab.Children.Remove($hostActions);$hostsTab.Children.Insert(0,$hostActions)
$null=Add-Button $hostActions 'Refresh host details' {Invoke-UiAction {Refresh-UxHostMetadata}}
$null=Add-Button $hostActions 'Use checked hosts / Next: Distributed Switch' {Invoke-UiAction {
    $null=$ui.HostGrid.CommitEdit();$null=$ui.HostGrid.CommitEdit()
    $selected=@($ui.HostGrid.ItemsSource|Where-Object {$_.Use})
    if(-not $selected.Count){throw 'Check at least one available host. SDDC validation determines supported host count.'}
    $other=@($script:DirtySections|Where-Object {$_ -notin @('3 Hosts / NIC mappings','3 Host Selection')})
    if($other.Count){throw ('Apply pending edits first: '+($other -join ', '))}
    $spec=Current-Spec;$existing=@($spec.computeSpec.clusterSpecs[0].hostSpecs);$new=@()
    foreach($row in $selected){
        $h=@($existing|Where-Object {$_.id -eq $row.Id})
        $item=if($h.Count -eq 1){Copy-Json $h[0]}else{@{id=[string]$row.Id;hostName=[string]$row.FQDN}}
        $item.Remove('azName')|Out-Null;$new+=,$item
    }
    $spec.computeSpec.clusterSpecs[0].hostSpecs=$new
    # Preserve any existing network mapping for the same selected host; do not invent it here.
    $null=$script:DirtySections.Remove('3 Hosts / NIC mappings');$null=$script:DirtySections.Add('3 Host Selection')
    Commit-Spec $spec
    Refresh-UxHostMetadata
    $ui.MainTabs.SelectedItem=$script:UxBasicTab
}}
Add-Text $hostsTab 'Check the hosts only. NIC/uplink mappings are configured on Distributed Switch. Host selection does not invent network profiles or change commissioned network pools. Creation validation remains blocked until networking is complete.'
# Structured switch builder, separate from inherited advanced editors.
$basic=New-PanelTab '4 Distributed Switch'
$basic.LastChildFill=$false
$basicTab=$basic.Parent;$ui.MainTabs.Items.Remove($basicTab)
$oldIndex=$ui.MainTabs.Items.IndexOf($switchTab.Parent);$ui.MainTabs.Items.Insert($oldIndex,$basicTab)
$switchTab.Parent.Header='Advanced vDS / JSON'

$bar=New-Bar $basic
$null=Add-Input $bar 'Switch name' 'UxSwitchName' 280
$null=Add-Input $bar 'vDS MTU' 'UxMtu' 100;$ui.UxMtu.Text='9000'
$null=Add-Input $bar 'Network profile name' 'UxProfile' 260
$bar=New-Bar $basic
$null=Add-Input $bar 'Uplinks (1-8)' 'UxUplinkCount' 100;$ui.UxUplinkCount.Text='2'
$null=Add-Input $bar 'NSX host switch' 'UxNsxMode' 180 -Choice
foreach($value in @('Not on this vDS','NSX on this vDS')){Add-InventoryChoice 'UxNsxMode' $value $value};$ui.UxNsxMode.SelectedIndex=0;$ui.UxNsxMode.IsEditable=$false
$script:UxMappingControls=@()
$mappingPanel=[Windows.Controls.StackPanel]::new();[Windows.Controls.DockPanel]::SetDock($mappingPanel,'Top');$null=$basic.Children.Add($mappingPanel)
function Build-UxMappings {
    $count=0;if(-not [int]::TryParse($ui.UxUplinkCount.Text,[ref]$count) -or $count -lt 1 -or $count -gt 8){throw 'Enter an uplink count from 1 through 8.'}
    $spec=Current-Spec;$mappingPanel.Children.Clear();$script:UxMappingControls=@()
    foreach($hostSpec in @($spec.computeSpec.clusterSpecs[0].hostSpecs)){
        $inventory=@($script:Cache.AvailableHosts|Where-Object {$_.id -eq $hostSpec.id})
        if($inventory.Count -ne 1){throw 'A selected host is absent from current available-host inventory. Refresh inventory and select hosts again.'}
        $nics=@($inventory[0].physicalNics.deviceName|Sort-Object -Unique)
        if($nics.Count -lt $count){throw 'Selected host has fewer discovered NICs than requested uplinks.'}
        $row=[Windows.Controls.WrapPanel]::new();$null=$mappingPanel.Children.Add($row)
        $label=[Windows.Controls.TextBlock]::new();$label.Text=[string]$inventory[0].fqdn;$label.Margin='6';$null=$row.Children.Add($label)
        for($i=1;$i -le $count;$i++){
            $label=[Windows.Controls.TextBlock]::new();$label.Text='uplink'+$i;$label.Margin='6';$null=$row.Children.Add($label)
            $combo=[Windows.Controls.ComboBox]::new();$combo.Width=110;$combo.Margin='4'
            foreach($nic in $nics){$null=$combo.Items.Add([string]$nic)}
            $null=$row.Children.Add($combo)
            $script:UxMappingControls+=@{HostId=[string]$hostSpec.id;Uplink='uplink'+$i;Control=$combo}
        }
    }
}
$bar=New-Bar $basic
$null=Add-Button $bar 'Build per-host NIC dropdowns' {Invoke-UiAction {Build-UxMappings}}
$traffic=New-Bar $basic
foreach($type in @('MANAGEMENT','VMOTION','VSAN')){
    $check=[Windows.Controls.CheckBox]::new();$check.Content=$type;$check.Margin='6';$ui['UxTraffic'+$type]=$check;$null=$traffic.Children.Add($check)
    $null=Add-Input $traffic ($type+' portgroup') ('UxPg'+$type) 190
}
$bar=New-Bar $basic
$null=Add-Button $bar 'Add new switch and mappings' {Invoke-UiAction {
    $name=$ui.UxSwitchName.Text.Trim();$profile=$ui.UxProfile.Text.Trim();if(-not $profile){$profile='Compute-Network-Profile'};$mtu=0
    if(-not $name -or -not $profile){throw 'Enter switch and network-profile names.'}
    if(-not [int]::TryParse($ui.UxMtu.Text,[ref]$mtu) -or $mtu -lt 1500 -or $mtu -gt 9000){throw 'vDS MTU must be 1500 through 9000.'}
    if(-not $script:UxMappingControls.Count){throw 'Build the per-host NIC dropdowns first.'}
    $spec=Current-Spec;$c=$spec.computeSpec.clusterSpecs[0];$n=$c.networkSpec
    if(-not $n){throw 'Load the starter network specification first.'}
    $pgs=@();$uplinks=@($script:UxMappingControls|Select-Object -ExpandProperty Uplink -Unique)
    foreach($type in @('MANAGEMENT','VMOTION','VSAN')){
        if($ui['UxTraffic'+$type].IsChecked){
            $pg=$ui['UxPg'+$type].Text.Trim();if(-not $pg){throw ('Enter '+$type+' portgroup name.')}
            $pgs+=Get-TrafficFormSpec $type $pg $uplinks
        }
    }
    if(-not $pgs.Count){throw 'Select at least one network traffic type.'}
    # Shared traffic is not blocked locally; installed SDDC validation decides domain/design eligibility.
    # NSX is configured in the separate NSX Network Profile step.
    $vds=@{name=$name;mtu=$mtu;isUsedByNsxt=$false;portGroupSpecs=$pgs}
    $existing=@($n.vdsSpecs|Where-Object {$_.name -eq $name})
    if($existing.Count){throw 'This name already exists in the payload. Use Advanced vDS to edit it; this basic builder will not overwrite unknown settings.'}
    $hosts=@($c.hostSpecs)
    $expected=0
    if(-not [int]::TryParse($ui.UxUplinkCount.Text,[ref]$expected) -or $expected -lt 1 -or $expected -gt 8){throw 'Uplink count must be 1-8.'}
    if(@($script:UxMappingControls.HostId|Sort-Object -Unique).Count -ne $hosts.Count -or @($script:UxMappingControls.Uplink|Sort-Object -Unique).Count -ne $expected){throw 'Hosts or uplink count changed. Rebuild NIC dropdowns.'}
    foreach($h in $hosts){
        $rows=@($script:UxMappingControls|Where-Object {$_.HostId -eq $h.id})
        if(-not $rows.Count){throw 'Selected hosts changed. Rebuild NIC dropdowns.'}
        $new=@();$used=@()
        foreach($row in $rows){
            $nic=[string]$row.Control.SelectedItem
            if(-not $nic -or $nic -in $used){throw 'Select a different discovered NIC for each uplink on each host.'}
            $used+=,$nic;$new+=@{id=$nic;vdsName=$name;uplink=$row.Uplink}
        }
        if(-not $h.hostNetworkSpec){$h.hostNetworkSpec=@{vmNics=@()}}
        $old=@($h.hostNetworkSpec.vmNics|Where-Object {$_.vdsName -ne $name})
        if(@($old|Where-Object {$_.id -in $used}).Count){throw 'A selected NIC is already assigned to another switch in the payload.'}
        $h.hostNetworkSpec.vmNics=@($old)+$new;$h.hostNetworkSpec.networkProfileName=$profile
    }
    if(-not @($n.networkProfiles|Where-Object {$_.name -eq $profile}).Count){$n.networkProfiles=@($n.networkProfiles)+@(@{name=$profile;isDefault=(@($n.networkProfiles).Count -eq 0);nsxtHostSwitchConfigs=@()})}
    $n.vdsSpecs=@($n.vdsSpecs)+@($vds)
    if($script:DirtySections.Count){throw ('Apply pending edits before adding a switch: '+($script:DirtySections -join ', '))}
    $mtuPlan=Get-RequestedTrafficMtuPlan $name $mtu
    Commit-Spec $spec
    $script:RequestedTrafficMtuPlans[$name]=$mtuPlan
    Refresh-AppliedVdsChoices $name
    $ui.VdsApplyStatus.Foreground='#87D8B0';$ui.VdsApplyStatus.Text='Saved '+$name+' and NIC mappings to creation JSON. Available on NSX Network Profile. Traffic MTUs remain planning-only, NOT applied.'
    $ui.VdsApplyStatus.BringIntoView()
    Write-Log ('Applied vDS '+$name+' and host mappings to creation JSON; refreshed NSX vDS choices. Per-traffic MTUs recorded separately, NOT deployed.')
}}
Add-Text $basic 'Basic form: create-new vDS, standard uplinks, discovered per-host NIC choices, traffic/portgroup names and vDS MTU. No JSON entry is needed here. Use Advanced for existing-switch import, LAG, teaming/NIOC, NSX/static TEP details and editing existing definitions. This is NOT full native-wizard parity. Per-VMkernel MTU is not configured.'
# Redirect successful host Next to structured switch page.
$script:UxBasicTab=$basicTab
Write-Log 'v3.1 UX extension loaded: encrypted connection profiles, host-only selection, structured basic vDS builder. Advanced networking remains separate.'

$saveBar=New-Bar $connections
$null=Add-Button $saveBar 'Save creation JSON (work in progress)' {Invoke-UiAction {
    if($script:ViewDirty){throw 'Apply pending form edits before saving creation JSON.'}
    $spec=Current-Spec
    $d=[Microsoft.Win32.SaveFileDialog]::new();$d.Filter='Creation JSON (*.json)|*.json';$d.FileName='ClusterCreationSpec.json'
    if($d.ShowDialog()){
        [IO.File]::WriteAllText($d.FileName,(ConvertTo-Json -InputObject $spec -Depth 100),[Text.UTF8Encoding]::new($false))
        if(Get-Command Save-TrafficMtuSidecar -ErrorAction SilentlyContinue){Save-TrafficMtuSidecar $d.FileName}
        Write-Log 'Saved work-in-progress creation JSON. This is not a validation or deployment-readiness assertion.'
    }
}}
# Keep profile controls near the loaders, above credentials.
foreach($barToMove in @($saveBar,$profileBar)){
    $connections.Children.Remove($barToMove);$connections.Children.Insert(2,$barToMove)
}
# Remove stale text directing host selection back to JSON editing.
foreach($child in @($hostsTab.Children)){
    if($child -is [Windows.Controls.TextBlock] -and $child.Text -like '*Set Use and network profile*'){$child.Text='Select available commissioned hosts. Configure NIC/uplink mappings on Distributed Switch afterward. SDDC validation determines host compatibility and minimum count.'}
}
# Advanced forms remain available, but not presented as primary wizard steps.
$allTab.Parent.Header='Advanced fields'
$nsxTab.Parent.Header='Advanced NSX discovery'
$networkTab.Parent.Header='Advanced NSX definitions'
$ui.MainTabs.SelectedItem=$connectionTab


# v3.2: clean navigation, structured traffic and NSX configuration.
$ui.UxNsxMode.Visibility='Collapsed';$ui.UxProfile.Text='Compute-Network-Profile';$ui.UxProfile.Visibility='Collapsed'
foreach($row in @($basic.Children)){
 if($row -is [Windows.Controls.Panel]){foreach($c in @($row.Children)){
  if($c -is [Windows.Controls.TextBlock] -and $c.Text -in @('NSX host switch','Network profile name')){$c.Visibility='Collapsed'}
 }}
 if($row -is [Windows.Controls.TextBlock] -and $row.Text -like 'Basic form:*'){$row.Visibility='Collapsed'}
}
$trafficPanel=New-Bar $basic
$basic.Children.Remove($trafficPanel);$basic.Children.Insert(0,$trafficPanel)
Add-Text $basic 'Create New vDS with standard uplinks. Existing-switch reuse and LAG are not implemented in the guided form; no nonfunctional option is shown. Configure NSX in the next step. Shared Management/vMotion/vSAN is not blocked locally. Confirm the design with installed SDDC validation.'
$script:TrafficForms=@{}
$policies=@(@('Route based on physical NIC load','loadbalance_loadbased'),@('Route based on originating virtual port','loadbalance_srcid'),@('Route based on source MAC hash','loadbalance_srcmac'),@('Route based on IP hash','loadbalance_ip'),@('Use explicit failover order','failover_explicit'))
foreach($type in @('MANAGEMENT','VMOTION','VSAN')){
 $group=[Windows.Controls.GroupBox]::new();$group.Header=$type+' traffic';$group.Foreground='#EDF4FA';$group.Margin='6';$group.Padding='6'
 $panel=[Windows.Controls.StackPanel]::new();$group.Content=$panel
 [Windows.Controls.DockPanel]::SetDock($group,'Top');$null=$basic.Children.Add($group)
 $row=New-Bar $panel
 $null=Add-Input $row 'Load balancing' ('TrafficPolicy'+$type) 330 -Choice
 $combo=$ui['TrafficPolicy'+$type];$combo.IsEditable=$false
 foreach($p in $policies){Add-InventoryChoice ('TrafficPolicy'+$type) $p[0] $p[1]};$combo.SelectedIndex=0
 $row=New-Bar $panel
 $null=Add-Input $row 'Active uplinks (ordered, comma separated)' ('TrafficActive'+$type) 230
 $null=Add-Input $row 'Standby uplinks (ordered)' ('TrafficStandby'+$type) 200
 $ui['TrafficActive'+$type].Text='uplink1,uplink2'
 Add-Text $panel 'Unused uplinks are those omitted from both lists. No JSON syntax is needed. Traffic/VMkernel MTU is NOT serialized: the documented cluster PortgroupSpec has no MTU field. vDS MTU above is separate.'
}
function Split-UplinkList([string]$Text){return ,@($Text.Split(',')|ForEach-Object {$_.Trim()}|Where-Object {$_})}
function Get-TrafficFormSpec([string]$Type,[string]$Name,$Allowed){
 $active=Split-UplinkList $ui['TrafficActive'+$Type].Text;$standby=Split-UplinkList $ui['TrafficStandby'+$Type].Text
 if(-not $active.Count){throw ($Type+': select at least one active uplink.')}
 $all=@($active)+@($standby)
 if(@($all|Sort-Object -Unique).Count -ne $all.Count -or @($all|Where-Object {$_ -notin $Allowed}).Count){throw ($Type+': duplicate or undefined uplinks in active/standby lists.')}
 $policy=[string]$ui['TrafficPolicy'+$Type].SelectedItem.Tag
 if($policy -eq 'loadbalance_ip'){throw 'IP-hash requires a separately verified physical-switch aggregation design. This guided standard-uplink path does not implement that design.'}
 return @{name=$Name;transportType=$Type;activeUplinks=@($active);standByUplinks=@($standby);teamingPolicy=$policy}
}
# Reorder guided switch form: settings/mappings, traffic groups, then Apply.
$applyRow=$null
foreach($row in @($basic.Children)){
 if($row -is [Windows.Controls.Panel]){foreach($c in @($row.Children)){if($c -is [Windows.Controls.Button] -and [string]$c.Content -eq 'Add new switch and mappings'){$applyRow=$row}}}
}
if($applyRow){$basic.Children.Remove($applyRow);$null=$basic.Children.Add($applyRow)}
$nsxGuided=New-PanelTab '5 NSX Network Profile';$nsxGuided.LastChildFill=$false
$nsxGuidedTab=$nsxGuided.Parent;$ui.MainTabs.Items.Remove($nsxGuidedTab);$ui.MainTabs.Items.Insert($ui.MainTabs.Items.IndexOf($basicTab)+1,$nsxGuidedTab)
Add-Text $nsxGuided 'Choose an applied vDS, discovered transport zone(s), operational mode, and None / DHCP / Static existing / Static new. This builds creation JSON only. Existing system/service pools are not TEP choices. No NSX objects are changed by Apply.'
$row=New-Bar $nsxGuided
$null=Add-Input $row 'Applied vDS' 'GuidedNsxVds' 300 -Choice;$ui.GuidedNsxVds.IsEditable=$false
$null=Add-Input $row 'Network profile' 'GuidedProfile' 250;$ui.GuidedProfile.Text='Compute-Network-Profile'
$null=Add-Button $row 'Refresh choices' {Invoke-UiAction {Refresh-GuidedNsx}}
$row=New-Bar $nsxGuided
$null=Add-Input $row 'TEP addressing' 'GuidedAddressing' 220 -Choice
foreach($mode in @('None (NSX prepared, no TEP IPv4)','DHCP','Static - existing NSX pool','Static - new pool')){Add-InventoryChoice 'GuidedAddressing' $mode $mode};$ui.GuidedAddressing.SelectedIndex=-1;$ui.GuidedAddressing.IsEditable=$false
$ui.GuidedAddressing.Add_SelectionChanged({Update-TepModeControls})
$null=Add-Input $row 'Verified DHCP API value' 'GuidedDhcpValue' 200
Add-Text $nsxGuided 'None uses the native VCF 9.1.1 API shape: overlayVtepSpec.vtepType=NO_IP. DHCP encoding remains unverified and still requires its exact API value. Static existing/new retain their separate pool choices.'
$ack=[Windows.Controls.CheckBox]::new();$ack.Content='I verified this DHCP API value against the installed VCF version request/schema';$ui.GuidedDhcpAck=$ack
[Windows.Controls.DockPanel]::SetDock($ack,'Top');$null=$nsxGuided.Children.Add($ack)
$zones=[Windows.Controls.ListBox]::new();$zones.SelectionMode='Multiple';$zones.Height=110;$zones.Background='#223441';$zones.Foreground='#FFFFFF';$zones.Margin='6';$ui.GuidedZones=$zones
[Windows.Controls.DockPanel]::SetDock($zones,'Top');$null=$nsxGuided.Children.Add($zones)
$row=New-Bar $nsxGuided
$null=Add-Input $row 'New static TEP pool name' 'GuidedPool' 230
$null=Add-Input $row 'CIDR' 'GuidedCidr' 160
$null=Add-Input $row 'Gateway' 'GuidedGateway' 160
$row=New-Bar $nsxGuided
$null=Add-Input $row 'Range start' 'GuidedStart' 170
$null=Add-Input $row 'Range end' 'GuidedEnd' 170
$row=New-Bar $nsxGuided
$null=Add-Input $row 'Discovered uplink template' 'GuidedUplinkTemplate' 350 -Choice;$ui.GuidedUplinkTemplate.IsEditable=$false
$null=Add-Button $row 'Copy template values' {Invoke-UiAction {
 $o=Selected-Object 'GuidedUplinkTemplate'
 if($null -eq $o.transport_vlan -or -not $o.teaming){throw 'Template lacks transport VLAN or teaming. No partial copy.'}
 $ui.GuidedVlan.Text=[string]$o.transport_vlan;$ui.GuidedUplinkPolicy.Text=[string]$o.teaming.policy
 Write-Log 'Copied template VLAN/policy only. Enter a NEW profile name and verify uplink mapping. Existing profile reuse is not asserted.'
}}
$row=New-Bar $nsxGuided
$null=Add-Input $row 'NEW NSX uplink profile name' 'GuidedUplinkName' 260
$null=Add-Input $row 'TEP transport VLAN' 'GuidedVlan' 100
$null=Add-Input $row 'NSX teaming policy' 'GuidedUplinkPolicy' 210;$ui.GuidedUplinkPolicy.Text='LOADBALANCE_SRCID'
Add-Text $nsxGuided 'NSX uplink mapping below uses the vDS uplink names as NSX uplink names. A new profile definition is generated. Empty discovered templates do not imply no profiles exist; the raw response is saved for diagnosis. Static pool ranges must be NEW, approved and verified outside this tool.'
$row=New-Bar $nsxGuided
$null=Add-Button $row 'Apply NSX network profile' {Invoke-UiAction {Apply-GuidedNsx}}
$ui.GuidedNsxStatus=[Windows.Controls.TextBlock]::new();$ui.GuidedNsxStatus.Text='Refresh choices after adding switches and completing discovery.';$ui.GuidedNsxStatus.TextWrapping='Wrap';$ui.GuidedNsxStatus.Foreground='#FFD166'
[Windows.Controls.DockPanel]::SetDock($ui.GuidedNsxStatus,'Top');$null=$nsxGuided.Children.Add($ui.GuidedNsxStatus)
function Refresh-GuidedNsx {
 $spec=Current-Spec
 Refresh-AppliedVdsChoices
 $ui.GuidedZones.Items.Clear()
 foreach($item in $ui.NsxZoneChoice.Items){$o=$item.Tag;if($o.transport_type -in @('VLAN','OVERLAY')){
  $entry=[Windows.Controls.ListBoxItem]::new();$entry.Content=([string]$o.display_name+' | '+[string]$o.transport_type);$entry.Tag=$o;$null=$ui.GuidedZones.Items.Add($entry)
 }}
 $objects=@($ui.NsxUplinkChoice.Items|ForEach-Object {$_.Tag}|Where-Object {$_})
 Fill-Choice 'GuidedUplinkTemplate' $objects @('display_name','name') @('id')
 $ui.GuidedNsxStatus.Text='Discovered zone choices: '+$ui.GuidedZones.Items.Count+'; uplink templates: '+$objects.Count+'. Select explicitly; nothing is auto-applied.'
}
function Assert-NewIpv4Pool([string]$Cidr,[string]$Gateway,[string]$Start,[string]$End){
 $parts=$Cidr.Split('/');$prefix=0
 if($parts.Count -ne 2 -or -not [int]::TryParse($parts[1],[ref]$prefix) -or $prefix -lt 1 -or $prefix -gt 30){throw 'Static TEP pool requires IPv4 CIDR /1 through /30.'}
 $values=@()
 foreach($text in @($parts[0],$Gateway,$Start,$End)){
  $ip=$null;if(-not [Net.IPAddress]::TryParse($text,[ref]$ip) -or $ip.AddressFamily -ne [Net.Sockets.AddressFamily]::InterNetwork){throw 'Enter valid IPv4 subnet, gateway and range addresses.'}
  $bytes=$ip.GetAddressBytes();$values+=([uint64]$bytes[0]*16777216+[uint64]$bytes[1]*65536+[uint64]$bytes[2]*256+$bytes[3])
 }
 $size=[uint64][math]::Pow(2,32-$prefix);$network=[uint64]([math]::Floor($values[0]/$size)*$size);$broadcast=$network+$size-1
 if($values[0] -ne $network){throw 'CIDR must specify the network address.'}
 foreach($v in $values[1..3]){if($v -le $network -or $v -ge $broadcast){throw 'Gateway/range must be usable addresses inside the CIDR.'}}
 if($values[2] -gt $values[3] -or ($values[1] -ge $values[2] -and $values[1] -le $values[3])){throw 'Range order is invalid or includes the gateway.'}
}
function Apply-GuidedNsx {
 if($script:ViewDirty){throw 'Apply pending legacy section edits first.'}
 $spec=Current-Spec;$n=$spec.computeSpec.clusterSpecs[0].networkSpec
 $chosen=Selected-Object 'GuidedNsxVds';$name=[string]$chosen.name
 $vds=@($n.vdsSpecs|Where-Object {$_.name -eq $name});if($vds.Count -ne 1){throw 'Refresh and select a current applied switch.'}
 $mode=$ui.GuidedAddressing.SelectedIndex
 if($mode -lt 0){throw 'Choose None, DHCP, Static existing, or Static new explicitly.'}
 $profile=$ui.GuidedProfile.Text.Trim();$upName=$ui.GuidedUplinkName.Text.Trim();$vlan=0
 if($mode -eq 0){Apply-NoneTepProfile $spec $vds[0] $name $profile;return}
 if($mode -eq 4){Apply-CapturedStaticProfile $spec $name;return}
 if($n.nsxClusterSpec.nsxTClusterSpec.overlayVtepSpec.vtepType -eq 'NO_IP'){throw 'Cluster-wide None is already applied. Start from a fresh configuration or explicitly review/remove overlayVtepSpec before configuring DHCP/static.'}

 if(-not $profile -or -not $upName){throw 'Enter network-profile and NEW NSX uplink-profile names.'}
 if(-not [int]::TryParse($ui.GuidedVlan.Text,[ref]$vlan) -or $vlan -lt 0 -or $vlan -gt 4094){throw 'TEP VLAN must be 0-4094.'}
 if($ui.GuidedUplinkPolicy.Text.Trim() -ne 'LOADBALANCE_SRCID'){throw 'Guided new uplink profile supports LOADBALANCE_SRCID only. Other policies require verified Advanced configuration.'}
 $zoneSpecs=@();foreach($entry in @($ui.GuidedZones.SelectedItems)){$zoneSpecs+=@{name=[string]$entry.Tag.display_name;transportType=[string]$entry.Tag.transport_type}}
 if(-not @($zoneSpecs|Where-Object {$_.transportType -eq 'OVERLAY'}).Count){throw 'Select a discovered OVERLAY transport zone for this TEP-enabled switch.'}
 $mappings=@($spec.computeSpec.clusterSpecs[0].hostSpecs|ForEach-Object {$_.hostNetworkSpec.vmNics}|Where-Object {$_.vdsName -eq $name})
 $uplinks=@($mappings.uplink|Sort-Object -Unique);if(-not $uplinks.Count){throw 'Apply host NIC mappings for this vDS first.'}
 if(-not $n.nsxClusterSpec){$n.nsxClusterSpec=@{nsxTClusterSpec=@{}}};$nsx=$n.nsxClusterSpec.nsxTClusterSpec
 if(@($nsx.uplinkProfiles|Where-Object {$_.name -eq $upName}).Count){throw 'Uplink profile name already defined. Use a new name or Advanced to edit the existing definition.'}
 if(@($ui.NsxUplinkChoice.Items|Where-Object {$_.Tag.display_name -eq $upName}).Count){throw 'Name matches a discovered existing NSX profile. This guided path creates a new definition, not existing-object reuse.'}
 $config=@{vdsName=$name;uplinkProfileName=$upName;vdsUplinkToNsxUplink=@($uplinks|ForEach-Object {@{vdsUplinkName=$_;nsxUplinkName=$_}})}
 $switchConfig=@{transportZones=$zoneSpecs};Set-GuidedOperationalMode $switchConfig
 if($mode -eq 3){
  $pool=$ui.GuidedPool.Text.Trim();if($pool -notmatch '^[a-zA-Z0-9_-]+$'){throw 'Enter a NEW static pool name using letters, digits, underscore or hyphen.'}
  if(@($nsx.ipAddressPoolsSpec|Where-Object {$_.name -eq $pool}).Count -or @($ui.NsxPoolChoice.Items|Where-Object {$_.Tag.display_name -eq $pool}).Count){throw 'Pool name already exists. No implicit reuse or overwrite is performed.'}
  Assert-NewIpv4Pool $ui.GuidedCidr.Text.Trim() $ui.GuidedGateway.Text.Trim() $ui.GuidedStart.Text.Trim() $ui.GuidedEnd.Text.Trim()
  $nsx.ipAddressPoolsSpec=@($nsx.ipAddressPoolsSpec|Where-Object {$_})+@(@{name=$pool;subnets=@(@{cidr=$ui.GuidedCidr.Text.Trim();gateway=$ui.GuidedGateway.Text.Trim();ipAddressPoolRanges=@(@{start=$ui.GuidedStart.Text.Trim();end=$ui.GuidedEnd.Text.Trim()})})})
  $config.ipAddressPoolName=$pool
 }elseif($mode -eq 2){
  $existing=Selected-Object 'GuidedExistingPool'
  if($existing._system_owned -eq $true -or $existing.display_name -match '^(SI_|system-owned-)'){throw 'System/service pools cannot be selected as TEP pools.'}
  $pool=[string]$existing.display_name
  if($pool -notmatch '^[a-zA-Z0-9_-]+$'){throw 'Existing pool name does not meet the documented SDDC pool-name pattern.'}
  if(-not $ui.GuidedExistingAck.IsChecked){throw 'Confirm this pool is approved for host TEPs in this customer environment.'}
  if(@($ui.NsxPoolChoice.Items|Where-Object {$_.Tag.display_name -eq $pool}).Count -ne 1){throw 'Existing pool display name is not unique. Name-only reuse cannot safely resolve it.'}
  $defs=@($nsx.ipAddressPoolsSpec|Where-Object {$_.name -eq $pool})
  if($defs.Count -and @($defs|Where-Object {$_.subnets}).Count){throw 'This name is already defined with subnets in the payload. Do not mix creation and reuse.'}
  if(-not $defs.Count){$nsx.ipAddressPoolsSpec=@($nsx.ipAddressPoolsSpec|Where-Object {$_})+@(@{name=$pool})}
  $config.ipAddressPoolName=$pool
 }else{
  if(-not $ui.GuidedDhcpAck.IsChecked -or [string]::IsNullOrWhiteSpace($ui.GuidedDhcpValue.Text)){throw 'DHCP requires the exact installed-version API value and acknowledgement. No enum is guessed.'}
  $switchConfig.ipAssignmentType=$ui.GuidedDhcpValue.Text.Trim()
 }
 $nsx.uplinkProfiles=@($nsx.uplinkProfiles|Where-Object {$_})+@(@{name=$upName;transportVlan=$vlan;teamings=@(@{policy='LOADBALANCE_SRCID';activeUplinks=$uplinks;standByUplinks=@()})})
 $vds[0].isUsedByNsxt=$true;$vds[0].nsxtSwitchConfig=$switchConfig
 $profiles=@($n.networkProfiles|Where-Object {$_.name -eq $profile});if($profiles.Count -gt 1){throw 'Duplicate network profile names.'}
 if($profiles.Count){$p=$profiles[0]}else{$p=@{name=$profile;isDefault=(@($n.networkProfiles).Count -eq 0);nsxtHostSwitchConfigs=@()};$n.networkProfiles=@($n.networkProfiles)+@($p)}
 if(@($p.nsxtHostSwitchConfigs|Where-Object {$_.vdsName -eq $name}).Count){throw 'Profile already configures this vDS. Use Advanced for a reviewed update; no silent overwrite.'}
 $p.nsxtHostSwitchConfigs=@($p.nsxtHostSwitchConfigs|Where-Object {$_})+@($config)
 foreach($h in $spec.computeSpec.clusterSpecs[0].hostSpecs){$h.hostNetworkSpec.networkProfileName=$profile}
 Commit-Spec $spec
 $ui.GuidedNsxStatus.Text='NSX profile applied to creation JSON. SDDC validation and installed-version compatibility checks are still required.'
}
# Clean primary navigation: Advanced is opt-in and every tab is explicitly re-enabled by readiness.
$script:AdvancedTabs=@($switchTab.Parent,$nsxTab.Parent,$networkTab.Parent,$allTab.Parent)
$advancedBar=New-Bar $connections
$toggle=[Windows.Controls.CheckBox]::new();$toggle.Content='Show Advanced editors (optional)';$null=$advancedBar.Children.Add($toggle)
$toggle.Add_Click({param($sender,$eventArgs) foreach($tab in $script:AdvancedTabs){$tab.Visibility=if($sender.IsChecked){'Visible'}else{'Collapsed'}}})
foreach($tab in $script:AdvancedTabs){$tab.Visibility='Collapsed'}
# Explicit order avoids New-PanelTab's historical insert-before-last-three assumption.
$ordered=@($connectionTab,$general.Parent,$storage.Parent,$hostsTab.Parent,$basicTab,$nsxGuidedTab)+$script:AdvancedTabs
$remaining=@($ui.MainTabs.Items|Where-Object {$_ -notin $ordered})
$ui.MainTabs.Items.Clear();foreach($tab in @($ordered)+@($remaining)){$null=$ui.MainTabs.Items.Add($tab)}
# Add scrolling to long guided pages without changing control-parent references.
foreach($panel in @($connections,$basic,$nsxGuided)){
 $tab=$panel.Parent;$tab.Content=$null
 $scroll=[Windows.Controls.ScrollViewer]::new();$scroll.VerticalScrollBarVisibility='Auto';$scroll.HorizontalScrollBarVisibility='Disabled';$scroll.Content=$panel;$tab.Content=$scroll
}
# Parent is now ScrollViewer for those panels. Existing handlers referencing .Parent need a stable tab variable.
$script:GuidedNsxTab=$nsxGuidedTab
$ui.MainTabs.Add_SelectionChanged({param($sender,$eventArgs)
 if($eventArgs.Source -eq $ui.MainTabs -and $ui.MainTabs.SelectedItem -eq $script:GuidedNsxTab -and $ui.Editor.Text){Invoke-UiAction {Refresh-GuidedNsx}}
})
$ui.GuidedDhcpValue.IsEnabled=$false;$ui.GuidedDhcpAck.IsEnabled=$false
Update-StartReadiness
$ui.MainTabs.SelectedItem=$connectionTab


# v3.3 TEP modes: no default inferred from customer name or lab inventory.
$row=New-Bar $nsxGuided
$null=Add-Input $row 'Operational mode' 'GuidedOperationalMode' 340 -Choice
foreach($entry in @(@('Apply NSX Manager default','DEFAULT'),@('Standard','STANDARD'),@('Enhanced Datapath - Standard','ENS_INTERRUPT'),@('Enhanced Datapath - Dedicated','ENS'))){Add-InventoryChoice 'GuidedOperationalMode' $entry[0] $entry[1]}
$ui.GuidedOperationalMode.IsEditable=$false;$ui.GuidedOperationalMode.SelectedIndex=0
$row=New-Bar $nsxGuided
$null=Add-Input $row 'Existing NSX TEP pool' 'GuidedExistingPool' 460 -Choice;$ui.GuidedExistingPool.IsEditable=$false
$ack=[Windows.Controls.CheckBox]::new();$ack.Content='Selected existing pool is approved for host TEP use in this environment';$ack.Margin='6';$ui.GuidedExistingAck=$ack
[Windows.Controls.DockPanel]::SetDock($ack,'Top');$null=$nsxGuided.Children.Add($ack)
Add-Text $nsxGuided 'Static existing reuses a discovered pool by name without copying allocation ranges. System-owned/service pools are excluded. A pool being listed does not establish TEP suitability or available addresses. None and DHCP have no static pool. The NSX pool is NOT the commissioned-host vMotion/vSAN network pool.'
function Set-GuidedOperationalMode($Config){
 $value=[string]$ui.GuidedOperationalMode.SelectedItem.Tag
 if($value -in @('STANDARD','ENS','ENS_INTERRUPT')){$Config.hostSwitchOperationalMode=$value}
 elseif($value -eq 'DEFAULT'){$Config.Remove('hostSwitchOperationalMode')|Out-Null}
 else{throw 'Choose an operational mode.'}
}
function Update-TepModeControls {
 $mode=$ui.GuidedAddressing.SelectedIndex
 foreach($key in @('GuidedPool','GuidedCidr','GuidedGateway','GuidedStart','GuidedEnd')){if($ui.ContainsKey($key)){$ui[$key].IsEnabled=($mode -eq 3)}}
 foreach($key in @('GuidedExistingPool','GuidedExistingAck')){if($ui.ContainsKey($key)){$ui[$key].IsEnabled=($mode -eq 2)}}
 foreach($key in @('GuidedDhcpValue','GuidedDhcpAck')){if($ui.ContainsKey($key)){$ui[$key].IsEnabled=($mode -eq 1)}}
 foreach($key in @('GuidedUplinkName','GuidedVlan','GuidedUplinkPolicy','GuidedUplinkTemplate')){if($ui.ContainsKey($key)){$ui[$key].IsEnabled=($mode -gt 0)}}
 if($ui.ContainsKey('GuidedNsxStatus')){
  $ui.GuidedNsxStatus.Text=switch($mode){
   0{'None: captured VCF 9.1.1 mapping is overlayVtepSpec.vtepType=NO_IP. Choose the overlay zone and NSX Manager default; no API value, pool, VLAN or uplink profile is required.'}
   1{'DHCP: no static pool. Enter TEP VLAN/uplink settings and the verified installed-version DHCP API value.'}
   2{'Static existing: select a discovered approved NSX pool. Name-only reuse; no ranges are copied.'}
   3{'Static new: enter a new pool name, CIDR, gateway and allocation range. No live pool is created until a separately enabled cluster deployment.'}
   default{'Choose a TEP mode explicitly. No lab/customer default is inferred.'}
  }
 }
}
function Set-CapturedNoneTepSpec($Spec,[string]$VdsName,$Zones){
 $n=$Spec.computeSpec.clusterSpecs[0].networkSpec
 $switches=@($n.vdsSpecs|Where-Object {$_.name -eq $VdsName})
 if($switches.Count -ne 1){throw 'Select exactly one applied vDS.'}
 if(-not @($Zones|Where-Object {$_.transportType -eq 'OVERLAY'}).Count){throw 'Select the discovered OVERLAY transport zone, as in the captured None request.'}
 if($n.nsxClusterSpec.nsxTClusterSpec.overlayVtepSpec.vtepType -and $n.nsxClusterSpec.nsxTClusterSpec.overlayVtepSpec.vtepType -ne 'NO_IP'){throw 'Existing cluster-wide VTEP mode conflicts with None. Review the full configuration before changing modes.'}
 if(@($n.networkProfiles|ForEach-Object {$_.nsxtHostSwitchConfigs}|Where-Object {$_.ipAddressPoolName -or $_.uplinkProfileName}).Count){throw 'TEP-enabled host-switch profiles already exist. None is cluster-wide in the captured request; review/remove those definitions explicitly before applying None.'}
 if(@($n.nsxClusterSpec.nsxTClusterSpec.ipAddressPoolsSpec|Where-Object {$_}).Count -or @($n.nsxClusterSpec.nsxTClusterSpec.uplinkProfiles|Where-Object {$_}).Count){throw 'Static pool/uplink definitions remain. Review them explicitly before switching to cluster-wide None.'}
 if(-not $n.nsxClusterSpec){$n.nsxClusterSpec=@{}}
 if(-not $n.nsxClusterSpec.nsxTClusterSpec){$n.nsxClusterSpec.nsxTClusterSpec=@{}}
 $n.nsxClusterSpec.nsxTClusterSpec.overlayVtepSpec=@{vtepType='NO_IP'}
 $n.nsxClusterSpec.nsxTClusterSpec.Remove('ipAddressPoolsSpec')|Out-Null
 $n.nsxClusterSpec.nsxTClusterSpec.Remove('uplinkProfiles')|Out-Null
 # Match captured request: transport zones only; no ipAssignmentType, isUsedByNsxt or operational mode.
 $switches[0].nsxtSwitchConfig=@{transportZones=@($Zones)}
 $switches[0].Remove('isUsedByNsxt')|Out-Null
 # Basic builder's empty profile scaffolding is not present in native None request.
 $profiles=@($n.networkProfiles|Where-Object {@($_.nsxtHostSwitchConfigs|Where-Object {$_}).Count -gt 0})
 if($profiles.Count){throw 'Existing host-switch configurations require explicit review before applying the the None shape.'}
 $n.Remove('networkProfiles')|Out-Null
 foreach($hostSpec in @($Spec.computeSpec.clusterSpecs[0].hostSpecs)){
  if($hostSpec.hostNetworkSpec){$hostSpec.hostNetworkSpec.Remove('networkProfileName')|Out-Null}
 }
}
function Apply-NoneTepProfile($Spec,$Vds,[string]$VdsName,[string]$Profile){
 if([string]$ui.GuidedOperationalMode.SelectedItem.Tag -ne 'DEFAULT'){throw 'Captured None request omits operational mode. Choose Apply NSX Manager default for this evidence-matched path. Explicit modes remain unverified.'}
 $zones=@();foreach($entry in @($ui.GuidedZones.SelectedItems)){$zones+=@{name=[string]$entry.Tag.display_name;transportType=[string]$entry.Tag.transport_type}}
 Set-CapturedNoneTepSpec $Spec $VdsName $zones
 Commit-Spec $Spec
 $ui.GuidedNsxStatus.Foreground='#87D8B0'
 $ui.GuidedNsxStatus.Text='Saved TEP None: overlayVtepSpec.vtepType=NO_IP, matching captured VCF 9.1.1 validation requests. No pool/API-value input required. Run SDDC validation for this new configuration.'
}
# Extend refresh without replacing its inventory behavior.
$script:OriginalRefreshGuidedNsx=${function:Refresh-GuidedNsx}
function Refresh-GuidedNsx {
 & $script:OriginalRefreshGuidedNsx
 $pools=@($ui.NsxPoolChoice.Items|ForEach-Object {$_.Tag}|Where-Object {$_ -and $_._system_owned -ne $true -and $_.display_name -notmatch '^(SI_|system-owned-)'})
 Fill-Choice 'GuidedExistingPool' $pools @('display_name','name') @('id')
 $ui.GuidedNsxStatus.Text+=' Eligible existing-pool candidates: '+$pools.Count+'. Approval for TEP use is still required.'
}
# Keep NSX form controls above Apply, and preserve scrolling.
$applyRow=$null
foreach($row in @($nsxGuided.Children)){if($row -is [Windows.Controls.Panel]){foreach($c in @($row.Children)){if($c -is [Windows.Controls.Button] -and [string]$c.Content -eq 'Apply NSX network profile'){$applyRow=$row}}}}
if($applyRow){$nsxGuided.Children.Remove($applyRow);$null=$nsxGuided.Children.Add($applyRow)}
Update-TepModeControls


# v3.3.1: switch commit dependency and explicit planning-only traffic MTU inputs.
$script:RequestedTrafficMtuPlans=@{}
function Refresh-AppliedVdsChoices([string]$Preferred='') {
 if(-not $ui.ContainsKey('GuidedNsxVds')){return}
 $old=if($ui.GuidedNsxVds.SelectedItem){[string]$ui.GuidedNsxVds.SelectedItem.Tag.name}else{''}
 if(-not $Preferred){$Preferred=$old}
 $spec=Current-Spec;$switches=@($spec.computeSpec.clusterSpecs[0].networkSpec.vdsSpecs|Where-Object {$_.name})
 Fill-Choice 'GuidedNsxVds' $switches @('name') @('name')
 foreach($item in $ui.GuidedNsxVds.Items){if([string]$item.Tag.name -eq $Preferred){$ui.GuidedNsxVds.SelectedItem=$item;break}}
 if(-not $switches.Count -and $ui.ContainsKey('GuidedNsxStatus')){
  $ui.GuidedNsxStatus.Text='No vDS has been saved in creation JSON. Return to Distributed Switch, select NICs/traffic and click Add new switch and mappings. Discovery alone does not define a new switch.'
 }
}
function Get-RequestedTrafficMtuPlan([string]$Switch,[int]$SwitchMtu){
 $items=@()
 foreach($type in @('MANAGEMENT','VMOTION','VSAN')){
  if($ui['UxTraffic'+$type].IsChecked){
   $value=0
   if(-not [int]::TryParse($ui['RequestedMtu'+$type].Text,[ref]$value) -or $value -lt 1500 -or $value -gt 9000 -or $value -gt $SwitchMtu){throw ($type+': requested traffic MTU must be 1500-9000 and no larger than vDS MTU.')}
   $items+=@{trafficType=$type;portgroup=$ui['UxPg'+$type].Text.Trim();requestedMtu=$value;applicationStatus='NOT_APPLIED';apiMappingStatus='UNVERIFIED'}
  }
 }
 return @{vdsName=$Switch;vdsMtu=$SwitchMtu;traffic=$items}
}
function Save-TrafficMtuSidecar([string]$CreationPath){
 $spec=Current-Spec;$names=@($spec.computeSpec.clusterSpecs[0].networkSpec.vdsSpecs.name)
 $plans=@($script:RequestedTrafficMtuPlans.Values|Where-Object {$_.vdsName -in $names})
 $path=$CreationPath+'.traffic-mtu-plan.json'
 $data=@{kind='TrafficMtuPlan';deploymentStatus='NOT_APPLIED';warning='Planning data only. Not part of SDDC creation payload. No per-traffic MTU configuration is performed.';switches=$plans}
 [IO.File]::WriteAllText($path,(ConvertTo-Json -InputObject $data -Depth 30),[Text.UTF8Encoding]::new($false))
 Write-Log 'Saved traffic MTU planning sidecar. These values have NOT been configured on hosts.'
}
foreach($group in @($basic.Children|Where-Object {$_ -is [Windows.Controls.GroupBox]})){
 $type=([string]$group.Header).Split(' ')[0]
 if($type -in @('MANAGEMENT','VMOTION','VSAN')){
  $row=New-Bar $group.Content
  $null=Add-Input $row 'Requested traffic MTU (plan only, NOT applied)' ('RequestedMtu'+$type) 130
  $ui['RequestedMtu'+$type].Text=if($type -eq 'MANAGEMENT'){'1500'}else{'9000'}
  $group.Content.Children.Remove($row);$group.Content.Children.Insert(0,$row)
 }
}
$ui.VdsApplyStatus=[Windows.Controls.TextBlock]::new();$ui.VdsApplyStatus.Text='No switch saved in this session. Add new switch and mappings commits it to creation JSON before NSX selection.';$ui.VdsApplyStatus.Foreground='#FFD166';$ui.VdsApplyStatus.TextWrapping='Wrap';$ui.VdsApplyStatus.Margin='6'
[Windows.Controls.DockPanel]::SetDock($ui.VdsApplyStatus,'Top');$basic.Children.Insert(0,$ui.VdsApplyStatus)
Add-Text $basic 'MTU LIMIT: Requested traffic MTUs are captured as a separate planning sidecar, not injected into unsupported portGroupSpecs fields. This build does not apply per-VMkernel MTU. Save creation JSON also saves the sidecar; do not treat that file as an SDDC payload.'
# Block an NSX apply with a dependency-specific explanation, not a discovery error.
$script:OriginalApplyGuidedNsx=${function:Apply-GuidedNsx}
function Apply-GuidedNsx {
 $spec=Current-Spec
 if(-not @($spec.computeSpec.clusterSpecs[0].networkSpec.vdsSpecs|Where-Object {$_.name}).Count){throw 'No switch has been saved. On Distributed Switch click Add new switch and mappings successfully first, then return to NSX. Refresh discovery is not the missing step.'}
 & $script:OriginalApplyGuidedNsx
}


# v3.3.2: local success feedback and conditional final topology step.
$ui.DatacenterApplyStatus=[Windows.Controls.TextBlock]::new();$ui.DatacenterApplyStatus.Margin='6';$ui.DatacenterApplyStatus.TextWrapping='Wrap';$ui.DatacenterApplyStatus.Foreground='#FFD166';$ui.DatacenterApplyStatus.Text='Datacenter not yet confirmed in this session.'
$null=$dcBar.Children.Add($ui.DatacenterApplyStatus)
$ui.DcChoice.Add_SelectionChanged({if($ui.ContainsKey('DatacenterApplyStatus')){$ui.DatacenterApplyStatus.Text='Datacenter selection changed. Click Apply selected datacenter.';$ui.DatacenterApplyStatus.Foreground='#FFD166'}})
# Put switch feedback beside its action, not only at the top of a long scrolling page.
$ui.VdsApplyStatus.Parent.Children.Remove($ui.VdsApplyStatus)
foreach($row in @($basic.Children)){
 if($row -is [Windows.Controls.Panel]){foreach($c in @($row.Children)){
  if($c -is [Windows.Controls.Button] -and [string]$c.Content -eq 'Add new switch and mappings'){$null=$row.Children.Add($ui.VdsApplyStatus);break}
 }}
}
# Topology is the final optional storage section, not the first input.
$script:TopologyFinalGroup=[Windows.Controls.GroupBox]::new();$script:TopologyFinalGroup.Header='Final step: topology / storage-site affinity (stretched server only)';$script:TopologyFinalGroup.Foreground='#EDF4FA';$script:TopologyFinalGroup.Margin='6';$script:TopologyFinalGroup.Padding='6'
$topologyPanel=[Windows.Controls.StackPanel]::new();$script:TopologyFinalGroup.Content=$topologyPanel
$topologyRow=$ui.Topology.Parent;$topologyRow.Parent.Children.Remove($topologyRow)
$siteRow=$ui.StorageSiteChoice.Parent;$siteRow.Parent.Children.Remove($siteRow)
$null=$topologyPanel.Children.Add($siteRow);$null=$topologyPanel.Children.Add($topologyRow)
[Windows.Controls.DockPanel]::SetDock($script:TopologyFinalGroup,'Top');$null=$storage.Children.Add($script:TopologyFinalGroup)
$ui.TopologyFinalStatus=[Windows.Controls.TextBlock]::new();$ui.TopologyFinalStatus.Margin='6';$ui.TopologyFinalStatus.TextWrapping='Wrap';$ui.TopologyFinalStatus.Foreground='#FFD166'
$null=$topologyPanel.Children.Add($ui.TopologyFinalStatus)
function Update-FinalTopologyState {
 $selected=$ui.StorageClusterChoice.SelectedItem
 $known=($selected -and $selected.Tag.isStretched -is [bool])
 $stretched=($known -and $selected.Tag.isStretched)
 $ready=($stretched -and $null -ne $ui.DsChoice.SelectedItem)
 $script:TopologyFinalGroup.IsEnabled=$ready;$script:TopologyFinalGroup.Opacity=if($ready){1.0}else{0.5}
 $ui.TopologyFinalStatus.Text=if(-not $known){'Select the storage server and datastore first.'}elseif(-not $stretched){'Not applicable: non-stretched storage server. Apply remote datastore handles omission of topology/site fields.'}elseif(-not $ready){'Select a discovered remote datastore first, then complete this final topology step.'}else{'Choose topology and, for Asymmetric, the discovered local server site. Either storage Apply commits the storage settings together.'}
}
$ui.StorageClusterChoice.Add_SelectionChanged({Update-FinalTopologyState})
$ui.DsChoice.Add_SelectionChanged({Update-FinalTopologyState})
foreach($child in @($storage.Children)){
 if($child -is [Windows.Controls.TextBlock] -and $child.Text -like 'Use the Symmetric / Asymmetric*'){$child.Text='Select storage server and remote datastore first. Optional topology/site affinity is at the bottom and is enabled only for a stretched server with a datastore selected.'}
}
# Clearly shade irrelevant None/DHCP/static fields, including labels and template-copy button.
$script:PreviousUpdateTepModeControls=${function:Update-TepModeControls}
function Update-TepModeControls {
 & $script:PreviousUpdateTepModeControls
 $mode=$ui.GuidedAddressing.SelectedIndex
 foreach($key in @('GuidedPool','GuidedCidr','GuidedGateway','GuidedStart','GuidedEnd','GuidedExistingPool','GuidedExistingAck','GuidedUplinkName','GuidedVlan','GuidedUplinkPolicy','GuidedUplinkTemplate')){
  if($ui.ContainsKey($key)){
   $control=$ui[$key];$control.Opacity=if($control.IsEnabled){1.0}else{0.4}
   if($control.Parent -is [Windows.Controls.Panel]){
    $index=$control.Parent.Children.IndexOf($control)
    if($index -gt 0 -and $control.Parent.Children[$index-1] -is [Windows.Controls.TextBlock]){$control.Parent.Children[$index-1].Opacity=$control.Opacity}
   }
  }
 }
 foreach($row in @($nsxGuided.Children)){
  if($row -is [Windows.Controls.Panel]){foreach($c in @($row.Children)){
   if($c -is [Windows.Controls.Button] -and [string]$c.Content -eq 'Copy template values'){$c.IsEnabled=($mode -gt 0);$c.Opacity=if($c.IsEnabled){1.0}else{0.4}}
  }}
 }
 # Transport zones, operational mode and verified API-value controls stay usable for None.
}
# Clear stale success feedback when a different configuration is loaded.
$ui.Load.Add_Click({$ui.DatacenterApplyStatus.Text='Configuration loaded; verify and Apply the datacenter.';$ui.DatacenterApplyStatus.Foreground='#FFD166';$ui.VdsApplyStatus.Text='Configuration loaded. Review applied switches in creation JSON.';$ui.VdsApplyStatus.Foreground='#FFD166'})
$ui.Starter.Add_Click({$ui.DatacenterApplyStatus.Text='New configuration: Apply the selected datacenter.';$ui.DatacenterApplyStatus.Foreground='#FFD166';$ui.VdsApplyStatus.Text='New configuration: no switch saved yet.';$ui.VdsApplyStatus.Foreground='#FFD166'})
Update-FinalTopologyState
Update-TepModeControls


# v3.4 captured None UI state.
$script:PreCapturedNoneModeControls=${function:Update-TepModeControls}
function Update-TepModeControls {
 & $script:PreCapturedNoneModeControls
 $none=($ui.GuidedAddressing.SelectedIndex -eq 0)
 $ui.GuidedProfile.IsEnabled=(-not $none);$ui.GuidedProfile.Opacity=if($none){0.4}else{1.0}
 foreach($key in @('GuidedDhcpValue','GuidedDhcpAck')){$ui[$key].IsEnabled=($ui.GuidedAddressing.SelectedIndex -eq 1);$ui[$key].Opacity=if($ui[$key].IsEnabled){1.0}else{0.4}}
 if($none){$ui.GuidedNsxStatus.Text='None uses the VCF 9.1.1 API shape: overlayVtepSpec.vtepType=NO_IP. Select the OVERLAY zone and NSX Manager default, then Apply. No manual API value or TEP pool is needed.'}
}
Update-TepModeControls


# Static existing profile import was removed. Configure None, DHCP, or a new static pool from live form inputs only.
Update-TepModeControls

# Manual preflight uses the exact applied editor JSON and performs no network call.
$preflightBar=New-Bar $connections
$null=Add-Button $preflightBar 'Run local preflight (no API call)' {Invoke-UiAction {
    Invalidate
    $spec=Read-Spec
    Invoke-SpecPreflight $spec
    $report=$script:LastPreflightReport
    $warnings=if($null -ne $report){[int]$report.warningCount}else{0}
    [Windows.MessageBox]::Show(('Local preflight PASSED. Failures: 0. Warnings: '+$warnings+'. Full SDDC validation is still required.'),'Local preflight passed','OK','Information')|Out-Null
}}
$ui.PreflightStatus=[Windows.Controls.TextBlock]::new();$ui.PreflightStatus.Text='Local preflight not run for this configuration.';$ui.PreflightStatus.Foreground='#FFD166';$ui.PreflightStatus.TextWrapping='Wrap';$ui.PreflightStatus.Margin='6';$null=$preflightBar.Children.Add($ui.PreflightStatus)
$connections.Children.Remove($preflightBar);$connections.Children.Insert(2,$preflightBar)
$ui.Editor.Add_TextChanged({if($ui.ContainsKey('PreflightStatus')){$ui.PreflightStatus.Text='Configuration changed: rerun local preflight and full SDDC validation.';$ui.PreflightStatus.Foreground='#FFD166'}})

# v3.5.2 usability and null-safety hotfix.
# Preflight stays mandatory before Generate/Validate/Execute, but its manual button belongs at final review.
if($preflightBar -and $preflightBar.Parent){$preflightBar.Parent.Children.Remove($preflightBar)}
$finalActions=$ui.Generate.Parent
if($finalActions -is [Windows.Controls.Panel]){
    $finalActions.Children.Insert(1,$preflightBar)
    $ui.PreflightStatus.Text='Run local preflight after all configuration sections are applied.'
}

# Saved creation JSON can legitimately contain empty host, topology, affinity and NSX arrays while work is in progress.
function Load-Text([string]$Path) {
    $script:LoadingForms=$true
    try {
        $ui.Editor.Text=[IO.File]::ReadAllText($Path)
        $s=Read-Spec
        $clusters=@($s.computeSpec.clusterSpecs|Where-Object {$null -ne $_})
        if($clusters.Count -ne 1){throw 'Creation JSON must contain exactly one cluster specification.'}
        $c=$clusters[0]
        $mounts=@($c.datastoreSpec.vsanRemoteDatastoreClusterSpec.vsanRemoteDatastoreSpec|Where-Object {$null -ne $_})
        $r=if($mounts.Count){$mounts[0]}else{$null}
        if($r){foreach($item in $ui.Topology.Items){if($item.Content -eq $r.networkTopology){$ui.Topology.SelectedItem=$item}}}
        $sites=@($c.hostSpecs|Where-Object {$null -ne $_}|ForEach-Object {$_.azName}|Where-Object {$_}|Select-Object -Unique)
        $ui.Client1.Text=if($sites.Count -gt 0){[string]$sites[0]}else{''}
        $ui.Client2.Text=if($sites.Count -gt 1){[string]$sites[1]}else{''}
        $aff=if($r){@($r.siteAffinity|Where-Object {$null -ne $_})}else{@()}
        $ui.Site1.Text=if($aff.Count -gt 0){[string]$aff[0].serverSite}else{''}
        $ui.Site2.Text=if($aff.Count -gt 1){[string]$aff[1].serverSite}else{''}
        Write-Log "Loaded $Path. Empty work-in-progress arrays were handled without indexing. No API mutation was performed."
    } finally {$script:LoadingForms=$false}
}

# Rebuild NIC selectors from selected host IDs and current SDDC physicalNics inventory.
$ui.UxMappingStatus=[Windows.Controls.TextBlock]::new()
$ui.UxMappingStatus.Margin='6';$ui.UxMappingStatus.TextWrapping='Wrap';$ui.UxMappingStatus.Foreground='#FFD166'
$ui.UxMappingStatus.Text='NIC dropdowns not built for the current host selection.'
[Windows.Controls.DockPanel]::SetDock($ui.UxMappingStatus,'Top');$mappingPanel.Children.Insert(0,$ui.UxMappingStatus)
function Build-UxMappings {
    $count=0
    if(-not [int]::TryParse($ui.UxUplinkCount.Text,[ref]$count) -or $count -lt 1 -or $count -gt 8){throw 'Enter an uplink count from 1 through 8.'}
    $spec=Current-Spec
    $clusters=@($spec.computeSpec.clusterSpecs|Where-Object {$null -ne $_})
    if($clusters.Count -ne 1){throw 'Load a creation JSON with exactly one cluster.'}
    $selected=@($clusters[0].hostSpecs|Where-Object {$null -ne $_ -and $_.id})
    if(-not $selected.Count){throw 'No hosts are saved in the creation JSON. Return to Host Selection, check hosts, and click Use checked hosts / Next.'}
    $available=@($script:Cache.AvailableHosts|Where-Object {$null -ne $_})
    if(-not $available.Count){throw 'Current available-host inventory is empty. Run Connect & Discover All, then reselect hosts.'}
    $mappingPanel.Children.Clear();$script:UxMappingControls=@()
    [Windows.Controls.DockPanel]::SetDock($ui.UxMappingStatus,'Top');$null=$mappingPanel.Children.Add($ui.UxMappingStatus)
    foreach($hostSpec in $selected){
        $inventory=@($available|Where-Object {[string]$_.id -eq [string]$hostSpec.id})
        if($inventory.Count -ne 1){throw ('Selected host '+[string]$hostSpec.id+' was not found exactly once in current available-host inventory. Refresh discovery and host selection.')}
        $nics=@($inventory[0].physicalNics|Where-Object {$null -ne $_ -and $_.deviceName}|ForEach-Object {[string]$_.deviceName}|Sort-Object -Unique)
        if($nics.Count -lt $count){throw ([string]$inventory[0].fqdn+' has '+$nics.Count+' discovered physical NIC(s), fewer than the requested '+$count+' uplinks.')}
        $row=[Windows.Controls.WrapPanel]::new();$null=$mappingPanel.Children.Add($row)
        $label=[Windows.Controls.TextBlock]::new();$label.Text=[string]$inventory[0].fqdn;$label.Margin='6';$null=$row.Children.Add($label)
        for($i=1;$i -le $count;$i++){
            $uplink='uplink'+$i
            $label=[Windows.Controls.TextBlock]::new();$label.Text=$uplink;$label.Margin='6';$null=$row.Children.Add($label)
            $combo=[Windows.Controls.ComboBox]::new();$combo.Width=120;$combo.Margin='4';$combo.IsEditable=$false
            foreach($nic in $nics){$null=$combo.Items.Add($nic)}
            $prior=@($hostSpec.hostNetworkSpec.vmNics|Where-Object {$_.uplink -eq $uplink}|Select-Object -First 1)
            if($prior.Count -and [string]$prior[0].id -in $nics){$combo.SelectedItem=[string]$prior[0].id}
            $null=$row.Children.Add($combo)
            $script:UxMappingControls+=@{HostId=[string]$hostSpec.id;Uplink=$uplink;Control=$combo}
        }
    }
    $ui.UxMappingStatus.Text='Built '+$script:UxMappingControls.Count+' NIC selector(s) for '+$selected.Count+' host(s). Select one unique physical NIC per uplink.'
    $ui.UxMappingStatus.Foreground='#87D8B0';$ui.UxMappingStatus.BringIntoView()
    Write-Log $ui.UxMappingStatus.Text
}

# One concise checkbox label per traffic type; hide the redundant Add-Input label.
foreach($type in @('MANAGEMENT','VMOTION','VSAN')){
    $ui['UxTraffic'+$type].Content=($type+' portgroup')
    $box=$ui['UxPg'+$type]
    if($box -and $box.Parent -is [Windows.Controls.Panel]){
        $index=$box.Parent.Children.IndexOf($box)
        if($index -gt 0 -and $box.Parent.Children[$index-1] -is [Windows.Controls.TextBlock]){$box.Parent.Children[$index-1].Visibility='Collapsed'}
    }
}

# Changing selected hosts or uplink count invalidates the previously rendered selectors visibly.
$ui.UxUplinkCount.Add_TextChanged({
    if($ui.ContainsKey('UxMappingStatus')){$ui.UxMappingStatus.Text='Uplink count changed. Rebuild per-host NIC dropdowns.';$ui.UxMappingStatus.Foreground='#FFD166'}
})
# v3.5.3 null-safe NSX reference validation.
# Empty collections are valid only for TEP None (overlayVtepSpec.vtepType=NO_IP).
function Assert-UniqueNamedCollection([string]$Label,$Items){
    $records=@($Items|Where-Object {$null -ne $_})
    if(-not $records.Count){return}
    $names=@($records|ForEach-Object {[string]$_.name})
    if(@($names|Where-Object {[string]::IsNullOrWhiteSpace($_)}).Count){throw ($Label+' contains an empty name.')}
    if(@($names|Sort-Object -Unique).Count -ne $names.Count){throw ('Duplicate names in '+$Label+'.')}
}
function Assert-References($Spec) {
    $n=$Spec.computeSpec.clusterSpecs[0].networkSpec
    if($n -isnot [Collections.IDictionary]){throw 'networkSpec is required.'}
    $switches=@($n.vdsSpecs|Where-Object {$null -ne $_})
    $nsx=$n.nsxClusterSpec.nsxTClusterSpec
    if($nsx -isnot [Collections.IDictionary]){throw 'nsxTClusterSpec is required.'}
    $pools=@($nsx.ipAddressPoolsSpec|Where-Object {$null -ne $_})
    $uplinks=@($nsx.uplinkProfiles|Where-Object {$null -ne $_})
    $profiles=@($n.networkProfiles|Where-Object {$null -ne $_})
    Assert-UniqueNamedCollection 'vDS definitions' $switches
    Assert-UniqueNamedCollection 'NSX pool definitions' $pools
    Assert-UniqueNamedCollection 'NSX uplink-profile definitions' $uplinks
    Assert-UniqueNamedCollection 'network-profile definitions' $profiles
    $vdsNames=@($switches|ForEach-Object {[string]$_.name})
    $poolNames=@($pools|ForEach-Object {[string]$_.name})
    $uplinkNames=@($uplinks|ForEach-Object {[string]$_.name})
    $none=($nsx.overlayVtepSpec.vtepType -ceq 'NO_IP')
    if($none){
        if($profiles.Count -or $pools.Count -or $uplinks.Count){throw 'TEP None requires networkProfiles, ipAddressPoolsSpec and uplinkProfiles to be absent or empty.'}
        Write-Log 'NSX reference checks passed for TEP None. Empty profile/pool/uplink collections are intentional.'
        return
    }
    if(-not $profiles.Count){throw 'TEP-enabled configuration requires at least one network profile.'}
    foreach($profile in $profiles){
        foreach($hostSwitch in @($profile.nsxtHostSwitchConfigs|Where-Object {$null -ne $_})){
            if([string]$hostSwitch.vdsName -notin $vdsNames){throw 'Network profile references an unknown vDS.'}
            if($hostSwitch.ipAddressPoolName){
                if([string]$hostSwitch.ipAddressPoolName -notin $poolNames){throw 'Static pool reference has no matching definition.'}
            }else{
                $sw=@($switches|Where-Object {$_.name -ceq [string]$hostSwitch.vdsName})
                if($sw.Count -ne 1 -or [string]::IsNullOrWhiteSpace([string]$sw[0].nsxtSwitchConfig.ipAssignmentType)){throw 'No static pool: an explicit installed-schema-verified DHCP assignment type is required.'}
            }
            if([string]$hostSwitch.uplinkProfileName -notin $uplinkNames){throw 'Network profile references an unknown uplink definition.'}
            $maps=@($hostSwitch.vdsUplinkToNsxUplink|Where-Object {$null -ne $_})
            if(-not $maps.Count){throw 'vDS-to-NSX uplink mapping is required.'}
        }
    }
    foreach($pool in $pools){
        if(-not $pool.Contains('subnets')){continue} # name-only existing-pool reuse
        foreach($sub in @($pool.subnets|Where-Object {$null -ne $_})){
            $gw=$null;if(-not [Net.IPAddress]::TryParse([string]$sub.gateway,[ref]$gw)){throw 'Invalid TEP gateway IP.'}
            if([string]$sub.cidr -notmatch '^.+/\d{1,3}$'){throw 'Invalid TEP CIDR format.'}
            foreach($range in @($sub.ipAddressPoolRanges|Where-Object {$null -ne $_})){
                $start=$null;$end=$null
                if(-not [Net.IPAddress]::TryParse([string]$range.start,[ref]$start) -or -not [Net.IPAddress]::TryParse([string]$range.end,[ref]$end)){throw 'Invalid static TEP range endpoint.'}
            }
        }
    }
    Write-Log 'NSX name references and basic address formats passed. No IP availability, overlap, routing, bandwidth, MTU or site-health assertion is made.'
}
# v3.5.4 VCF 9 license-less deployment field and actionable validation output.
# SDDC validation explicitly required this root-level boolean for the connected vCenter version.
$finalActions=$ui.Generate.Parent
$ui.DeployWithoutLicenseKeys=[Windows.Controls.CheckBox]::new()
$ui.DeployWithoutLicenseKeys.Content='Deploy without license keys (VCF 9 / subscription licensing)'
$ui.DeployWithoutLicenseKeys.Margin='6';$ui.DeployWithoutLicenseKeys.IsChecked=$false
if($finalActions -is [Windows.Controls.Panel]){$finalActions.Children.Insert(1,$ui.DeployWithoutLicenseKeys)}
$ui.DeployWithoutLicenseKeys.Add_Checked({
    if($script:LoadingForms){return}
    Invoke-UiAction {
        $spec=Current-Spec
        $spec.deployWithoutLicenseKeys=$true
        Commit-Spec $spec
        Write-Log 'Set root deployWithoutLicenseKeys=true in creation JSON. This responds to SDDC validation; it does not bypass product entitlement requirements.'
    }
})
$ui.DeployWithoutLicenseKeys.Add_Unchecked({
    if($script:LoadingForms){return}
    Invoke-UiAction {
        $spec=Current-Spec
        if($spec.Contains('deployWithoutLicenseKeys')){$spec.Remove('deployWithoutLicenseKeys')|Out-Null;Commit-Spec $spec}
        Write-Log 'Removed deployWithoutLicenseKeys from creation JSON. Revalidate before execution.'
    }
})
function Sync-LicenseControlFromSpec {
    if(-not $ui.ContainsKey('DeployWithoutLicenseKeys') -or [string]::IsNullOrWhiteSpace($ui.Editor.Text)){return}
    try{
        $spec=Parse-Json $ui.Editor.Text
        $script:LoadingForms=$true
        $ui.DeployWithoutLicenseKeys.IsChecked=($spec.deployWithoutLicenseKeys -eq $true)
    }finally{$script:LoadingForms=$false}
}
$ui.Editor.Add_TextChanged({Sync-LicenseControlFromSpec})
Sync-LicenseControlFromSpec

# Add the installed-version field to local preflight without weakening any existing check.
$script:PreLicenseGetSpecPreflight=${function:Get-SpecPreflight}
function Get-SpecPreflight($Spec,$ServerIsStretched=$null){
    $rows=@(& $script:PreLicenseGetSpecPreflight $Spec $ServerIsStretched)
    $ok=($Spec.deployWithoutLicenseKeys -is [bool] -and $Spec.deployWithoutLicenseKeys -eq $true)
    $rows+=,[pscustomobject]@{Area='Payload';Check='License-less deployment flag';Status=if($ok){'PASS'}else{'FAIL'};Detail='Connected SDDC validation required root deployWithoutLicenseKeys=true for this vCenter version.'}
    return ,$rows
}

# Preserve strict failure, but surface the exact SDDC error/remediation in the dialog/log.
function Assert-ValidationResponse($Response){
    $issues=[Collections.Generic.List[string]]::new()
    function Visit-ValidationNode($Node){
        if($null -eq $Node){return}
        if($Node -is [array]){foreach($item in $Node){Visit-ValidationNode $item};return}
        if($Node -is [Collections.IDictionary]){$props=@($Node.Keys)}else{$props=@($Node.PSObject.Properties.Name)}
        if('resultStatus' -in $props -and [string]$Node.resultStatus -in @('FAILED','CANCELLED','PENDING','IN_PROGRESS','CANCELLATION_IN_PROGRESS','ERROR')){
            $code=if($Node.errorResponse.errorCode){[string]$Node.errorResponse.errorCode}else{[string]$Node.resultStatus}
            $message=[string]$Node.errorResponse.message;$remediation=[string]$Node.errorResponse.remediationMessage
            $detail=$code
            if($message){$detail+=': '+$message}
            if($remediation){$detail+=' Remediation: '+$remediation}
            if($detail -notin $issues){$issues.Add($detail)}
        }
        foreach($key in $props){$value=$Node.$key;if($value -is [Collections.IDictionary] -or $value -is [pscustomobject] -or $value -is [array]){Visit-ValidationNode $value}}
    }
    Visit-ValidationNode $Response
    if($Response.executionStatus -cne 'COMPLETED' -or $Response.resultStatus -cne 'SUCCEEDED' -or $issues.Count){
        $headline='SDDC validation result: executionStatus='+[string]$Response.executionStatus+', resultStatus='+[string]$Response.resultStatus+'.'
        if($issues.Count){throw ($headline+' '+($issues -join ' | '))}
        throw ($headline+' Inspect the saved validation response. HTTP acceptance alone is not success.')
    }
}
# v3.5.5 automatically applies the VCF 9 license-less deployment field before preflight.
# This removes dependence on an easy-to-miss checkbox event while keeping the JSON visible and reviewable.
$script:PreAutoLicenseInvokeSpecPreflight=${function:Invoke-SpecPreflight}
function Invoke-SpecPreflight($Spec){
    if($Spec -isnot [Collections.IDictionary]){throw 'Creation specification root must be an object.'}
    $changed=(-not $Spec.Contains('deployWithoutLicenseKeys') -or $Spec.deployWithoutLicenseKeys -ne $true)
    if($changed){
        $Spec.deployWithoutLicenseKeys=$true
        $script:LoadingForms=$true
        try{$ui.Editor.Text=ConvertTo-Json -InputObject $Spec -Depth 100}finally{$script:LoadingForms=$false}
        $script:ViewDirty=$false;$script:FormsStale=$false
        Invalidate
        if($ui.ContainsKey('DeployWithoutLicenseKeys')){
            $script:LoadingForms=$true
            try{$ui.DeployWithoutLicenseKeys.IsChecked=$true}finally{$script:LoadingForms=$false}
        }
        Write-Log 'Automatically applied root deployWithoutLicenseKeys=true before local preflight, as required by the prior SDDC validation response.'
    }
    & $script:PreAutoLicenseInvokeSpecPreflight $Spec
}
# The connected environment already required this field. Keep the control checked and informational.
if($ui.ContainsKey('DeployWithoutLicenseKeys')){
    $ui.DeployWithoutLicenseKeys.Content='deployWithoutLicenseKeys=true (required by connected VCF 9 validation; applied automatically)'
    $ui.DeployWithoutLicenseKeys.IsEnabled=$false
    $ui.DeployWithoutLicenseKeys.ToolTip='The prior SDDC validation explicitly required this root-level Boolean. Preflight writes it into the visible creation JSON before checking.'
}

# v3.5.7 integrated host-selection and NIC mapping corrections.
$oldHostNext=$null
foreach($row in @($hostsTab.Children)){
    if($row -is [Windows.Controls.Panel]){foreach($control in @($row.Children)){
        if($control -is [Windows.Controls.Button] -and [string]$control.Content -eq 'Use checked hosts / Next: Distributed Switch'){$oldHostNext=$control}
    }}
}
if($oldHostNext){$oldHostNext.Visibility='Collapsed'}
function Save-CheckedHostsForVds {
    $null=$ui.HostGrid.CommitEdit([Windows.Controls.DataGridEditingUnit]::Cell,$true)
    $null=$ui.HostGrid.CommitEdit([Windows.Controls.DataGridEditingUnit]::Row,$true)
    $selected=@($ui.HostGrid.ItemsSource|Where-Object {$_.Use -eq $true})
    if(-not $selected.Count){throw 'Check at least one available host.'}
    $available=@($script:Cache.AvailableHosts|Where-Object {$null -ne $_})
    if(-not $available.Count){throw 'Available-host inventory is empty. Run Connect & Discover All.'}
    foreach($row in $selected){if(@($available|Where-Object {[string]$_.id -eq [string]$row.Id}).Count -ne 1){throw ('Checked host '+[string]$row.FQDN+' is not present exactly once in current available-host inventory.')}}
    $spec=Current-Spec;$c=$spec.computeSpec.clusterSpecs[0]
    $existing=@($c.hostSpecs|Where-Object {$null -ne $_});$new=@()
    foreach($row in $selected){
        $prior=@($existing|Where-Object {[string]$_.id -eq [string]$row.Id})
        $item=if($prior.Count -eq 1){Copy-Json $prior[0]}else{@{id=[string]$row.Id;hostName=[string]$row.FQDN}}
        $item.Remove('azName')|Out-Null;$new+=,$item
    }
    $c.hostSpecs=$new
    foreach($name in @('3 Hosts / NIC mappings','3 Host Selection','4 Distributed Switch','4 Custom vDS')){$null=$script:DirtySections.Remove($name)}
    $script:LoadingForms=$true
    try{$ui.Editor.Text=ConvertTo-Json -InputObject $spec -Depth 100}finally{$script:LoadingForms=$false}
    $script:ViewDirty=$false;$script:FormsStale=$false;Invalidate;Reload-Forms
    $saved=@((Parse-Json $ui.Editor.Text).computeSpec.clusterSpecs[0].hostSpecs|Where-Object {$null -ne $_ -and $_.id})
    if($saved.Count -ne $selected.Count){throw 'Host-selection verification failed: editor JSON host count does not match checked rows.'}
    Write-Log ('Saved '+$saved.Count+' checked host(s) to creation JSON and verified hostSpecs before Distributed Switch.')
    $ui.MainTabs.SelectedItem=$script:UxBasicTab
}
$newHostNext=[Windows.Controls.Button]::new();$newHostNext.Content='Use checked hosts / Next: Distributed Switch'
$newHostNext.Add_Click({Invoke-UiAction {Save-CheckedHostsForVds}})
if($hostActions -is [Windows.Controls.Panel]){$null=$hostActions.Children.Add($newHostNext)}
# Replace existing builder behavior through final function definition.
$script:PriorBuildUxMappings=${function:Build-UxMappings}
function Build-UxMappings {
    $count=0
    if(-not [int]::TryParse($ui.UxUplinkCount.Text,[ref]$count) -or $count -lt 1 -or $count -gt 8){throw 'Enter an uplink count from 1 through 8.'}
    $spec=Current-Spec;$selected=@($spec.computeSpec.clusterSpecs[0].hostSpecs|Where-Object {$null -ne $_ -and $_.id})
    if(-not $selected.Count){
        # The operator may navigate directly to Distributed Switch after checking rows.
        # Commit those explicit selections here instead of requiring a separate transition button.
        $null=$ui.HostGrid.CommitEdit([Windows.Controls.DataGridEditingUnit]::Cell,$true)
        $null=$ui.HostGrid.CommitEdit([Windows.Controls.DataGridEditingUnit]::Row,$true)
        $checked=@($ui.HostGrid.ItemsSource|Where-Object {$_.Use -eq $true})
        if(-not $checked.Count){throw 'No hosts are saved in creation JSON and no host rows are checked. Select hosts on Host Selection first.'}
        $availableNow=@($script:Cache.AvailableHosts|Where-Object {$null -ne $_})
        if(-not $availableNow.Count){throw 'Available-host inventory is empty. Run Connect & Discover All.'}
        $newHosts=@()
        foreach($row in $checked){
            $rowId=[string]$row.Id;if([string]::IsNullOrWhiteSpace($rowId)){$rowId=[string]$row.id}
            $rowName=[string]$row.FQDN;if([string]::IsNullOrWhiteSpace($rowName)){$rowName=[string]$row.fqdn}
            $matches=@($availableNow|Where-Object {[string]$_.id -eq $rowId})
            if($matches.Count -ne 1){throw ('Checked host '+$rowName+' is not present exactly once in current available-host inventory.')}
            $newHosts+=,@{id=$rowId;hostName=$rowName}
        }
        $spec.computeSpec.clusterSpecs[0].hostSpecs=$newHosts
        foreach($name in @('3 Hosts / NIC mappings','3 Host Selection','4 Distributed Switch','4 Custom vDS')){$null=$script:DirtySections.Remove($name)}
        $script:LoadingForms=$true
        try{$ui.Editor.Text=ConvertTo-Json -InputObject $spec -Depth 100}finally{$script:LoadingForms=$false}
        $script:ViewDirty=$false;$script:FormsStale=$false;Invalidate
        $verified=Parse-Json $ui.Editor.Text
        $selected=@($verified.computeSpec.clusterSpecs[0].hostSpecs|Where-Object {$null -ne $_ -and $_.id})
        if($selected.Count -ne $checked.Count){throw 'Automatic checked-host commit verification failed.'}
        Write-Log ('Automatically saved '+$selected.Count+' checked host(s) to creation JSON before building NIC dropdowns.')
        $spec=$verified
    }
    $available=@($script:Cache.AvailableHosts|Where-Object {$null -ne $_});if(-not $available.Count){throw 'Current available-host inventory is empty. Run Connect & Discover All.'}
    $mappingPanel.Children.Clear();$script:UxMappingControls=@()
    foreach($hostSpec in $selected){
        $inventory=@($available|Where-Object {[string]$_.id -eq [string]$hostSpec.id});if($inventory.Count -ne 1){throw 'Selected host is not present exactly once in current inventory.'}
        $nics=@($inventory[0].physicalNics|Where-Object {$null -ne $_ -and $_.deviceName}|ForEach-Object {[string]$_.deviceName}|Sort-Object -Unique)
        if($nics.Count -lt $count){throw ([string]$inventory[0].fqdn+' has fewer discovered NICs than requested uplinks.')}
        $row=[Windows.Controls.WrapPanel]::new();$null=$mappingPanel.Children.Add($row)
        $label=[Windows.Controls.TextBlock]::new();$label.Text=[string]$inventory[0].fqdn;$label.Margin='6';$null=$row.Children.Add($label)
        for($i=1;$i -le $count;$i++){
            $uplink='uplink'+$i;$label=[Windows.Controls.TextBlock]::new();$label.Text=$uplink;$label.Margin='6';$null=$row.Children.Add($label)
            $combo=[Windows.Controls.ComboBox]::new();$combo.Width=120;$combo.Margin='4';$combo.IsEditable=$false;foreach($nic in $nics){$null=$combo.Items.Add($nic)}
            $prior=@($hostSpec.hostNetworkSpec.vmNics|Where-Object {$_.uplink -eq $uplink}|Select-Object -First 1);if($prior.Count -and [string]$prior[0].id -in $nics){$combo.SelectedItem=[string]$prior[0].id}
            $null=$row.Children.Add($combo);$script:UxMappingControls+=@{HostId=[string]$hostSpec.id;Uplink=$uplink;Control=$combo}
        }
    }
    Write-Log ('Built '+$script:UxMappingControls.Count+' NIC selector(s) for '+$selected.Count+' host(s).')
}

$null=$script:Window.ShowDialog()
